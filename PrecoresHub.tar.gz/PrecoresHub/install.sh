#!/bin/bash
################################################################################
# PrecoresHub v5.0.0 - Installation Script
# 
# This script installs PrecoresHub to /opt/precoreshub or user-specified location
################################################################################

set -e

VERSION="5.0.0"
INSTALL_DIR="/opt/precoreshub"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print functions
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Print header
print_header() {
    clear
    echo "================================================================"
    echo "           PrecoresHub v${VERSION} - Installation"
    echo "================================================================"
    echo ""
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root. Installing to ${INSTALL_DIR}"
        return 0
    else
        print_info "Not running as root. Installing to ${HOME}/.local/share/precoreshub"
        INSTALL_DIR="${HOME}/.local/share/precoreshub"
        return 1
    fi
}

# Check dependencies
check_dependencies() {
    print_info "Checking dependencies..."
    
    local missing_deps=()
    
    if ! command -v jq &>/dev/null; then
        missing_deps+=("jq")
    fi
    
    if ! command -v fzf &>/dev/null; then
        missing_deps+=("fzf")
    fi
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        print_warning "Missing dependencies: ${missing_deps[*]}"
        echo ""
        echo "Please install missing dependencies:"
        echo ""
        echo "  Debian/Ubuntu:  sudo apt install ${missing_deps[*]}"
        echo "  Arch Linux:     sudo pacman -S ${missing_deps[*]}"
        echo "  Fedora:         sudo dnf install ${missing_deps[*]}"
        echo "  Alpine:         sudo apk add ${missing_deps[*]}"
        echo ""
        read -p "Continue anyway? (y/n): " continue_install
        if [[ "$continue_install" != "y" ]]; then
            print_error "Installation cancelled"
            exit 1
        fi
    else
        print_success "All dependencies satisfied"
    fi
}

# Install files
install_files() {
    print_info "Installing PrecoresHub to ${INSTALL_DIR}..."
    
    # Create installation directory
    mkdir -p "${INSTALL_DIR}"
    
    # Copy all files
    cp -r "${SCRIPT_DIR}"/* "${INSTALL_DIR}/" 2>/dev/null || true
    
    # Make main script executable
    chmod +x "${INSTALL_DIR}/PrecoresHub.sh"
    
    # Make all library files executable
    chmod +x "${INSTALL_DIR}"/lib/*.sh 2>/dev/null || true
    
    print_success "Files installed successfully"
}

# Create symlink
create_symlink() {
    local bin_dir
    
    if [[ $EUID -eq 0 ]]; then
        bin_dir="/usr/local/bin"
    else
        bin_dir="${HOME}/.local/bin"
        mkdir -p "${bin_dir}"
    fi
    
    print_info "Creating symlink in ${bin_dir}..."
    
    # Remove old symlink if exists
    rm -f "${bin_dir}/precoreshub"
    
    # Create new symlink
    ln -s "${INSTALL_DIR}/PrecoresHub.sh" "${bin_dir}/precoreshub"
    
    print_success "Symlink created: ${bin_dir}/precoreshub"
    
    # Check if bin_dir is in PATH
    if [[ ":$PATH:" != *":${bin_dir}:"* ]]; then
        print_warning "${bin_dir} is not in your PATH"
        echo ""
        echo "Add this line to your ~/.bashrc or ~/.zshrc:"
        echo "  export PATH=\"${bin_dir}:\$PATH\""
        echo ""
    fi
}

# Create desktop entry (for GUI systems)
create_desktop_entry() {
    if [[ $EUID -eq 0 ]]; then
        local desktop_dir="/usr/share/applications"
    else
        local desktop_dir="${HOME}/.local/share/applications"
        mkdir -p "${desktop_dir}"
    fi
    
    print_info "Creating desktop entry..."
    
    cat > "${desktop_dir}/precoreshub.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=PrecoresHub
Comment=Unified Control Center for Linux
Exec=${INSTALL_DIR}/PrecoresHub.sh
Icon=utilities-terminal
Terminal=true
Categories=System;Utility;
Keywords=package;install;system;management;
EOF
    
    print_success "Desktop entry created"
}

# Print completion message
print_completion() {
    echo ""
    echo "================================================================"
    print_success "PrecoresHub v${VERSION} installed successfully!"
    echo "================================================================"
    echo ""
    echo "Installation directory: ${INSTALL_DIR}"
    echo ""
    echo "To run PrecoresHub:"
    echo "  1. Using symlink:  precoreshub"
    echo "  2. Direct:         bash ${INSTALL_DIR}/PrecoresHub.sh"
    echo "  3. From menu:      Search for 'PrecoresHub' in your application menu"
    echo ""
    echo "Documentation:"
    echo "  - Quick Start:  ${INSTALL_DIR}/QUICK_START.md"
    echo "  - README:       ${INSTALL_DIR}/README.md"
    echo "  - Start Here:   ${INSTALL_DIR}/START_HERE.md"
    echo ""
    echo "Configuration:"
    echo "  - Config:  ~/.config/precoreshub/config.json"
    echo "  - Cache:   ~/.cache/precoreshub/"
    echo ""
    print_info "Run 'precoreshub' to start!"
    echo ""
}

# Main installation
main() {
    print_header
    
    # Check if already installed
    if [[ -d "${INSTALL_DIR}" ]]; then
        print_warning "PrecoresHub is already installed at ${INSTALL_DIR}"
        read -p "Reinstall? (y/n): " reinstall
        if [[ "$reinstall" != "y" ]]; then
            print_info "Installation cancelled"
            exit 0
        fi
        print_info "Removing old installation..."
        rm -rf "${INSTALL_DIR}"
    fi
    
    # Check root
    check_root
    
    # Check dependencies
    check_dependencies
    
    # Install files
    install_files
    
    # Create symlink
    create_symlink
    
    # Create desktop entry
    create_desktop_entry
    
    # Print completion
    print_completion
}

# Run main
main "$@"
