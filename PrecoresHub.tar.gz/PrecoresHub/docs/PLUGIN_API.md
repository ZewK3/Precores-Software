# PrecoresHub Plugin API Documentation

## Overview

The PrecoresHub Plugin API provides a set of functions that plugins can use to interact with the PrecoresHub system. These functions allow plugins to install packages, execute commands, display notifications, manage configuration, and more.

## API Functions

### 1. phub_install_package()

Install a package using the current distribution's package manager.

**Syntax:**
```bash
phub_install_package "package_name"
```

**Parameters:**
- `package_name` (required): Name of the package to install

**Returns:**
- Exit code 0 on success
- Exit code 1 on failure

**Example:**
```bash
# Install curl
phub_install_package "curl"

# Check result
if phub_install_package "git"; then
    phub_notify "Git installed successfully" "success"
else
    phub_notify "Failed to install git" "error"
fi
```

**Notes:**
- Automatically uses the correct package manager for the current distribution
- Handles package name mapping across different distributions
- Logs all installation attempts

---

### 2. phub_execute_command()

Execute a shell command with progress tracking and logging.

**Syntax:**
```bash
phub_execute_command "command"
```

**Parameters:**
- `command` (required): Shell command to execute

**Returns:**
- Exit code from the executed command

**Example:**
```bash
# Execute a simple command
phub_execute_command "echo Hello World"

# Execute with error handling
if phub_execute_command "systemctl status nginx"; then
    phub_notify "Nginx is running" "success"
else
    phub_notify "Nginx is not running" "error"
fi

# Execute complex command
phub_execute_command "cd /tmp && wget https://example.com/file.tar.gz && tar -xzf file.tar.gz"
```

**Notes:**
- Command output is captured and logged
- Supports complex commands with pipes and redirects
- Executed in a subshell for isolation

---

### 3. phub_notify()

Display a notification message to the user.

**Syntax:**
```bash
phub_notify "message" ["type"]
```

**Parameters:**
- `message` (required): Message to display
- `type` (optional): Notification type - "info" (default), "error", or "success"

**Returns:**
- Exit code 0 (always succeeds)

**Example:**
```bash
# Info notification (default)
phub_notify "Starting installation..."

# Success notification
phub_notify "Installation completed!" "success"

# Error notification
phub_notify "Failed to download file" "error"

# Info notification (explicit)
phub_notify "Processing data..." "info"
```

**Notes:**
- Messages are logged to the system log
- Success messages include a checkmark (✓) prefix
- All notifications are visible to the user

---

### 4. phub_config_get()

Get a configuration value from PrecoresHub settings.

**Syntax:**
```bash
value=$(phub_config_get "key")
```

**Parameters:**
- `key` (required): Configuration key to retrieve

**Returns:**
- Configuration value on stdout
- Exit code 0 on success
- Exit code 1 if key not found

**Example:**
```bash
# Get language setting
lang=$(phub_config_get "language")
echo "Current language: $lang"

# Get with error handling
if value=$(phub_config_get "theme"); then
    echo "Theme: $value"
else
    echo "Theme not configured"
fi

# Get parallel installation limit
limit=$(phub_config_get "parallel_install_limit")
echo "Parallel limit: $limit"
```

**Common Configuration Keys:**
- `language` - User interface language (en, vi)
- `parallel_install_limit` - Maximum parallel installations
- `cache_ttl` - Cache time-to-live in seconds
- `update_check_frequency` - Update check frequency in hours
- `log_level` - Logging level (DEBUG, INFO, ERROR)

---

### 5. phub_config_set()

Set a configuration value in PrecoresHub settings.

**Syntax:**
```bash
phub_config_set "key" "value"
```

**Parameters:**
- `key` (required): Configuration key to set
- `value` (required): Value to set

**Returns:**
- Exit code 0 on success
- Exit code 1 on failure

**Example:**
```bash
# Set language
phub_config_set "language" "vi"

# Set parallel installation limit
phub_config_set "parallel_install_limit" "3"

# Set with error handling
if phub_config_set "theme" "dark"; then
    phub_notify "Theme updated" "success"
else
    phub_notify "Failed to update theme" "error"
fi
```

**Notes:**
- Changes are persisted to disk immediately
- Configuration is validated before saving
- Invalid values may be rejected

---

### 6. phub_get_distro()

Get information about the current Linux distribution.

**Syntax:**
```bash
distro_info=$(phub_get_distro)
```

**Parameters:**
- None

**Returns:**
- JSON object with distribution information
- Exit code 0 on success
- Exit code 1 on failure

**JSON Structure:**
```json
{
  "id": "alpine",
  "name": "Alpine Linux",
  "package_manager": "apk"
}
```

**Example:**
```bash
# Get full distro info
distro_info=$(phub_get_distro)
echo "$distro_info"

# Extract specific fields
distro_name=$(phub_get_distro | jq -r '.name')
pkg_manager=$(phub_get_distro | jq -r '.package_manager')

echo "Running on: $distro_name"
echo "Package manager: $pkg_manager"

# Use in conditional
distro_id=$(phub_get_distro | jq -r '.id')
if [[ "$distro_id" == "alpine" ]]; then
    phub_notify "Alpine Linux detected" "info"
fi
```

**Supported Distributions:**
- Alpine Linux (apk)
- Arch Linux (pacman)
- Debian/Ubuntu (apt)
- Fedora (dnf)
- RHEL/CentOS (yum/dnf)
- openSUSE (zypper)
- Gentoo (emerge)
- Void Linux (xbps)
- NixOS (nix)
- Solus (eopkg)
- Clear Linux (swupd)

---

### 7. phub_is_installed()

Check if a package is installed on the system.

**Syntax:**
```bash
phub_is_installed "package_name"
```

**Parameters:**
- `package_name` (required): Name of the package to check

**Returns:**
- Exit code 0 if package is installed
- Exit code 1 if package is not installed

**Example:**
```bash
# Simple check
if phub_is_installed "curl"; then
    echo "curl is installed"
else
    echo "curl is not installed"
fi

# Install if not present
if ! phub_is_installed "git"; then
    phub_notify "Installing git..." "info"
    phub_install_package "git"
fi

# Check multiple packages
for pkg in curl wget git; do
    if phub_is_installed "$pkg"; then
        phub_notify "$pkg: installed" "success"
    else
        phub_notify "$pkg: not installed" "info"
    fi
done
```

**Notes:**
- Uses the distribution's package manager to check
- Handles package name mapping automatically
- Fast operation (uses package manager cache)

---

## Complete Example Plugin

Here's a complete example plugin that demonstrates all API functions:

```json
{
  "name": "dev-setup",
  "version": "1.0.0",
  "description": "Development environment setup plugin",
  "author": "Your Name",
  "license": "MIT",
  "dependencies": ["bash", "jq"],
  "functions": {
    "setup_dev_env": "
      phub_notify 'Setting up development environment...' 'info'
      
      # Get distro info
      distro_info=$(phub_get_distro)
      distro_name=$(echo $distro_info | jq -r .name)
      phub_notify \"Detected: $distro_name\" 'info'
      
      # Check and install packages
      packages='git curl wget vim'
      for pkg in $packages; do
        if phub_is_installed \"$pkg\"; then
          phub_notify \"$pkg: already installed\" 'success'
        else
          phub_notify \"Installing $pkg...\" 'info'
          if phub_install_package \"$pkg\"; then
            phub_notify \"$pkg: installed\" 'success'
          else
            phub_notify \"$pkg: failed to install\" 'error'
          fi
        fi
      done
      
      # Configure git
      phub_notify 'Configuring git...' 'info'
      phub_execute_command 'git config --global color.ui auto'
      
      # Save configuration
      phub_config_set 'dev_env_setup' 'completed'
      
      phub_notify 'Development environment setup complete!' 'success'
    ",
    
    "check_status": "
      if status=$(phub_config_get 'dev_env_setup'); then
        phub_notify \"Dev environment status: $status\" 'info'
      else
        phub_notify 'Dev environment not set up yet' 'info'
      fi
    "
  },
  "menu_items": [
    {
      "label": "Setup Development Environment",
      "function": "setup_dev_env"
    },
    {
      "label": "Check Setup Status",
      "function": "check_status"
    }
  ]
}
```

## Best Practices

### 1. Error Handling

Always check return codes and handle errors gracefully:

```bash
if ! phub_install_package "package"; then
    phub_notify "Installation failed, trying alternative..." "error"
    phub_install_package "alternative-package"
fi
```

### 2. User Feedback

Provide clear feedback to users:

```bash
phub_notify "Starting long operation..." "info"
# ... do work ...
phub_notify "Operation completed!" "success"
```

### 3. Configuration Management

Use configuration to store plugin state:

```bash
# Save state
phub_config_set "myplugin_last_run" "$(date +%s)"

# Load state
if last_run=$(phub_config_get "myplugin_last_run"); then
    echo "Last run: $(date -d @$last_run)"
fi
```

### 4. Distribution Awareness

Check the distribution before running distro-specific commands:

```bash
distro_id=$(phub_get_distro | jq -r '.id')
case "$distro_id" in
    "alpine")
        phub_execute_command "apk add --no-cache package"
        ;;
    "debian"|"ubuntu")
        phub_execute_command "apt-get install -y package"
        ;;
esac
```

### 5. Dependency Checking

Check for required packages before running:

```bash
if ! phub_is_installed "jq"; then
    phub_notify "Installing required dependency: jq" "info"
    phub_install_package "jq"
fi
```

## API Validation

All API functions validate their inputs:

- Empty or missing required parameters return exit code 1
- Invalid parameter types are rejected
- Error messages are logged for debugging

Example validation:

```bash
# This will fail with error message
phub_install_package ""  # Empty package name

# This will fail with error message
phub_config_get ""  # Empty key

# This will fail with error message
phub_notify ""  # Empty message
```

## Logging

All API functions log their operations:

- `phub_notify()` - Logs all notifications
- `phub_install_package()` - Logs installation attempts and results
- `phub_execute_command()` - Logs command execution and output
- `phub_config_get/set()` - Logs configuration access
- `phub_get_distro()` - Logs distribution detection
- `phub_is_installed()` - Logs package checks

Logs are stored in `~/.cache/precoreshub/logs/`

## Security Considerations

### Command Injection

Be careful with user input in commands:

```bash
# BAD - vulnerable to injection
user_input="$1"
phub_execute_command "echo $user_input"

# GOOD - properly quoted
user_input="$1"
phub_execute_command "echo \"$user_input\""
```

### Package Installation

Only install trusted packages:

```bash
# Validate package name before installing
if [[ "$package" =~ ^[a-zA-Z0-9_-]+$ ]]; then
    phub_install_package "$package"
else
    phub_notify "Invalid package name" "error"
fi
```

### Configuration Access

Don't store sensitive data in configuration:

```bash
# BAD - storing password
phub_config_set "password" "secret123"

# GOOD - store only non-sensitive data
phub_config_set "username" "user"
```

## Troubleshooting

### API Function Not Found

If you get "command not found" errors:

1. Ensure `lib/plugin.sh` is sourced
2. Check that the plugin system is initialized
3. Verify the function name is correct

### Permission Denied

If you get permission errors:

1. Check file permissions on plugin files
2. Ensure user has sudo access for package installation
3. Verify plugin directories are writable

### Package Not Found

If package installation fails:

1. Check package name is correct for the distribution
2. Update package manager cache
3. Check package mappings in `config/package_mappings.json`

## Support

For more information:

- Plugin System Documentation: `docs/PLUGIN_SYSTEM.md`
- Plugin Development Guide: `docs/PLUGIN_DEVELOPMENT.md`
- Example Plugins: `plugins/example.phub`
- Test Suite: `tests/test_plugin_api.sh`

## Version History

### v1.0.0 (2024)
- Initial API release
- 7 core API functions
- Full input validation
- Comprehensive error handling
- Complete documentation
