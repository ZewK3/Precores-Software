# Contributing to PrecoresHub

Thank you for your interest in contributing to PrecoresHub! This document provides guidelines and instructions for contributing.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [How to Contribute](#how-to-contribute)
- [Coding Standards](#coding-standards)
- [Testing](#testing)
- [Documentation](#documentation)
- [Pull Request Process](#pull-request-process)
- [Community](#community)

## 📜 Code of Conduct

### Our Pledge

We pledge to make participation in our project a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, nationality, personal appearance, race, religion, or sexual identity and orientation.

### Our Standards

**Positive behavior includes:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism
- Focusing on what is best for the community
- Showing empathy towards other community members

**Unacceptable behavior includes:**
- Trolling, insulting/derogatory comments, and personal attacks
- Public or private harassment
- Publishing others' private information without permission
- Other conduct which could reasonably be considered inappropriate

## 🚀 Getting Started

### Prerequisites

- Bash >= 4.0
- jq >= 1.6
- fzf >= 0.30.0
- Git
- Docker (for testing)

### Fork and Clone

1. Fork the repository on GitHub
2. Clone your fork:
   ```bash
   git clone https://github.com/YOUR_USERNAME/precoreshub.git
   cd precoreshub
   ```
3. Add upstream remote:
   ```bash
   git remote add upstream https://github.com/original/precoreshub.git
   ```

## 🛠️ Development Setup

### Local Development

```bash
# Install dependencies (Debian/Ubuntu)
sudo apt install bash jq fzf git

# Install dependencies (Arch Linux)
sudo pacman -S bash jq fzf git

# Install dependencies (Fedora)
sudo dnf install bash jq fzf git

# Make script executable
chmod +x PrecoresHub.sh

# Run locally
./PrecoresHub.sh
```

### Docker Development

```bash
# Build Docker image
docker build -t precoreshub-dev -f Dockerfile.precoreshub .

# Run in Docker
docker run --rm -it -v ${PWD}:/precoreshub -w /precoreshub precoreshub-dev bash

# Inside container
./PrecoresHub.sh
```

### Project Structure

```
PrecoresHub/
├── PrecoresHub.sh          # Main script
├── lib/                    # Core libraries
│   ├── core.sh
│   ├── config.sh
│   ├── distro.sh
│   ├── package_manager.sh
│   ├── progress.sh
│   ├── cache.sh
│   ├── history.sh
│   ├── favorites.sh
│   ├── localization.sh
│   ├── error.sh
│   ├── plugin.sh
│   └── plugin_ui.sh
├── config/                 # Configuration files
├── lang/                   # Language files
├── plugins/                # System plugins
├── tests/                  # Test suite
├── docs/                   # Documentation
└── README.md
```

## 🤝 How to Contribute

### Types of Contributions

1. **Bug Reports**: Report bugs via GitHub Issues
2. **Feature Requests**: Suggest new features via GitHub Issues
3. **Code Contributions**: Submit pull requests
4. **Documentation**: Improve docs, add examples
5. **Translations**: Add new language support
6. **Plugins**: Create and share plugins
7. **Testing**: Test on different distributions

### Reporting Bugs

**Before submitting a bug report:**
- Check existing issues to avoid duplicates
- Test with the latest version
- Gather relevant information

**Bug report should include:**
- Clear, descriptive title
- Steps to reproduce
- Expected behavior
- Actual behavior
- Environment details:
  - PrecoresHub version
  - Linux distribution
  - Bash version
  - jq version
  - fzf version
- Relevant logs from `~/.cache/precoreshub/logs/`
- Screenshots (if applicable)

**Example bug report:**
```markdown
## Bug: Installation fails on Alpine Linux

**Environment:**
- PrecoresHub: v5.0.0
- Distribution: Alpine Linux 3.18
- Bash: 5.2.15
- jq: 1.6
- fzf: 0.42.0

**Steps to Reproduce:**
1. Run `./PrecoresHub.sh`
2. Select QuickInstall
3. Try to install git

**Expected:** Git should install successfully
**Actual:** Installation fails with error "package not found"

**Logs:**
```
[ERROR] Package not found: git
```

**Additional Context:**
Works fine on Arch Linux
```

### Suggesting Features

**Feature request should include:**
- Clear, descriptive title
- Problem statement (what problem does it solve?)
- Proposed solution
- Alternative solutions considered
- Additional context

**Example feature request:**
```markdown
## Feature: Add support for Snap packages

**Problem:**
Many users want to install Snap packages, but PrecoresHub only supports native package managers.

**Proposed Solution:**
Add Snap support to package_manager.sh with automatic detection.

**Alternatives:**
- Create a Snap plugin
- Add as optional feature

**Additional Context:**
Snap is widely used on Ubuntu and other distributions.
```

## 💻 Coding Standards

### Bash Style Guide

**General Rules:**
- Use 4 spaces for indentation (no tabs)
- Maximum line length: 100 characters
- Use `#!/bin/bash` shebang
- Use `set -euo pipefail` for strict mode (in functions)
- Quote all variables: `"$variable"`
- Use `[[` instead of `[` for conditionals
- Use `$(command)` instead of backticks

**Naming Conventions:**
- Functions: `snake_case`
- Variables: `UPPER_CASE` for constants, `snake_case` for locals
- Files: `snake_case.sh`

**Example:**
```bash
#!/bin/bash
# lib/example.sh - Example library

# Constants
readonly EXAMPLE_DIR="/path/to/dir"
readonly EXAMPLE_FILE="file.txt"

# Function with documentation
# Usage: example_function "arg1" "arg2"
# Returns: 0 on success, 1 on failure
example_function() {
    local arg1="$1"
    local arg2="$2"
    
    if [[ -z "$arg1" ]]; then
        log_error "example_function: arg1 is required"
        return 1
    fi
    
    # Function logic here
    log_info "Processing: $arg1"
    
    return 0
}
```

### Code Organization

**Library Structure:**
```bash
#!/bin/bash
# lib/example.sh - Brief description

# Source dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/core.sh"

# Constants
readonly CONSTANT_NAME="value"

# Global variables (if needed)
declare -g GLOBAL_VAR=""

# Public functions
public_function() {
    # Implementation
}

# Private functions (prefix with _)
_private_function() {
    # Implementation
}
```

### Error Handling

**Always handle errors:**
```bash
# Check command success
if ! some_command; then
    log_error "Command failed"
    return 1
fi

# Check file existence
if [[ ! -f "$file" ]]; then
    log_error "File not found: $file"
    return 1
fi

# Validate input
if [[ -z "$input" ]]; then
    log_error "Input is required"
    return 1
fi
```

### Logging

**Use logging functions:**
```bash
log_debug "Debug message"
log_info "Info message"
log_error "Error message"
```

### Comments

**Add comments for:**
- Complex logic
- Non-obvious code
- Function documentation
- TODOs

**Example:**
```bash
# Calculate the factorial of a number
# This uses recursion for simplicity
# TODO: Optimize for large numbers
factorial() {
    local n="$1"
    
    # Base case
    if [[ $n -le 1 ]]; then
        echo 1
        return 0
    fi
    
    # Recursive case
    local prev=$(factorial $((n - 1)))
    echo $((n * prev))
}
```

## 🧪 Testing

### Running Tests

```bash
# Run all tests
cd tests
for test in test_*.sh; do
    bash "$test"
done

# Run specific test
bash tests/test_core.sh

# Run in Docker
docker run --rm -v ${PWD}:/precoreshub -w /precoreshub precoreshub-dev bash tests/test_all.sh
```

### Writing Tests

**Test file structure:**
```bash
#!/bin/bash
# tests/test_example.sh - Test suite for example module

# Setup
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/example.sh"

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helpers
test_start() {
    echo "TEST: $1"
    ((TESTS_RUN++))
}

test_pass() {
    echo "  ✓ PASS"
    ((TESTS_PASSED++))
}

test_fail() {
    echo "  ✗ FAIL: $1"
    ((TESTS_FAILED++))
}

# Test cases
test_example_function() {
    test_start "example_function with valid input"
    
    if example_function "test"; then
        test_pass
    else
        test_fail "Function should succeed"
    fi
}

# Run tests
test_example_function

# Summary
echo ""
echo "Tests run: $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"

[[ $TESTS_FAILED -eq 0 ]] && exit 0 || exit 1
```

### Test Coverage

**Aim for:**
- 100% function coverage
- Edge cases tested
- Error conditions tested
- Integration tests for critical paths

## 📚 Documentation

### Code Documentation

**Document all public functions:**
```bash
# Install a package using the package manager
# Usage: pkg_install "package_name"
# Arguments:
#   $1 - package_name: Name of the package to install
# Returns:
#   0 on success, 1 on failure
# Example:
#   pkg_install "git"
pkg_install() {
    local package_name="$1"
    # Implementation
}
```

### User Documentation

**Update documentation when:**
- Adding new features
- Changing existing behavior
- Adding new configuration options
- Adding new commands

**Documentation files:**
- `README.md` - Main documentation
- `docs/PLUGIN_API.md` - Plugin API reference
- `docs/PLUGIN_DEVELOPMENT.md` - Plugin development guide
- `CHANGELOG.md` - Version history
- `CONTRIBUTING.md` - This file

## 🔄 Pull Request Process

### Before Submitting

1. **Create a branch:**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes:**
   - Follow coding standards
   - Add tests
   - Update documentation

3. **Test your changes:**
   ```bash
   # Run tests
   bash tests/test_all.sh
   
   # Test manually
   ./PrecoresHub.sh
   ```

4. **Commit your changes:**
   ```bash
   git add .
   git commit -m "feat: add your feature description"
   ```
   
   **Commit message format:**
   - `feat:` New feature
   - `fix:` Bug fix
   - `docs:` Documentation changes
   - `test:` Test changes
   - `refactor:` Code refactoring
   - `style:` Code style changes
   - `chore:` Maintenance tasks

5. **Push to your fork:**
   ```bash
   git push origin feature/your-feature-name
   ```

### Submitting Pull Request

1. Go to GitHub and create a pull request
2. Fill in the PR template:
   - Description of changes
   - Related issues
   - Testing done
   - Screenshots (if applicable)

**PR template:**
```markdown
## Description
Brief description of changes

## Related Issues
Fixes #123

## Changes Made
- Added feature X
- Fixed bug Y
- Updated documentation

## Testing
- [ ] All tests pass
- [ ] Tested on Alpine Linux
- [ ] Tested on Arch Linux
- [ ] Manual testing completed

## Screenshots
(if applicable)

## Checklist
- [ ] Code follows style guidelines
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
```

### Review Process

1. **Automated checks:**
   - Syntax check
   - Test suite
   - Linting

2. **Code review:**
   - Maintainer reviews code
   - Feedback provided
   - Changes requested (if needed)

3. **Approval:**
   - PR approved
   - Merged to main branch

### After Merge

1. **Update your fork:**
   ```bash
   git checkout main
   git pull upstream main
   git push origin main
   ```

2. **Delete branch:**
   ```bash
   git branch -d feature/your-feature-name
   git push origin --delete feature/your-feature-name
   ```

## 👥 Community

### Communication Channels

- **GitHub Issues**: Bug reports, feature requests
- **GitHub Discussions**: General discussions, Q&A
- **Email**: support@precoreshub.com

### Getting Help

- Check [README.md](README.md) for usage
- Search existing issues
- Ask in GitHub Discussions
- Contact maintainers

### Recognition

Contributors are recognized in:
- README.md contributors section
- Release notes
- CHANGELOG.md

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for contributing to PrecoresHub! 🎉**
