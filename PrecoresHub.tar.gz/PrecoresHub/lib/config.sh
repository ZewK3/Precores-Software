#!/bin/bash
# lib/config.sh - Configuration management for PrecoresHub
# Manages user configuration stored in ~/.config/precoreshub/config.json

# Source core utilities
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"

# Configuration file paths
readonly CONFIG_DIR="${HOME}/.config/precoreshub"
readonly CONFIG_FILE="${CONFIG_DIR}/config.json"
readonly DEFAULT_CONFIG_FILE="${SCRIPT_DIR}/config/default_config.json"

# In-memory configuration cache
declare -A CONFIG_CACHE

# Initialize configuration with defaults
# Creates config file if it doesn't exist
# Usage: config_init
# Exit codes: 0 = success, 1 = failed
config_init() {
    log_debug "Initializing configuration system..."
    
    # Ensure config directory exists
    if [[ ! -d "$CONFIG_DIR" ]]; then
        if ! mkdir -p "$CONFIG_DIR" 2>/dev/null; then
            log_error "Failed to create config directory: $CONFIG_DIR"
            return 1
        fi
        log_debug "Created config directory: $CONFIG_DIR"
    fi
    
    # If config file doesn't exist, create from defaults
    if [[ ! -f "$CONFIG_FILE" ]]; then
        log_info "Config file not found, creating from defaults..."
        if ! config_reset; then
            log_error "Failed to initialize config file"
            return 1
        fi
    fi
    
    # Load configuration into cache
    if ! config_load; then
        log_error "Failed to load configuration"
        return 1
    fi
    
    log_info "Configuration initialized successfully"
    return 0
}

# Load user configuration into memory
# Usage: config_load
# Exit codes: 0 = success, 1 = failed
config_load() {
    log_debug "Loading configuration from $CONFIG_FILE..."
    
    # Check if config file exists
    if [[ ! -f "$CONFIG_FILE" ]]; then
        log_error "Config file not found: $CONFIG_FILE"
        return 1
    fi
    
    # Read entire config into cache
    local config_json
    if ! config_json=$(read_json "$CONFIG_FILE" 2>/dev/null); then
        log_error "Failed to read config file: $CONFIG_FILE"
        return 1
    fi
    
    # Parse and cache common config values
    CONFIG_CACHE["version"]=$(echo "$config_json" | jq -r '.version // "5.0.0"')
    CONFIG_CACHE["language"]=$(echo "$config_json" | jq -r '.language // "en"')
    CONFIG_CACHE["parallel_installs"]=$(echo "$config_json" | jq -r '.parallel_installs // 3')
    CONFIG_CACHE["update_check_frequency"]=$(echo "$config_json" | jq -r '.update_check_frequency // 21600')
    CONFIG_CACHE["auto_update_check"]=$(echo "$config_json" | jq -r '.auto_update_check // true')
    CONFIG_CACHE["cache_ttl"]=$(echo "$config_json" | jq -r '.cache_ttl // 86400')
    
    # Store full JSON for complex queries
    CONFIG_CACHE["_full_json"]="$config_json"
    
    log_debug "Configuration loaded successfully"
    return 0
}

# Save current configuration to file
# Usage: config_save
# Exit codes: 0 = success, 1 = failed
config_save() {
    log_debug "Saving configuration to $CONFIG_FILE..."
    
    # Build JSON from cache
    local config_json
    config_json=$(jq -n \
        --arg version "${CONFIG_CACHE[version]}" \
        --arg language "${CONFIG_CACHE[language]}" \
        --argjson parallel_installs "${CONFIG_CACHE[parallel_installs]}" \
        --argjson update_check_frequency "${CONFIG_CACHE[update_check_frequency]}" \
        --argjson auto_update_check "${CONFIG_CACHE[auto_update_check]}" \
        --argjson cache_ttl "${CONFIG_CACHE[cache_ttl]}" \
        '{
            version: $version,
            language: $language,
            parallel_installs: $parallel_installs,
            update_check_frequency: $update_check_frequency,
            auto_update_check: $auto_update_check,
            cache_ttl: $cache_ttl,
            plugins_enabled: [],
            keyboard_shortcuts: {
                exit: "Ctrl+Q",
                home: "Ctrl+H",
                search: "Ctrl+S",
                favorites: "Ctrl+F",
                refresh: "Ctrl+R",
                history: "Ctrl+L"
            }
        }')
    
    # Write to file
    if ! write_json "$CONFIG_FILE" "$config_json" 2>/dev/null; then
        log_error "Failed to save config file: $CONFIG_FILE"
        return 1
    fi
    
    log_info "Configuration saved successfully"
    return 0
}

# Get configuration value
# Supports dot notation for nested keys (e.g., "keyboard_shortcuts.exit")
# Usage: config_get "key"
# Returns: value or empty string if not found
config_get() {
    local key="$1"
    
    if [[ -z "$key" ]]; then
        log_error "config_get: key is required"
        return 1
    fi
    
    # Check if it's a simple cached key
    if [[ -n "${CONFIG_CACHE[$key]}" ]]; then
        echo "${CONFIG_CACHE[$key]}"
        return 0
    fi
    
    # For nested keys, use jq on full JSON
    if [[ -n "${CONFIG_CACHE[_full_json]}" ]]; then
        local value
        value=$(echo "${CONFIG_CACHE[_full_json]}" | jq -r ".$key // empty" 2>/dev/null)
        if [[ -n "$value" && "$value" != "null" ]]; then
            echo "$value"
            return 0
        fi
    fi
    
    log_debug "config_get: key not found: $key"
    return 1
}

# Set configuration value
# Usage: config_set "key" "value" [--no-save]
# Exit codes: 0 = success, 1 = failed
config_set() {
    local key="$1"
    local value="$2"
    local save_flag="${3:-}"
    
    if [[ -z "$key" ]]; then
        log_error "config_set: key is required"
        return 1
    fi
    
    if [[ -z "$value" ]]; then
        log_error "config_set: value is required"
        return 1
    fi
    
    # Validate the key and value
    if ! config_validate "$key" "$value"; then
        log_error "config_set: validation failed for $key=$value"
        return 1
    fi
    
    # Update cache
    CONFIG_CACHE["$key"]="$value"
    log_debug "config_set: $key=$value"
    
    # Save to file unless --no-save flag is provided
    if [[ "$save_flag" != "--no-save" ]]; then
        if ! config_save; then
            log_error "config_set: failed to save configuration"
            return 1
        fi
    fi
    
    return 0
}

# Validate configuration value
# Usage: config_validate "key" "value"
# Exit codes: 0 = valid, 1 = invalid
config_validate() {
    local key="$1"
    local value="$2"
    
    case "$key" in
        "language")
            # Must be 2-letter language code
            if [[ ! "$value" =~ ^[a-z]{2}$ ]]; then
                log_error "Invalid language code: $value (must be 2 letters)"
                return 1
            fi
            ;;
        "parallel_installs")
            # Must be integer between 1 and 10
            if [[ ! "$value" =~ ^[0-9]+$ ]] || [[ "$value" -lt 1 ]] || [[ "$value" -gt 10 ]]; then
                log_error "Invalid parallel_installs: $value (must be 1-10)"
                return 1
            fi
            ;;
        "update_check_frequency")
            # Must be positive integer (seconds)
            if [[ ! "$value" =~ ^[0-9]+$ ]] || [[ "$value" -lt 0 ]]; then
                log_error "Invalid update_check_frequency: $value (must be >= 0)"
                return 1
            fi
            ;;
        "cache_ttl")
            # Must be positive integer (seconds)
            if [[ ! "$value" =~ ^[0-9]+$ ]] || [[ "$value" -lt 0 ]]; then
                log_error "Invalid cache_ttl: $value (must be >= 0)"
                return 1
            fi
            ;;
        "auto_update_check")
            # Must be boolean
            if [[ "$value" != "true" && "$value" != "false" ]]; then
                log_error "Invalid auto_update_check: $value (must be true or false)"
                return 1
            fi
            ;;
        *)
            # Unknown keys are allowed (for extensibility)
            log_debug "config_validate: unknown key $key, allowing"
            ;;
    esac
    
    return 0
}

# Reset configuration to defaults
# Usage: config_reset
# Exit codes: 0 = success, 1 = failed
config_reset() {
    log_info "Resetting configuration to defaults..."
    
    # Check if default config exists
    if [[ ! -f "$DEFAULT_CONFIG_FILE" ]]; then
        log_error "Default config file not found: $DEFAULT_CONFIG_FILE"
        log_info "Creating default configuration..."
        
        # Create default config inline
        local default_config='{
            "version": "5.0.0",
            "language": "en",
            "parallel_installs": 3,
            "update_check_frequency": 21600,
            "auto_update_check": true,
            "cache_ttl": 86400,
            "plugins_enabled": [],
            "keyboard_shortcuts": {
                "exit": "Ctrl+Q",
                "home": "Ctrl+H",
                "search": "Ctrl+S",
                "favorites": "Ctrl+F",
                "refresh": "Ctrl+R",
                "history": "Ctrl+L"
            }
        }'
        
        if ! write_json "$CONFIG_FILE" "$default_config" 2>/dev/null; then
            log_error "Failed to create default config"
            return 1
        fi
    else
        # Copy default config to user config
        local default_json
        if ! default_json=$(read_json "$DEFAULT_CONFIG_FILE" 2>/dev/null); then
            log_error "Failed to read default config: $DEFAULT_CONFIG_FILE"
            return 1
        fi
        
        if ! write_json "$CONFIG_FILE" "$default_json" 2>/dev/null; then
            log_error "Failed to write config file: $CONFIG_FILE"
            return 1
        fi
    fi
    
    # Reload configuration
    if ! config_load; then
        log_error "Failed to reload configuration after reset"
        return 1
    fi
    
    log_info "Configuration reset to defaults successfully"
    return 0
}
