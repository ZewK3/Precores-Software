#!/bin/bash
# lib/plugin_ui.sh - Plugin Management UI for PrecoresHub
# Provides user interface for managing plugins

# Source dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/core.sh"
source "${SCRIPT_DIR}/plugin.sh"

# Check if fzf is available
if ! command -v fzf &>/dev/null; then
    log_error "fzf is required for plugin management UI"
    FZF_AVAILABLE=false
else
    FZF_AVAILABLE=true
fi

# ============================================================================
# Plugin Management Menu
# ============================================================================

# Main plugin management menu
# Usage: plugin_menu
plugin_menu() {
    log_info "Opening plugin management menu"
    
    # Initialize plugin system
    plugin_init
    
    while true; do
        clear
        echo "========================================"
        echo "Plugin Manager"
        echo "========================================"
        echo ""
        echo "1. List All Plugins"
        echo "2. Enable Plugin"
        echo "3. Disable Plugin"
        echo "4. View Plugin Details"
        echo "5. Execute Plugin Function"
        echo "6. Check Plugin Dependencies"
        echo "7. Refresh Plugin List"
        echo "0. Back to Main Menu"
        echo ""
        read -p "Select option: " choice
        
        case "$choice" in
            1) plugin_ui_list_all ;;
            2) plugin_ui_enable ;;
            3) plugin_ui_disable ;;
            4) plugin_ui_details ;;
            5) plugin_ui_execute ;;
            6) plugin_ui_check_deps ;;
            7) plugin_ui_refresh ;;
            0) return 0 ;;
            *) 
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

# ============================================================================
# List Plugins
# ============================================================================

# List all discovered plugins
# Usage: plugin_ui_list_all
plugin_ui_list_all() {
    clear
    echo "========================================"
    echo "All Plugins"
    echo "========================================"
    echo ""
    
    # Discover plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        echo ""
        echo "Plugin directories:"
        echo "  System: $PLUGIN_DIR"
        echo "  User:   $USER_PLUGIN_DIR"
        echo ""
        read -p "Press Enter to continue..."
        return 0
    fi
    
    echo "Found $count plugin(s):"
    echo ""
    
    # Display plugins
    local index=0
    while [[ $index -lt $count ]]; do
        local plugin=$(echo "$plugins" | jq -r ".[$index]")
        local name=$(echo "$plugin" | jq -r '.name')
        local type=$(echo "$plugin" | jq -r '.type')
        local path=$(echo "$plugin" | jq -r '.path')
        
        # Check if loaded
        local loaded_status="[ ]"
        if plugin_is_loaded "$name"; then
            loaded_status="[L]"
        fi
        
        # Check if enabled
        local enabled_status="[ ]"
        if plugin_is_enabled "$name"; then
            enabled_status="[E]"
        fi
        
        # Get plugin metadata
        local version=$(jq -r '.version // "unknown"' "$path" 2>/dev/null)
        local description=$(jq -r '.description // "No description"' "$path" 2>/dev/null)
        
        echo "$((index + 1)). $name (v$version) [$type]"
        echo "   Status: Loaded=$loaded_status Enabled=$enabled_status"
        echo "   Description: $description"
        echo ""
        
        ((index++))
    done
    
    echo "Legend: [L]=Loaded, [E]=Enabled"
    echo ""
    read -p "Press Enter to continue..."
}

# ============================================================================
# Enable Plugin
# ============================================================================

# Enable a plugin
# Usage: plugin_ui_enable
plugin_ui_enable() {
    clear
    echo "========================================"
    echo "Enable Plugin"
    echo "========================================"
    echo ""
    
    # Get list of plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Use fzf if available, otherwise show numbered list
    if [[ "$FZF_AVAILABLE" == true ]]; then
        local plugin_name=$(echo "$plugins" | jq -r '.[].name' | fzf --prompt="Select plugin to enable: " --height=40%)
        
        if [[ -z "$plugin_name" ]]; then
            echo "No plugin selected."
            sleep 1
            return 1
        fi
    else
        # Show numbered list
        echo "Available plugins:"
        echo ""
        local index=0
        while [[ $index -lt $count ]]; do
            local name=$(echo "$plugins" | jq -r ".[$index].name")
            echo "$((index + 1)). $name"
            ((index++))
        done
        echo ""
        read -p "Enter plugin number: " selection
        
        if [[ ! "$selection" =~ ^[0-9]+$ ]] || [[ "$selection" -lt 1 ]] || [[ "$selection" -gt "$count" ]]; then
            echo "Invalid selection."
            sleep 1
            return 1
        fi
        
        plugin_name=$(echo "$plugins" | jq -r ".[$(($selection - 1))].name")
    fi
    
    # Check if already enabled
    if plugin_is_enabled "$plugin_name"; then
        echo ""
        echo "Plugin '$plugin_name' is already enabled."
        read -p "Press Enter to continue..."
        return 0
    fi
    
    # Check dependencies
    echo ""
    echo "Checking dependencies..."
    if ! plugin_check_dependencies "$plugin_name" 2>/dev/null; then
        echo ""
        echo "Warning: Some dependencies are missing."
        read -p "Continue anyway? (y/n): " confirm
        if [[ "$confirm" != "y" ]]; then
            echo "Cancelled."
            sleep 1
            return 1
        fi
    fi
    
    # Enable plugin
    echo ""
    echo "Enabling plugin '$plugin_name'..."
    if plugin_enable "$plugin_name"; then
        echo "✓ Plugin enabled successfully!"
    else
        echo "✗ Failed to enable plugin."
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# ============================================================================
# Disable Plugin
# ============================================================================

# Disable a plugin
# Usage: plugin_ui_disable
plugin_ui_disable() {
    clear
    echo "========================================"
    echo "Disable Plugin"
    echo "========================================"
    echo ""
    
    # Get list of enabled plugins
    local enabled=$(plugin_list "enabled")
    local count=$(echo "$enabled" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No enabled plugins."
        read -p "Press Enter to continue..."
        return 0
    fi
    
    # Use fzf if available
    if [[ "$FZF_AVAILABLE" == true ]]; then
        local plugin_name=$(echo "$enabled" | jq -r '.[]' | fzf --prompt="Select plugin to disable: " --height=40%)
        
        if [[ -z "$plugin_name" ]]; then
            echo "No plugin selected."
            sleep 1
            return 1
        fi
    else
        # Show numbered list
        echo "Enabled plugins:"
        echo ""
        local index=0
        while [[ $index -lt $count ]]; do
            local name=$(echo "$enabled" | jq -r ".[$index]")
            echo "$((index + 1)). $name"
            ((index++))
        done
        echo ""
        read -p "Enter plugin number: " selection
        
        if [[ ! "$selection" =~ ^[0-9]+$ ]] || [[ "$selection" -lt 1 ]] || [[ "$selection" -gt "$count" ]]; then
            echo "Invalid selection."
            sleep 1
            return 1
        fi
        
        plugin_name=$(echo "$enabled" | jq -r ".[$(($selection - 1))]")
    fi
    
    # Disable plugin
    echo ""
    echo "Disabling plugin '$plugin_name'..."
    if plugin_disable "$plugin_name"; then
        echo "✓ Plugin disabled successfully!"
    else
        echo "✗ Failed to disable plugin."
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# ============================================================================
# View Plugin Details
# ============================================================================

# View detailed information about a plugin
# Usage: plugin_ui_details
plugin_ui_details() {
    clear
    echo "========================================"
    echo "Plugin Details"
    echo "========================================"
    echo ""
    
    # Get list of plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Select plugin
    if [[ "$FZF_AVAILABLE" == true ]]; then
        local plugin_name=$(echo "$plugins" | jq -r '.[].name' | fzf --prompt="Select plugin: " --height=40%)
        
        if [[ -z "$plugin_name" ]]; then
            echo "No plugin selected."
            sleep 1
            return 1
        fi
    else
        echo "Available plugins:"
        echo ""
        local index=0
        while [[ $index -lt $count ]]; do
            local name=$(echo "$plugins" | jq -r ".[$index].name")
            echo "$((index + 1)). $name"
            ((index++))
        done
        echo ""
        read -p "Enter plugin number: " selection
        
        if [[ ! "$selection" =~ ^[0-9]+$ ]] || [[ "$selection" -lt 1 ]] || [[ "$selection" -gt "$count" ]]; then
            echo "Invalid selection."
            sleep 1
            return 1
        fi
        
        plugin_name=$(echo "$plugins" | jq -r ".[$(($selection - 1))].name")
    fi
    
    # Get plugin metadata
    local metadata=$(plugin_get_metadata "$plugin_name")
    
    if [[ -z "$metadata" ]]; then
        echo "Failed to load plugin metadata."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Display details
    clear
    echo "========================================"
    echo "Plugin: $plugin_name"
    echo "========================================"
    echo ""
    
    echo "Name:        $(echo "$metadata" | jq -r '.name // "N/A"')"
    echo "Version:     $(echo "$metadata" | jq -r '.version // "N/A"')"
    echo "Author:      $(echo "$metadata" | jq -r '.author // "N/A"')"
    echo "License:     $(echo "$metadata" | jq -r '.license // "N/A"')"
    echo "Description: $(echo "$metadata" | jq -r '.description // "N/A"')"
    echo ""
    
    # Status
    echo "Status:"
    if plugin_is_loaded "$plugin_name"; then
        echo "  Loaded:  Yes"
    else
        echo "  Loaded:  No"
    fi
    
    if plugin_is_enabled "$plugin_name"; then
        echo "  Enabled: Yes"
    else
        echo "  Enabled: No"
    fi
    echo ""
    
    # Dependencies
    local deps=$(echo "$metadata" | jq -r '.dependencies // [] | .[]' 2>/dev/null)
    if [[ -n "$deps" ]]; then
        echo "Dependencies:"
        while IFS= read -r dep; do
            if command -v "$dep" &>/dev/null; then
                echo "  ✓ $dep"
            else
                echo "  ✗ $dep (missing)"
            fi
        done <<< "$deps"
        echo ""
    fi
    
    # Functions
    local functions=$(echo "$metadata" | jq -r '.functions // {} | keys | .[]' 2>/dev/null)
    if [[ -n "$functions" ]]; then
        echo "Available Functions:"
        while IFS= read -r func; do
            echo "  - $func"
        done <<< "$functions"
        echo ""
    fi
    
    # Menu items
    local menu_items=$(echo "$metadata" | jq -r '.menu_items // [] | length' 2>/dev/null)
    if [[ "$menu_items" -gt 0 ]]; then
        echo "Menu Items: $menu_items"
        echo ""
    fi
    
    read -p "Press Enter to continue..."
}

# ============================================================================
# Execute Plugin Function
# ============================================================================

# Execute a plugin function
# Usage: plugin_ui_execute
plugin_ui_execute() {
    clear
    echo "========================================"
    echo "Execute Plugin Function"
    echo "========================================"
    echo ""
    
    # Get list of enabled plugins
    local enabled=$(plugin_list "enabled")
    local count=$(echo "$enabled" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No enabled plugins."
        echo "Please enable a plugin first."
        read -p "Press Enter to continue..."
        return 0
    fi
    
    # Select plugin
    if [[ "$FZF_AVAILABLE" == true ]]; then
        local plugin_name=$(echo "$enabled" | jq -r '.[]' | fzf --prompt="Select plugin: " --height=40%)
        
        if [[ -z "$plugin_name" ]]; then
            echo "No plugin selected."
            sleep 1
            return 1
        fi
    else
        echo "Enabled plugins:"
        echo ""
        local index=0
        while [[ $index -lt $count ]]; do
            local name=$(echo "$enabled" | jq -r ".[$index]")
            echo "$((index + 1)). $name"
            ((index++))
        done
        echo ""
        read -p "Enter plugin number: " selection
        
        if [[ ! "$selection" =~ ^[0-9]+$ ]] || [[ "$selection" -lt 1 ]] || [[ "$selection" -gt "$count" ]]; then
            echo "Invalid selection."
            sleep 1
            return 1
        fi
        
        plugin_name=$(echo "$enabled" | jq -r ".[$(($selection - 1))]")
    fi
    
    # Get plugin functions
    local metadata=$(plugin_get_metadata "$plugin_name")
    local functions=$(echo "$metadata" | jq -r '.functions // {} | keys | .[]' 2>/dev/null)
    
    if [[ -z "$functions" ]]; then
        echo ""
        echo "No functions available in this plugin."
        read -p "Press Enter to continue..."
        return 0
    fi
    
    # Select function
    if [[ "$FZF_AVAILABLE" == true ]]; then
        local function_name=$(echo "$functions" | fzf --prompt="Select function: " --height=40%)
        
        if [[ -z "$function_name" ]]; then
            echo "No function selected."
            sleep 1
            return 1
        fi
    else
        echo ""
        echo "Available functions:"
        echo ""
        local func_array=()
        while IFS= read -r func; do
            func_array+=("$func")
        done <<< "$functions"
        
        for i in "${!func_array[@]}"; do
            echo "$((i + 1)). ${func_array[$i]}"
        done
        echo ""
        read -p "Enter function number: " selection
        
        if [[ ! "$selection" =~ ^[0-9]+$ ]] || [[ "$selection" -lt 1 ]] || [[ "$selection" -gt "${#func_array[@]}" ]]; then
            echo "Invalid selection."
            sleep 1
            return 1
        fi
        
        function_name="${func_array[$((selection - 1))]}"
    fi
    
    # Execute function
    echo ""
    echo "========================================"
    echo "Executing: $plugin_name.$function_name"
    echo "========================================"
    echo ""
    
    if plugin_execute "$plugin_name" "$function_name"; then
        echo ""
        echo "========================================"
        echo "✓ Function executed successfully!"
        echo "========================================"
    else
        echo ""
        echo "========================================"
        echo "✗ Function execution failed!"
        echo "========================================"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# ============================================================================
# Check Plugin Dependencies
# ============================================================================

# Check dependencies for a plugin
# Usage: plugin_ui_check_deps
plugin_ui_check_deps() {
    clear
    echo "========================================"
    echo "Check Plugin Dependencies"
    echo "========================================"
    echo ""
    
    # Get list of plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Select plugin
    if [[ "$FZF_AVAILABLE" == true ]]; then
        local plugin_name=$(echo "$plugins" | jq -r '.[].name' | fzf --prompt="Select plugin: " --height=40%)
        
        if [[ -z "$plugin_name" ]]; then
            echo "No plugin selected."
            sleep 1
            return 1
        fi
    else
        echo "Available plugins:"
        echo ""
        local index=0
        while [[ $index -lt $count ]]; do
            local name=$(echo "$plugins" | jq -r ".[$index].name")
            echo "$((index + 1)). $name"
            ((index++))
        done
        echo ""
        read -p "Enter plugin number: " selection
        
        if [[ ! "$selection" =~ ^[0-9]+$ ]] || [[ "$selection" -lt 1 ]] || [[ "$selection" -gt "$count" ]]; then
            echo "Invalid selection."
            sleep 1
            return 1
        fi
        
        plugin_name=$(echo "$plugins" | jq -r ".[$(($selection - 1))].name")
    fi
    
    # Check dependencies
    echo ""
    echo "Checking dependencies for '$plugin_name'..."
    echo ""
    
    local metadata=$(plugin_get_metadata "$plugin_name")
    local deps=$(echo "$metadata" | jq -r '.dependencies // [] | .[]' 2>/dev/null)
    
    if [[ -z "$deps" ]]; then
        echo "No dependencies required."
    else
        local all_satisfied=true
        while IFS= read -r dep; do
            if command -v "$dep" &>/dev/null; then
                echo "✓ $dep (installed)"
            else
                echo "✗ $dep (missing)"
                all_satisfied=false
            fi
        done <<< "$deps"
        
        echo ""
        if $all_satisfied; then
            echo "✓ All dependencies satisfied!"
        else
            echo "✗ Some dependencies are missing."
            echo ""
            echo "Please install missing dependencies before enabling this plugin."
        fi
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# ============================================================================
# Refresh Plugin List
# ============================================================================

# Refresh plugin list
# Usage: plugin_ui_refresh
plugin_ui_refresh() {
    clear
    echo "========================================"
    echo "Refresh Plugin List"
    echo "========================================"
    echo ""
    
    echo "Refreshing plugin list..."
    
    # Re-initialize plugin system
    plugin_init
    
    # Discover plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    echo "✓ Found $count plugin(s)"
    echo ""
    
    sleep 1
}

# ============================================================================
# Plugin Menu Integration
# ============================================================================

# Show plugin menu items in main menu
# Usage: plugin_ui_show_menu_items
plugin_ui_show_menu_items() {
    local enabled=$(plugin_list "enabled")
    local count=$(echo "$enabled" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        return 0
    fi
    
    echo ""
    echo "--- Plugin Menu Items ---"
    echo ""
    
    # For each enabled plugin
    local index=0
    while [[ $index -lt $count ]]; do
        local plugin_name=$(echo "$enabled" | jq -r ".[$index]")
        local metadata=$(plugin_get_metadata "$plugin_name")
        local menu_items=$(echo "$metadata" | jq -r '.menu_items // [] | .[]' 2>/dev/null)
        
        if [[ -n "$menu_items" ]]; then
            echo "[$plugin_name]"
            while IFS= read -r item; do
                local label=$(echo "$item" | jq -r '.label')
                echo "  $label"
            done <<< "$menu_items"
            echo ""
        fi
        
        ((index++))
    done
}
