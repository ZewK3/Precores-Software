#!/bin/bash
# lib/plugin_ui.sh - Plugin Management UI for PrecoresHub
# Provides user interface for managing plugins with fzf

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"
source "${SCRIPT_DIR}/lib/plugin.sh"

# ============================================================================
# Plugin Management Menu
# ============================================================================

# Main plugin management menu with fzf
# Usage: plugin_menu
plugin_menu() {
    log_info "Opening plugin management menu"
    
    # Initialize plugin system
    plugin_init
    
    while true; do
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║         PLUGIN MANAGER - EXTENSIONS                  ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#cba6f7,fg+:#cdd6f4,bg+:#313244,hl+:#cba6f7,info:#cba6f7,prompt:#cba6f7,pointer:#cba6f7,marker:#a6e3a1,spinner:#f5e0dc,header:#cba6f7"
[01] List All Plugins       - View all discovered plugins
[02] Enable Plugin          - Activate a plugin
[03] Disable Plugin         - Deactivate a plugin
[04] View Plugin Details    - Show plugin information
[05] Execute Function       - Run plugin function
[06] Check Dependencies     - Verify plugin requirements
[07] Refresh Plugin List    - Rescan plugin directories
[00] Back to Main Menu      - Return
EOF
)
        
        [[ -z "$choice" ]] && return 0
        
        case "${choice:1:2}" in
            01) plugin_ui_list_all ;;
            02) plugin_ui_enable ;;
            03) plugin_ui_disable ;;
            04) plugin_ui_details ;;
            05) plugin_ui_execute ;;
            06) plugin_ui_check_deps ;;
            07) plugin_ui_refresh ;;
            00) return 0 ;;
        esac
    done
}

# ============================================================================
# List Plugins
# ============================================================================

# List all discovered plugins with fzf preview
# Usage: plugin_ui_list_all
plugin_ui_list_all() {
    log_info "Listing all plugins"
    
    # Discover plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=40% --border=rounded --prompt="No plugins found > " --header="╔══════════════════════════════════════════════════════════╗
║                  NO PLUGINS FOUND                    ║
╚══════════════════════════════════════════════════════════╝

Plugin directories:
  System: $PLUGIN_DIR
  User:   $USER_PLUGIN_DIR
" --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#f38ba8,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#f38ba8"
[OK] Back to Plugin Menu
EOF
)
        return 0
    fi
    
    # Build plugin list with status
    local plugin_list=""
    local index=0
    while [[ $index -lt $count ]]; do
        local plugin=$(echo "$plugins" | jq -r ".[$index]")
        local name=$(echo "$plugin" | jq -r '.name')
        local type=$(echo "$plugin" | jq -r '.type')
        local path=$(echo "$plugin" | jq -r '.path')
        
        # Get metadata
        local version=$(jq -r '.version // "unknown"' "$path" 2>/dev/null)
        local description=$(jq -r '.description // "No description"' "$path" 2>/dev/null)
        
        # Status indicators
        local status=""
        if plugin_is_loaded "$name"; then
            status="${status}[L]"
        fi
        if plugin_is_enabled "$name"; then
            status="${status}[E]"
        fi
        [[ -z "$status" ]] && status="[ ]"
        
        plugin_list="${plugin_list}${status} ${name} (v${version}) - ${description}\n"
        ((index++))
    done
    
    # Show with fzf
    echo -e "$plugin_list" | fzf --ansi --reverse --height=90% --border=rounded \
        --prompt="Plugins > " \
        --header="╔══════════════════════════════════════════════════════════╗
║              ALL PLUGINS ($count found)                  ║
╚══════════════════════════════════════════════════════════╝

Legend: [L]=Loaded [E]=Enabled
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#cba6f7,fg+:#cdd6f4,bg+:#313244,hl+:#cba6f7,info:#cba6f7,prompt:#cba6f7,pointer:#cba6f7,marker:#a6e3a1,spinner:#f5e0dc,header:#cba6f7"
}

# ============================================================================
# Enable Plugin
# ============================================================================

# Enable a plugin with fzf selection
# Usage: plugin_ui_enable
plugin_ui_enable() {
    log_info "Enabling plugin"
    
    # Get list of plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        sleep 2
        return 1
    fi
    
    # Build selection list
    local plugin_list=""
    local index=0
    while [[ $index -lt $count ]]; do
        local name=$(echo "$plugins" | jq -r ".[$index].name")
        local path=$(echo "$plugins" | jq -r ".[$index].path")
        local version=$(jq -r '.version // "unknown"' "$path" 2>/dev/null)
        local description=$(jq -r '.description // "No description"' "$path" 2>/dev/null)
        
        # Skip if already enabled
        if plugin_is_enabled "$name"; then
            plugin_list="${plugin_list}[✓] ${name} (v${version}) - Already enabled\n"
        else
            plugin_list="${plugin_list}[ ] ${name} (v${version}) - ${description}\n"
        fi
        ((index++))
    done
    
    # Select plugin
    local selection=$(echo -e "$plugin_list" | fzf --ansi --reverse --height=80% --border=rounded \
        --prompt="Select plugin to enable > " \
        --header="╔══════════════════════════════════════════════════════════╗
║                   ENABLE PLUGIN                      ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1")
    
    [[ -z "$selection" ]] && return 0
    
    # Extract plugin name
    local plugin_name=$(echo "$selection" | sed -E 's/^\[.\] ([^ ]+).*/\1/')
    
    # Check if already enabled
    if plugin_is_enabled "$plugin_name"; then
        log_info "Plugin '$plugin_name' is already enabled"
        sleep 2
        return 0
    fi
    
    # Check dependencies
    if ! plugin_check_dependencies "$plugin_name" 2>/dev/null; then
        local confirm=$(cat <<EOF | fzf --ansi --reverse --height=40% --border=rounded --prompt="Continue? > " --header="╔══════════════════════════════════════════════════════════╗
║                     WARNING                          ║
╚══════════════════════════════════════════════════════════╝

Some dependencies are missing for '$plugin_name'
" --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af"
[Yes] Continue anyway
[No] Cancel
EOF
)
        [[ "$confirm" != "[Yes]"* ]] && return 0
    fi
    
    # Enable plugin
    if plugin_enable "$plugin_name"; then
        log_success "Plugin '$plugin_name' enabled successfully"
    else
        log_error "Failed to enable plugin '$plugin_name'"
    fi
    sleep 2
}

# ============================================================================
# Disable Plugin
# ============================================================================

# Disable a plugin with fzf selection
# Usage: plugin_ui_disable
plugin_ui_disable() {
    log_info "Disabling plugin"
    
    # Get list of enabled plugins
    local enabled=$(plugin_list "enabled")
    local count=$(echo "$enabled" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=40% --border=rounded --prompt="No enabled plugins > " --header="╔══════════════════════════════════════════════════════════╗
║              NO ENABLED PLUGINS                      ║
╚══════════════════════════════════════════════════════════╝
" --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#f38ba8,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#f38ba8"
[OK] Back to Plugin Menu
EOF
)
        return 0
    fi
    
    # Build selection list
    local plugin_list=""
    local index=0
    while [[ $index -lt $count ]]; do
        local name=$(echo "$enabled" | jq -r ".[$index]")
        local metadata=$(plugin_get_metadata "$name")
        local version=$(echo "$metadata" | jq -r '.version // "unknown"')
        local description=$(echo "$metadata" | jq -r '.description // "No description"')
        
        plugin_list="${plugin_list}[✓] ${name} (v${version}) - ${description}\n"
        ((index++))
    done
    
    # Select plugin
    local selection=$(echo -e "$plugin_list" | fzf --ansi --reverse --height=80% --border=rounded \
        --prompt="Select plugin to disable > " \
        --header="╔══════════════════════════════════════════════════════════╗
║                  DISABLE PLUGIN                      ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#f38ba8,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#f38ba8")
    
    [[ -z "$selection" ]] && return 0
    
    # Extract plugin name
    local plugin_name=$(echo "$selection" | sed -E 's/^\[.\] ([^ ]+).*/\1/')
    
    # Disable plugin
    if plugin_disable "$plugin_name"; then
        log_success "Plugin '$plugin_name' disabled successfully"
    else
        log_error "Failed to disable plugin '$plugin_name'"
    fi
    sleep 2
}

# ============================================================================
# View Plugin Details
# ============================================================================

# View detailed information about a plugin
# Usage: plugin_ui_details
plugin_ui_details() {
    log_info "Viewing plugin details"
    
    # Get list of plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        sleep 2
        return 1
    fi
    
    # Build selection list
    local plugin_list=""
    local index=0
    while [[ $index -lt $count ]]; do
        local name=$(echo "$plugins" | jq -r ".[$index].name")
        local path=$(echo "$plugins" | jq -r ".[$index].path")
        local version=$(jq -r '.version // "unknown"' "$path" 2>/dev/null)
        
        plugin_list="${plugin_list}${name} (v${version})\n"
        ((index++))
    done
    
    # Select plugin
    local selection=$(echo -e "$plugin_list" | fzf --ansi --reverse --height=80% --border=rounded \
        --prompt="Select plugin > " \
        --header="╔══════════════════════════════════════════════════════════╗
║                 PLUGIN DETAILS                       ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#89b4fa,fg+:#cdd6f4,bg+:#313244,hl+:#89b4fa,info:#cba6f7,prompt:#89b4fa,pointer:#89b4fa,marker:#a6e3a1,spinner:#f5e0dc,header:#89b4fa")
    
    [[ -z "$selection" ]] && return 0
    
    # Extract plugin name
    local plugin_name=$(echo "$selection" | sed -E 's/^([^ ]+).*/\1/')
    
    # Get plugin metadata
    local metadata=$(plugin_get_metadata "$plugin_name")
    
    if [[ -z "$metadata" ]]; then
        log_error "Failed to load plugin metadata"
        sleep 2
        return 1
    fi
    
    # Build details view
    local details="╔══════════════════════════════════════════════════════════╗
║              PLUGIN: $plugin_name
╚══════════════════════════════════════════════════════════╝

Name:        $(echo "$metadata" | jq -r '.name // "N/A"')
Version:     $(echo "$metadata" | jq -r '.version // "N/A"')
Author:      $(echo "$metadata" | jq -r '.author // "N/A"')
License:     $(echo "$metadata" | jq -r '.license // "N/A"')
Description: $(echo "$metadata" | jq -r '.description // "N/A"')

Status:
"
    
    if plugin_is_loaded "$plugin_name"; then
        details="${details}  Loaded:  ✓ Yes\n"
    else
        details="${details}  Loaded:  ✗ No\n"
    fi
    
    if plugin_is_enabled "$plugin_name"; then
        details="${details}  Enabled: ✓ Yes\n"
    else
        details="${details}  Enabled: ✗ No\n"
    fi
    
    # Dependencies
    local deps=$(echo "$metadata" | jq -r '.dependencies // [] | .[]' 2>/dev/null)
    if [[ -n "$deps" ]]; then
        details="${details}\nDependencies:\n"
        while IFS= read -r dep; do
            if command -v "$dep" &>/dev/null; then
                details="${details}  ✓ $dep\n"
            else
                details="${details}  ✗ $dep (missing)\n"
            fi
        done <<< "$deps"
    fi
    
    # Functions
    local functions=$(echo "$metadata" | jq -r '.functions // {} | keys | .[]' 2>/dev/null)
    if [[ -n "$functions" ]]; then
        details="${details}\nAvailable Functions:\n"
        while IFS= read -r func; do
            details="${details}  - $func\n"
        done <<< "$functions"
    fi
    
    # Show details
    echo -e "$details" | fzf --ansi --reverse --height=90% --border=rounded \
        --prompt="Press ESC to return > " \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#89b4fa,fg+:#cdd6f4,bg+:#313244,hl+:#89b4fa,info:#cba6f7,prompt:#89b4fa,pointer:#89b4fa,marker:#a6e3a1,spinner:#f5e0dc,header:#89b4fa"
}

# ============================================================================
# Execute Plugin Function
# ============================================================================

# Execute a plugin function
# Usage: plugin_ui_execute
plugin_ui_execute() {
    log_info "Executing plugin function"
    
    # Get list of enabled plugins
    local enabled=$(plugin_list "enabled")
    local count=$(echo "$enabled" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=40% --border=rounded --prompt="No enabled plugins > " --header="╔══════════════════════════════════════════════════════════╗
║              NO ENABLED PLUGINS                      ║
╚══════════════════════════════════════════════════════════╝

Please enable a plugin first.
" --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#f38ba8,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#f38ba8"
[OK] Back to Plugin Menu
EOF
)
        return 0
    fi
    
    # Select plugin
    local plugin_list=""
    local index=0
    while [[ $index -lt $count ]]; do
        local name=$(echo "$enabled" | jq -r ".[$index]")
        plugin_list="${plugin_list}${name}\n"
        ((index++))
    done
    
    local plugin_name=$(echo -e "$plugin_list" | fzf --ansi --reverse --height=60% --border=rounded \
        --prompt="Select plugin > " \
        --header="╔══════════════════════════════════════════════════════════╗
║            EXECUTE PLUGIN FUNCTION                   ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1")
    
    [[ -z "$plugin_name" ]] && return 0
    
    # Get plugin functions
    local metadata=$(plugin_get_metadata "$plugin_name")
    local functions=$(echo "$metadata" | jq -r '.functions // {} | keys | .[]' 2>/dev/null)
    
    if [[ -z "$functions" ]]; then
        log_error "No functions available in this plugin"
        sleep 2
        return 0
    fi
    
    # Select function
    local function_name=$(echo "$functions" | fzf --ansi --reverse --height=60% --border=rounded \
        --prompt="Select function > " \
        --header="╔══════════════════════════════════════════════════════════╗
║              PLUGIN: $plugin_name
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1")
    
    [[ -z "$function_name" ]] && return 0
    
    # Execute function
    clear
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║         Executing: $plugin_name.$function_name"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    if plugin_execute "$plugin_name" "$function_name"; then
        echo ""
        echo "✓ Function executed successfully!"
    else
        echo ""
        echo "✗ Function execution failed!"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# ============================================================================
# Check Plugin Dependencies
# ============================================================================

# Check dependencies for a plugin
# Usage: plugin_ui_check_deps
plugin_ui_check_deps() {
    log_info "Checking plugin dependencies"
    
    # Get list of plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        echo "No plugins found."
        sleep 2
        return 1
    fi
    
    # Build selection list
    local plugin_list=""
    local index=0
    while [[ $index -lt $count ]]; do
        local name=$(echo "$plugins" | jq -r ".[$index].name")
        plugin_list="${plugin_list}${name}\n"
        ((index++))
    done
    
    # Select plugin
    local plugin_name=$(echo -e "$plugin_list" | fzf --ansi --reverse --height=60% --border=rounded \
        --prompt="Select plugin > " \
        --header="╔══════════════════════════════════════════════════════════╗
║           CHECK PLUGIN DEPENDENCIES                  ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af")
    
    [[ -z "$plugin_name" ]] && return 0
    
    # Check dependencies
    local metadata=$(plugin_get_metadata "$plugin_name")
    local deps=$(echo "$metadata" | jq -r '.dependencies // [] | .[]' 2>/dev/null)
    
    local dep_status="╔══════════════════════════════════════════════════════════╗
║         Dependencies for: $plugin_name
╚══════════════════════════════════════════════════════════╝

"
    
    if [[ -z "$deps" ]]; then
        dep_status="${dep_status}✓ No dependencies required.\n"
    else
        local all_satisfied=true
        while IFS= read -r dep; do
            if command -v "$dep" &>/dev/null; then
                dep_status="${dep_status}✓ $dep (installed)\n"
            else
                dep_status="${dep_status}✗ $dep (missing)\n"
                all_satisfied=false
            fi
        done <<< "$deps"
        
        dep_status="${dep_status}\n"
        if $all_satisfied; then
            dep_status="${dep_status}✓ All dependencies satisfied!\n"
        else
            dep_status="${dep_status}✗ Some dependencies are missing.\n"
        fi
    fi
    
    # Show status
    echo -e "$dep_status" | fzf --ansi --reverse --height=70% --border=rounded \
        --prompt="Press ESC to return > " \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af"
}

# ============================================================================
# Refresh Plugin List
# ============================================================================

# Refresh plugin list
# Usage: plugin_ui_refresh
plugin_ui_refresh() {
    log_info "Refreshing plugin list"
    
    # Re-initialize plugin system
    plugin_init
    
    # Discover plugins
    local plugins=$(plugin_discover)
    local count=$(echo "$plugins" | jq 'length')
    
    log_success "Found $count plugin(s)"
    sleep 2
}

# ============================================================================
# Plugin Menu Integration
# ============================================================================

# Show plugin menu items in main menu
# Usage: plugin_ui_show_menu_items
plugin_ui_show_menu_items() {
    local enabled=$(plugin_list "enabled")
    local count=$(echo "$enabled" | jq 'length')
    
    if [[ "$count" -eq 0 ]]; then
        return 0
    fi
    
    # For each enabled plugin, show menu items
    local index=0
    while [[ $index -lt $count ]]; do
        local plugin_name=$(echo "$enabled" | jq -r ".[$index]")
        local metadata=$(plugin_get_metadata "$plugin_name")
        local menu_items=$(echo "$metadata" | jq -r '.menu_items // [] | .[]' 2>/dev/null)
        
        if [[ -n "$menu_items" ]]; then
            while IFS= read -r item; do
                local label=$(echo "$item" | jq -r '.label')
                echo "[$plugin_name] $label"
            done <<< "$menu_items"
        fi
        
        ((index++))
    done
}
