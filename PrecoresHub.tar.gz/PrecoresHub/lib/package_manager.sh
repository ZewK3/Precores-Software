#!/bin/bash
# lib/package_manager.sh - Package manager adapter for PrecoresHub
# Provides unified interface for all package managers

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"
source "${SCRIPT_DIR}/lib/distro.sh"

# Package mappings configuration
readonly PACKAGE_MAPPINGS="${SCRIPT_DIR}/config/package_mappings.json"

# Resolve package name for current distribution
# Usage: _resolve_package_name "docker"
# Returns: distribution-specific package name(s)
_resolve_package_name() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "_resolve_package_name: app_name is required"
        return 1
    fi
    
    # Check if mappings file exists
    if [[ ! -f "$PACKAGE_MAPPINGS" ]]; then
        log_error "Package mappings file not found: $PACKAGE_MAPPINGS"
        return 1
    fi
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        log_error "Distribution not detected. Run detect_distro first."
        return 1
    fi
    
    # Try to get distro-specific mapping
    local packages
    packages=$(read_json "$PACKAGE_MAPPINGS" ".${app_name}.${DETECTED_DISTRO}[]" 2>/dev/null)
    
    # If not found, try default mapping
    if [[ -z "$packages" || "$packages" == "null" ]]; then
        packages=$(read_json "$PACKAGE_MAPPINGS" ".${app_name}.default[]" 2>/dev/null)
    fi
    
    # If still not found, use app_name as-is
    if [[ -z "$packages" || "$packages" == "null" ]]; then
        log_debug "No mapping found for $app_name, using as-is"
        echo "$app_name"
        return 0
    fi
    
    echo "$packages"
    return 0
}

# Install package(s)
# Usage: pkg_install "docker" or pkg_install "docker nginx"
# Exit codes: 0 = success, 1 = failed
pkg_install() {
    local app_names="$@"
    local show_progress=true
    
    # Check if NO_PROGRESS is set (for nested calls)
    if [[ "$NO_PROGRESS" == "1" ]]; then
        show_progress=false
    fi
    
    if [[ -z "$app_names" ]]; then
        log_error "pkg_install: at least one package name is required"
        return 1
    fi
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Get install command
    local install_cmd
    if ! install_cmd=$(get_package_manager_command "install"); then
        log_error "Failed to get install command"
        return 1
    fi
    
    # Resolve all package names
    local resolved_packages=""
    for app_name in $app_names; do
        local packages
        if ! packages=$(_resolve_package_name "$app_name"); then
            log_error "Failed to resolve package name: $app_name"
            return 1
        fi
        
        # Handle empty package list (not available on this distro)
        if [[ -z "$packages" ]]; then
            log_error "Package $app_name is not available on $DETECTED_DISTRO_NAME"
            continue
        fi
        
        resolved_packages="$resolved_packages $packages"
    done
    
    # Trim whitespace
    resolved_packages=$(echo "$resolved_packages" | xargs)
    
    if [[ -z "$resolved_packages" ]]; then
        log_error "No packages to install"
        return 1
    fi
    
    log_info "Installing packages: $resolved_packages"
    log_debug "Command: $install_cmd $resolved_packages"
    
    # Start progress tracking if enabled
    if [[ "$show_progress" == "true" ]] && command -v progress_start &>/dev/null; then
        progress_start "Installing $resolved_packages"
    fi
    
    # Execute install command
    local result=0
    if eval "$install_cmd $resolved_packages"; then
        log_info "Successfully installed: $resolved_packages"
        result=0
        
        # Complete progress with success
        if [[ "$show_progress" == "true" ]] && command -v progress_complete &>/dev/null; then
            progress_complete "success"
        fi
    else
        log_error "Failed to install packages"
        result=1
        
        # Complete progress with failure
        if [[ "$show_progress" == "true" ]] && command -v progress_complete &>/dev/null; then
            progress_complete "failed"
        fi
    fi
    
    return $result
}

# Remove package(s)
# Usage: pkg_remove "docker"
# Exit codes: 0 = success, 1 = failed
pkg_remove() {
    local app_names="$@"
    
    if [[ -z "$app_names" ]]; then
        log_error "pkg_remove: at least one package name is required"
        return 1
    fi
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Get remove command
    local remove_cmd
    if ! remove_cmd=$(get_package_manager_command "remove"); then
        log_error "Failed to get remove command"
        return 1
    fi
    
    # Resolve all package names
    local resolved_packages=""
    for app_name in $app_names; do
        local packages
        if ! packages=$(_resolve_package_name "$app_name"); then
            log_error "Failed to resolve package name: $app_name"
            return 1
        fi
        resolved_packages="$resolved_packages $packages"
    done
    
    # Trim whitespace
    resolved_packages=$(echo "$resolved_packages" | xargs)
    
    if [[ -z "$resolved_packages" ]]; then
        log_error "No packages to remove"
        return 1
    fi
    
    log_info "Removing packages: $resolved_packages"
    log_debug "Command: $remove_cmd $resolved_packages"
    
    # Execute remove command
    if eval "$remove_cmd $resolved_packages"; then
        log_info "Successfully removed: $resolved_packages"
        return 0
    else
        log_error "Failed to remove packages"
        return 1
    fi
}

# Update package lists
# Usage: pkg_update_system
# Exit codes: 0 = success, 1 = failed
pkg_update_system() {
    local show_progress=true
    
    # Check if NO_PROGRESS is set (for nested calls)
    if [[ "$NO_PROGRESS" == "1" ]]; then
        show_progress=false
    fi
    
    log_info "Updating package lists..."
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Get update command
    local update_cmd
    if ! update_cmd=$(get_package_manager_command "update"); then
        log_error "Failed to get update command"
        return 1
    fi
    
    log_debug "Command: $update_cmd"
    
    # Start progress tracking if enabled
    if [[ "$show_progress" == "true" ]] && command -v progress_start &>/dev/null; then
        progress_start "Updating system packages"
    fi
    
    # Execute update command
    local result=0
    if eval "$update_cmd"; then
        log_info "Package lists updated successfully"
        result=0
        
        # Complete progress with success
        if [[ "$show_progress" == "true" ]] && command -v progress_complete &>/dev/null; then
            progress_complete "success"
        fi
    else
        log_error "Failed to update package lists"
        result=1
        
        # Complete progress with failure
        if [[ "$show_progress" == "true" ]] && command -v progress_complete &>/dev/null; then
            progress_complete "failed"
        fi
    fi
    
    return $result
}

# Clean package cache
# Usage: pkg_clean
# Exit codes: 0 = success, 1 = failed
pkg_clean() {
    log_info "Cleaning package cache..."
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Get clean command
    local clean_cmd
    if ! clean_cmd=$(get_package_manager_command "clean"); then
        log_error "Failed to get clean command"
        return 1
    fi
    
    log_debug "Command: $clean_cmd"
    
    # Execute clean command
    if eval "$clean_cmd"; then
        log_info "Package cache cleaned successfully"
        return 0
    else
        log_error "Failed to clean package cache"
        return 1
    fi
}

# Search for packages
# Usage: pkg_search "docker"
# Returns: search results
pkg_search() {
    local search_term="$1"
    
    if [[ -z "$search_term" ]]; then
        log_error "pkg_search: search term is required"
        return 1
    fi
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Get search command
    local search_cmd
    if ! search_cmd=$(get_package_manager_command "search"); then
        log_error "Failed to get search command"
        return 1
    fi
    
    log_debug "Searching for: $search_term"
    log_debug "Command: $search_cmd $search_term"
    
    # Execute search command
    eval "$search_cmd $search_term"
    return $?
}

# Check if package is installed
# Usage: pkg_is_installed "docker"
# Exit codes: 0 = installed, 1 = not installed
pkg_is_installed() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "pkg_is_installed: package name is required"
        return 1
    fi
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Resolve package name
    local packages
    if ! packages=$(_resolve_package_name "$app_name"); then
        log_error "Failed to resolve package name: $app_name"
        return 1
    fi
    
    # Check each package
    for package in $packages; do
        case "$DETECTED_PKG_MANAGER" in
            "pacman")
                if pacman -Q "$package" &>/dev/null; then
                    return 0
                fi
                ;;
            "apt")
                if dpkg -l "$package" 2>/dev/null | grep -q "^ii"; then
                    return 0
                fi
                ;;
            "dnf"|"yum")
                if rpm -q "$package" &>/dev/null; then
                    return 0
                fi
                ;;
            "zypper")
                if rpm -q "$package" &>/dev/null; then
                    return 0
                fi
                ;;
            "apk")
                if apk info -e "$package" &>/dev/null; then
                    return 0
                fi
                ;;
            "emerge")
                if equery list "$package" &>/dev/null; then
                    return 0
                fi
                ;;
            "xbps")
                if xbps-query "$package" &>/dev/null; then
                    return 0
                fi
                ;;
            *)
                log_error "Unsupported package manager: $DETECTED_PKG_MANAGER"
                return 1
                ;;
        esac
    done
    
    return 1
}

# Get package information
# Usage: pkg_get_info "docker"
# Returns: package information
pkg_get_info() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "pkg_get_info: package name is required"
        return 1
    fi
    
    # Ensure distro is detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro; then
            log_error "Failed to detect distribution"
            return 1
        fi
    fi
    
    # Resolve package name
    local packages
    if ! packages=$(_resolve_package_name "$app_name"); then
        log_error "Failed to resolve package name: $app_name"
        return 1
    fi
    
    # Get info for first package
    local package=$(echo "$packages" | awk '{print $1}')
    
    case "$DETECTED_PKG_MANAGER" in
        "pacman")
            pacman -Si "$package" 2>/dev/null || pacman -Qi "$package" 2>/dev/null
            ;;
        "apt")
            apt-cache show "$package" 2>/dev/null
            ;;
        "dnf")
            dnf info "$package" 2>/dev/null
            ;;
        "yum")
            yum info "$package" 2>/dev/null
            ;;
        "zypper")
            zypper info "$package" 2>/dev/null
            ;;
        "apk")
            apk info "$package" 2>/dev/null
            ;;
        "emerge")
            emerge --info "$package" 2>/dev/null
            ;;
        "xbps")
            xbps-query -R "$package" 2>/dev/null
            ;;
        *)
            log_error "Unsupported package manager: $DETECTED_PKG_MANAGER"
            return 1
            ;;
    esac
    
    return $?
}
