#!/bin/bash
# lib/history.sh - Installation history and rollback for PrecoresHub
# Tracks installation operations and enables rollback

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"

# History configuration
readonly HISTORY_DIR="${HOME}/.config/precoreshub"
readonly HISTORY_FILE="${HISTORY_DIR}/history.json"
readonly HISTORY_LOG_DIR="${HOME}/.cache/precoreshub/logs"
readonly MAX_HISTORY_ENTRIES=100

# Initialize history system
_history_init() {
    # Ensure history directory exists
    if [[ ! -d "$HISTORY_DIR" ]]; then
        mkdir -p "$HISTORY_DIR" 2>/dev/null || return 1
    fi
    
    # Ensure log directory exists
    if [[ ! -d "$HISTORY_LOG_DIR" ]]; then
        mkdir -p "$HISTORY_LOG_DIR" 2>/dev/null || return 1
    fi
    
    # Create empty history file if it doesn't exist
    if [[ ! -f "$HISTORY_FILE" ]]; then
        local empty_history='{"entries":[]}'
        write_json "$HISTORY_FILE" "$empty_history" 2>/dev/null || return 1
    fi
    
    return 0
}

# Record installation operation
# Usage: history_record "install" "docker nginx" "success" [duration] [log_file]
history_record() {
    local operation="$1"
    local packages="$2"
    local status="$3"
    local duration="${4:-0}"
    local log_file="${5:-}"
    
    if [[ -z "$operation" || -z "$packages" || -z "$status" ]]; then
        log_error "history_record: operation, packages, and status are required"
        return 1
    fi
    
    # Initialize if needed
    _history_init || return 1
    
    # Generate unique ID
    local id=$(date +%Y%m%d-%H%M%S)
    local timestamp=$(date +%s)
    
    # Create log file if not provided
    if [[ -z "$log_file" ]]; then
        log_file="${HISTORY_LOG_DIR}/${id}.log"
    fi
    
    # Read current history
    local history_json
    if ! history_json=$(read_json "$HISTORY_FILE" 2>/dev/null); then
        log_error "Failed to read history file"
        return 1
    fi
    
    # Create new entry
    local new_entry=$(jq -n \
        --arg id "$id" \
        --argjson timestamp "$timestamp" \
        --arg operation "$operation" \
        --arg packages "$packages" \
        --arg status "$status" \
        --argjson duration "$duration" \
        --arg log_file "$log_file" \
        '{
            id: $id,
            timestamp: $timestamp,
            operation: $operation,
            packages: $packages,
            status: $status,
            duration: $duration,
            log_file: $log_file
        }')
    
    # Add entry to history
    local updated_history
    updated_history=$(echo "$history_json" | jq \
        --argjson entry "$new_entry" \
        '.entries += [$entry]')
    
    # Limit history size
    updated_history=$(echo "$updated_history" | jq \
        --argjson max "$MAX_HISTORY_ENTRIES" \
        '.entries |= if length > $max then .[-$max:] else . end')
    
    # Write updated history
    if ! write_json "$HISTORY_FILE" "$updated_history" 2>/dev/null; then
        log_error "Failed to write history file"
        return 1
    fi
    
    log_debug "Recorded history entry: $id"
    return 0
}

# List installation history
# Usage: history_list ["all"|"success"|"failure"|date_range]
history_list() {
    local filter="${1:-all}"
    
    # Initialize if needed
    _history_init || return 1
    
    # Check if history file exists
    if [[ ! -f "$HISTORY_FILE" ]]; then
        echo "[]"
        return 0
    fi
    
    # Read history
    local history_json
    if ! history_json=$(read_json "$HISTORY_FILE" 2>/dev/null); then
        log_error "Failed to read history file"
        return 1
    fi
    
    # Apply filter
    case "$filter" in
        "all")
            echo "$history_json" | jq '.entries | reverse'
            ;;
        "success")
            echo "$history_json" | jq '.entries | reverse | map(select(.status == "success"))'
            ;;
        "failure")
            echo "$history_json" | jq '.entries | reverse | map(select(.status == "failure"))'
            ;;
        *)
            # Assume it's a date range or other filter
            echo "$history_json" | jq '.entries | reverse'
            ;;
    esac
    
    return 0
}

# Get detailed history entry
# Usage: history_get "20240101-120000"
history_get() {
    local id="$1"
    
    if [[ -z "$id" ]]; then
        log_error "history_get: id is required"
        return 1
    fi
    
    # Initialize if needed
    _history_init || return 1
    
    # Read history
    local history_json
    if ! history_json=$(read_json "$HISTORY_FILE" 2>/dev/null); then
        log_error "Failed to read history file"
        return 1
    fi
    
    # Find entry by ID
    local entry
    entry=$(echo "$history_json" | jq \
        --arg id "$id" \
        '.entries[] | select(.id == $id)')
    
    if [[ -z "$entry" || "$entry" == "null" ]]; then
        log_error "History entry not found: $id"
        return 1
    fi
    
    echo "$entry"
    return 0
}

# Rollback installation
# Usage: history_rollback "20240101-120000"
history_rollback() {
    local id="$1"
    
    if [[ -z "$id" ]]; then
        log_error "history_rollback: id is required"
        return 1
    fi
    
    log_info "Rolling back installation: $id"
    
    # Get history entry
    local entry
    if ! entry=$(history_get "$id"); then
        log_error "Cannot rollback: history entry not found"
        return 1
    fi
    
    # Extract packages
    local packages
    packages=$(echo "$entry" | jq -r '.packages')
    
    if [[ -z "$packages" || "$packages" == "null" ]]; then
        log_error "Cannot rollback: no packages found in history entry"
        return 1
    fi
    
    # Extract operation
    local operation
    operation=$(echo "$entry" | jq -r '.operation')
    
    # Determine rollback operation
    local rollback_operation
    case "$operation" in
        "install")
            rollback_operation="remove"
            ;;
        "remove")
            rollback_operation="install"
            ;;
        *)
            log_error "Cannot rollback: unsupported operation: $operation"
            return 1
            ;;
    esac
    
    log_info "Rollback operation: $rollback_operation packages: $packages"
    
    # Source package manager if not already loaded
    if ! declare -f pkg_remove &>/dev/null; then
        source "${SCRIPT_DIR}/package_manager.sh"
    fi
    
    # Execute rollback
    if [[ "$rollback_operation" == "remove" ]]; then
        if pkg_remove $packages; then
            log_info "Rollback successful"
            history_record "rollback" "$packages" "success"
            return 0
        else
            log_error "Rollback failed"
            history_record "rollback" "$packages" "failure"
            return 1
        fi
    elif [[ "$rollback_operation" == "install" ]]; then
        if pkg_install $packages; then
            log_info "Rollback successful"
            history_record "rollback" "$packages" "success"
            return 0
        else
            log_error "Rollback failed"
            history_record "rollback" "$packages" "failure"
            return 1
        fi
    fi
    
    return 1
}

# Retry failed installation
# Usage: history_retry "20240101-120000"
history_retry() {
    local id="$1"
    
    if [[ -z "$id" ]]; then
        log_error "history_retry: id is required"
        return 1
    fi
    
    log_info "Retrying installation: $id"
    
    # Get history entry
    local entry
    if ! entry=$(history_get "$id"); then
        log_error "Cannot retry: history entry not found"
        return 1
    fi
    
    # Extract packages and operation
    local packages
    local operation
    packages=$(echo "$entry" | jq -r '.packages')
    operation=$(echo "$entry" | jq -r '.operation')
    
    if [[ -z "$packages" || "$packages" == "null" ]]; then
        log_error "Cannot retry: no packages found in history entry"
        return 1
    fi
    
    log_info "Retry operation: $operation packages: $packages"
    
    # Source package manager if not already loaded
    if ! declare -f pkg_install &>/dev/null; then
        source "${SCRIPT_DIR}/package_manager.sh"
    fi
    
    # Execute retry
    case "$operation" in
        "install")
            if pkg_install $packages; then
                log_info "Retry successful"
                history_record "install" "$packages" "success"
                return 0
            else
                log_error "Retry failed"
                history_record "install" "$packages" "failure"
                return 1
            fi
            ;;
        "remove")
            if pkg_remove $packages; then
                log_info "Retry successful"
                history_record "remove" "$packages" "success"
                return 0
            else
                log_error "Retry failed"
                history_record "remove" "$packages" "failure"
                return 1
            fi
            ;;
        *)
            log_error "Cannot retry: unsupported operation: $operation"
            return 1
            ;;
    esac
    
    return 1
}

# Export history
# Usage: history_export "json" > history.json
# Usage: history_export "csv" > history.csv
history_export() {
    local format="${1:-json}"
    
    # Initialize if needed
    _history_init || return 1
    
    # Read history
    local history_json
    if ! history_json=$(read_json "$HISTORY_FILE" 2>/dev/null); then
        log_error "Failed to read history file"
        return 1
    fi
    
    case "$format" in
        "json")
            echo "$history_json" | jq '.entries'
            ;;
        "csv")
            echo "ID,Timestamp,Operation,Packages,Status,Duration"
            echo "$history_json" | jq -r '.entries[] | [.id, .timestamp, .operation, .packages, .status, .duration] | @csv'
            ;;
        *)
            log_error "Unsupported export format: $format"
            return 1
            ;;
    esac
    
    return 0
}

# Get history statistics
# Usage: history_get_stats
history_get_stats() {
    # Initialize if needed
    _history_init || return 1
    
    # Read history
    local history_json
    if ! history_json=$(read_json "$HISTORY_FILE" 2>/dev/null); then
        log_error "Failed to read history file"
        return 1
    fi
    
    # Calculate statistics
    local total=$(echo "$history_json" | jq '.entries | length')
    local success=$(echo "$history_json" | jq '.entries | map(select(.status == "success")) | length')
    local failure=$(echo "$history_json" | jq '.entries | map(select(.status == "failure")) | length')
    local installs=$(echo "$history_json" | jq '.entries | map(select(.operation == "install")) | length')
    local removes=$(echo "$history_json" | jq '.entries | map(select(.operation == "remove")) | length')
    
    jq -n \
        --argjson total "$total" \
        --argjson success "$success" \
        --argjson failure "$failure" \
        --argjson installs "$installs" \
        --argjson removes "$removes" \
        '{
            total: $total,
            success: $success,
            failure: $failure,
            installs: $installs,
            removes: $removes
        }'
    
    return 0
}

# Clear old history entries
# Usage: history_clear_old [days]
history_clear_old() {
    local days="${1:-30}"
    
    log_info "Clearing history entries older than $days days..."
    
    # Initialize if needed
    _history_init || return 1
    
    # Read history
    local history_json
    if ! history_json=$(read_json "$HISTORY_FILE" 2>/dev/null); then
        log_error "Failed to read history file"
        return 1
    fi
    
    # Calculate cutoff timestamp
    local cutoff=$(($(date +%s) - (days * 86400)))
    
    # Filter entries
    local updated_history
    updated_history=$(echo "$history_json" | jq \
        --argjson cutoff "$cutoff" \
        '.entries |= map(select(.timestamp >= $cutoff))')
    
    # Write updated history
    if ! write_json "$HISTORY_FILE" "$updated_history" 2>/dev/null; then
        log_error "Failed to write history file"
        return 1
    fi
    
    log_info "Old history entries cleared"
    return 0
}
