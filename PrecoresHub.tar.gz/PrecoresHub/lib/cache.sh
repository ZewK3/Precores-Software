#!/bin/bash
# lib/cache.sh - Caching system for PrecoresHub
# Caches package information for faster startup

# Source dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/core.sh"

# Cache configuration
readonly CACHE_DIR="${HOME}/.cache/precoreshub"
readonly CACHE_FILE="${CACHE_DIR}/package_cache.json"
readonly DEFAULT_CACHE_TTL=86400  # 24 hours in seconds

# Initialize cache system
# Usage: cache_init
cache_init() {
    log_debug "Initializing cache system..."
    
    # Ensure cache directory exists
    if [[ ! -d "$CACHE_DIR" ]]; then
        if ! mkdir -p "$CACHE_DIR" 2>/dev/null; then
            log_error "Failed to create cache directory: $CACHE_DIR"
            return 1
        fi
        log_debug "Created cache directory: $CACHE_DIR"
    fi
    
    # Create empty cache file if it doesn't exist
    if [[ ! -f "$CACHE_FILE" ]]; then
        local empty_cache='{
            "timestamp": 0,
            "ttl": '$DEFAULT_CACHE_TTL',
            "packages": {}
        }'
        
        if ! write_json "$CACHE_FILE" "$empty_cache" 2>/dev/null; then
            log_error "Failed to create cache file: $CACHE_FILE"
            return 1
        fi
        log_debug "Created cache file: $CACHE_FILE"
    fi
    
    log_info "Cache system initialized"
    return 0
}

# Get cached value
# Usage: cache_get "docker"
# Returns: cached value or empty if not found/expired
cache_get() {
    local key="$1"
    
    if [[ -z "$key" ]]; then
        log_error "cache_get: key is required"
        return 1
    fi
    
    # Check if cache file exists
    if [[ ! -f "$CACHE_FILE" ]]; then
        log_debug "Cache file not found"
        return 1
    fi
    
    # Check if cache is valid
    if ! cache_is_valid; then
        log_debug "Cache is expired"
        return 1
    fi
    
    # Get value from cache
    local value
    value=$(read_json "$CACHE_FILE" ".packages.\"${key}\"" 2>/dev/null)
    
    if [[ -z "$value" || "$value" == "null" ]]; then
        log_debug "Cache miss for key: $key"
        return 1
    fi
    
    log_debug "Cache hit for key: $key"
    echo "$value"
    return 0
}

# Set cached value with TTL
# Usage: cache_set "docker" '{"name":"docker","available":true}' [ttl]
cache_set() {
    local key="$1"
    local value="$2"
    local ttl="${3:-$DEFAULT_CACHE_TTL}"
    
    if [[ -z "$key" ]]; then
        log_error "cache_set: key is required"
        return 1
    fi
    
    if [[ -z "$value" ]]; then
        log_error "cache_set: value is required"
        return 1
    fi
    
    # Ensure cache is initialized
    if [[ ! -f "$CACHE_FILE" ]]; then
        cache_init
    fi
    
    # Read current cache
    local cache_json
    if ! cache_json=$(read_json "$CACHE_FILE" 2>/dev/null); then
        log_error "Failed to read cache file"
        return 1
    fi
    
    # Update cache with new value
    local updated_cache
    updated_cache=$(echo "$cache_json" | jq \
        --arg key "$key" \
        --argjson value "$value" \
        --argjson timestamp "$(date +%s)" \
        --argjson ttl "$ttl" \
        '.timestamp = $timestamp | .ttl = $ttl | .packages[$key] = $value')
    
    # Write updated cache
    if ! write_json "$CACHE_FILE" "$updated_cache" 2>/dev/null; then
        log_error "Failed to write cache file"
        return 1
    fi
    
    log_debug "Cached value for key: $key"
    return 0
}

# Invalidate cached value
# Usage: cache_invalidate "docker"
cache_invalidate() {
    local key="$1"
    
    if [[ -z "$key" ]]; then
        log_error "cache_invalidate: key is required"
        return 1
    fi
    
    # Check if cache file exists
    if [[ ! -f "$CACHE_FILE" ]]; then
        log_debug "Cache file not found, nothing to invalidate"
        return 0
    fi
    
    # Read current cache
    local cache_json
    if ! cache_json=$(read_json "$CACHE_FILE" 2>/dev/null); then
        log_error "Failed to read cache file"
        return 1
    fi
    
    # Remove key from cache
    local updated_cache
    updated_cache=$(echo "$cache_json" | jq --arg key "$key" 'del(.packages[$key])')
    
    # Write updated cache
    if ! write_json "$CACHE_FILE" "$updated_cache" 2>/dev/null; then
        log_error "Failed to write cache file"
        return 1
    fi
    
    log_debug "Invalidated cache for key: $key"
    return 0
}

# Check if cache is valid (not expired)
# Usage: cache_is_valid
# Exit codes: 0 = valid, 1 = invalid/expired
cache_is_valid() {
    # Check if cache file exists
    if [[ ! -f "$CACHE_FILE" ]]; then
        return 1
    fi
    
    # Get cache timestamp and TTL
    local timestamp
    local ttl
    timestamp=$(read_json "$CACHE_FILE" ".timestamp" 2>/dev/null)
    ttl=$(read_json "$CACHE_FILE" ".ttl" 2>/dev/null)
    
    if [[ -z "$timestamp" || "$timestamp" == "null" ]]; then
        log_debug "Cache has no timestamp"
        return 1
    fi
    
    if [[ -z "$ttl" || "$ttl" == "null" ]]; then
        ttl=$DEFAULT_CACHE_TTL
    fi
    
    # Calculate cache age
    local current_time=$(date +%s)
    local cache_age=$((current_time - timestamp))
    
    # Check if cache is expired
    if [[ $cache_age -gt $ttl ]]; then
        log_debug "Cache expired (age: ${cache_age}s, ttl: ${ttl}s)"
        return 1
    fi
    
    log_debug "Cache is valid (age: ${cache_age}s, ttl: ${ttl}s)"
    return 0
}

# Refresh cache (invalidate all)
# Usage: cache_refresh
cache_refresh() {
    log_info "Refreshing cache..."
    
    # Create new empty cache
    local empty_cache='{
        "timestamp": '$(date +%s)',
        "ttl": '$DEFAULT_CACHE_TTL',
        "packages": {}
    }'
    
    if ! write_json "$CACHE_FILE" "$empty_cache" 2>/dev/null; then
        log_error "Failed to refresh cache"
        return 1
    fi
    
    log_info "Cache refreshed successfully"
    return 0
}

# Get cache age in seconds
# Usage: cache_get_age
# Returns: age in seconds
cache_get_age() {
    if [[ ! -f "$CACHE_FILE" ]]; then
        echo "0"
        return 0
    fi
    
    local timestamp
    timestamp=$(read_json "$CACHE_FILE" ".timestamp" 2>/dev/null)
    
    if [[ -z "$timestamp" || "$timestamp" == "null" ]]; then
        echo "0"
        return 0
    fi
    
    local current_time=$(date +%s)
    local age=$((current_time - timestamp))
    
    echo "$age"
    return 0
}

# Get cache age in human-readable format
# Usage: cache_get_age_human
# Returns: "2 hours ago", "5 minutes ago", etc.
cache_get_age_human() {
    local age=$(cache_get_age)
    
    if [[ $age -lt 60 ]]; then
        echo "${age} seconds ago"
    elif [[ $age -lt 3600 ]]; then
        echo "$((age / 60)) minutes ago"
    elif [[ $age -lt 86400 ]]; then
        echo "$((age / 3600)) hours ago"
    else
        echo "$((age / 86400)) days ago"
    fi
    
    return 0
}

# Get cache statistics
# Usage: cache_get_stats
# Returns: JSON with cache statistics
cache_get_stats() {
    if [[ ! -f "$CACHE_FILE" ]]; then
        echo '{"exists":false}'
        return 0
    fi
    
    local timestamp=$(read_json "$CACHE_FILE" ".timestamp" 2>/dev/null)
    local ttl=$(read_json "$CACHE_FILE" ".ttl" 2>/dev/null)
    local package_count=$(read_json "$CACHE_FILE" ".packages | length" 2>/dev/null)
    local age=$(cache_get_age)
    local age_human=$(cache_get_age_human)
    local is_valid="false"
    
    if cache_is_valid; then
        is_valid="true"
    fi
    
    jq -n \
        --argjson exists true \
        --argjson timestamp "$timestamp" \
        --argjson ttl "$ttl" \
        --argjson package_count "$package_count" \
        --argjson age "$age" \
        --arg age_human "$age_human" \
        --argjson is_valid "$is_valid" \
        '{
            exists: $exists,
            timestamp: $timestamp,
            ttl: $ttl,
            package_count: $package_count,
            age: $age,
            age_human: $age_human,
            is_valid: $is_valid
        }'
    
    return 0
}
