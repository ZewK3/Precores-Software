#!/bin/bash
# lib/progress.sh - Progress tracking system for PrecoresHub
# Provides visual progress indicators for operations

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"

# Progress bar configuration
readonly PROGRESS_BAR_WIDTH=50
readonly PROGRESS_SPINNER=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')

# Global progress state
PROGRESS_CURRENT_OPERATION=""
PROGRESS_CURRENT_PERCENTAGE=0
PROGRESS_SPINNER_INDEX=0
PROGRESS_PID=""

# Start progress tracking
# Usage: progress_start "Installing Docker"
progress_start() {
    local operation_name="$1"
    
    if [[ -z "$operation_name" ]]; then
        log_error "progress_start: operation name is required"
        return 1
    fi
    
    PROGRESS_CURRENT_OPERATION="$operation_name"
    PROGRESS_CURRENT_PERCENTAGE=0
    PROGRESS_SPINNER_INDEX=0
    
    log_info "Starting: $operation_name"
    
    # Display initial progress bar
    _draw_progress_bar 0 "$operation_name"
    
    return 0
}

# Update progress
# Usage: progress_update 50 "Downloading packages"
progress_update() {
    local percentage="$1"
    local message="${2:-$PROGRESS_CURRENT_OPERATION}"
    
    # Validate percentage
    if [[ ! "$percentage" =~ ^[0-9]+$ ]] || [[ "$percentage" -lt 0 ]] || [[ "$percentage" -gt 100 ]]; then
        log_error "progress_update: invalid percentage: $percentage (must be 0-100)"
        return 1
    fi
    
    PROGRESS_CURRENT_PERCENTAGE="$percentage"
    
    # Draw progress bar
    _draw_progress_bar "$percentage" "$message"
    
    return 0
}

# Complete progress tracking
# Usage: progress_complete "success" "Installation completed"
progress_complete() {
    local status="$1"  # "success" or "failure"
    local message="$2"
    
    if [[ "$status" == "success" ]]; then
        _draw_progress_bar 100 "$message"
        echo ""
        log_info "✓ $message"
    else
        echo ""
        log_error "✗ $message"
    fi
    
    # Reset state
    PROGRESS_CURRENT_OPERATION=""
    PROGRESS_CURRENT_PERCENTAGE=0
    
    return 0
}

# Draw progress bar
# Internal function
_draw_progress_bar() {
    local percentage="$1"
    local message="$2"
    
    # Calculate filled and empty portions
    local filled=$((percentage * PROGRESS_BAR_WIDTH / 100))
    local empty=$((PROGRESS_BAR_WIDTH - filled))
    
    # Build progress bar
    local bar=""
    for ((i=0; i<filled; i++)); do
        bar+="█"
    done
    for ((i=0; i<empty; i++)); do
        bar+="░"
    done
    
    # Print progress bar (overwrite previous line)
    printf "\r\033[K[%s] %3d%% - %s" "$bar" "$percentage" "$message"
    
    return 0
}

# Start spinner animation (for indeterminate progress)
# Usage: progress_spinner_start "Processing..."
progress_spinner_start() {
    local message="$1"
    
    PROGRESS_CURRENT_OPERATION="$message"
    PROGRESS_SPINNER_INDEX=0
    
    # Start spinner in background
    _spinner_loop "$message" &
    PROGRESS_PID=$!
    
    return 0
}

# Stop spinner animation
# Usage: progress_spinner_stop
progress_spinner_stop() {
    if [[ -n "$PROGRESS_PID" ]]; then
        kill "$PROGRESS_PID" 2>/dev/null
        wait "$PROGRESS_PID" 2>/dev/null
        PROGRESS_PID=""
    fi
    
    # Clear spinner line
    printf "\r\033[K"
    
    return 0
}

# Spinner loop (internal)
_spinner_loop() {
    local message="$1"
    local index=0
    
    while true; do
        local spinner_char="${PROGRESS_SPINNER[$index]}"
        printf "\r%s %s" "$spinner_char" "$message"
        index=$(( (index + 1) % ${#PROGRESS_SPINNER[@]} ))
        sleep 0.1
    done
}

# Start parallel progress tracking
# Usage: progress_parallel_start 3
progress_parallel_start() {
    local count="$1"
    
    if [[ ! "$count" =~ ^[0-9]+$ ]] || [[ "$count" -lt 1 ]]; then
        log_error "progress_parallel_start: invalid count: $count"
        return 1
    fi
    
    log_info "Starting parallel operations ($count tasks)"
    
    # Initialize parallel progress state
    declare -g -A PARALLEL_PROGRESS
    for ((i=0; i<count; i++)); do
        PARALLEL_PROGRESS[$i]=0
    done
    
    # Draw initial parallel progress bars
    for ((i=0; i<count; i++)); do
        echo ""
    done
    
    return 0
}

# Update parallel progress
# Usage: progress_parallel_update 0 50 "Installing Docker"
progress_parallel_update() {
    local index="$1"
    local percentage="$2"
    local message="$3"
    
    # Validate inputs
    if [[ ! "$index" =~ ^[0-9]+$ ]]; then
        log_error "progress_parallel_update: invalid index: $index"
        return 1
    fi
    
    if [[ ! "$percentage" =~ ^[0-9]+$ ]] || [[ "$percentage" -lt 0 ]] || [[ "$percentage" -gt 100 ]]; then
        log_error "progress_parallel_update: invalid percentage: $percentage"
        return 1
    fi
    
    # Update state
    PARALLEL_PROGRESS[$index]=$percentage
    
    # Move cursor up to the correct line
    local lines_up=$((${#PARALLEL_PROGRESS[@]} - index))
    printf "\033[%dA" "$lines_up"
    
    # Draw progress bar for this task
    _draw_progress_bar "$percentage" "$message"
    
    # Move cursor back down
    printf "\033[%dB" "$lines_up"
    
    return 0
}

# Complete parallel progress tracking
# Usage: progress_parallel_complete
progress_parallel_complete() {
    echo ""
    log_info "All parallel operations completed"
    
    # Clear parallel progress state
    unset PARALLEL_PROGRESS
    
    return 0
}

# Simple progress indicator (for quick operations)
# Usage: progress_simple "Installing..." && install_package && progress_simple_done
progress_simple() {
    local message="$1"
    printf "%s... " "$message"
    return 0
}

progress_simple_done() {
    echo "✓"
    return 0
}

progress_simple_failed() {
    echo "✗"
    return 0
}
