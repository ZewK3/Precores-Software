#!/bin/bash
# lib/error.sh - Enhanced error handling for PrecoresHub
# Provides better error messages with suggested fixes

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"

# Error log configuration
readonly ERROR_LOG_DIR="${HOME}/.cache/precoreshub/logs"
readonly ERROR_LOG_FILE="${ERROR_LOG_DIR}/error.log"

# Error types
readonly ERROR_PACKAGE_NOT_FOUND="package_not_found"
readonly ERROR_NETWORK="network_error"
readonly ERROR_DISK_SPACE="disk_space"
readonly ERROR_PERMISSION_DENIED="permission_denied"
readonly ERROR_DEPENDENCY_CONFLICT="dependency_conflict"
readonly ERROR_UNKNOWN="unknown_error"

# Initialize error handling system
error_init() {
    # Ensure error log directory exists
    if [[ ! -d "$ERROR_LOG_DIR" ]]; then
        mkdir -p "$ERROR_LOG_DIR" 2>/dev/null || return 1
    fi
    
    # Create error log file if it doesn't exist
    if [[ ! -f "$ERROR_LOG_FILE" ]]; then
        touch "$ERROR_LOG_FILE" 2>/dev/null || return 1
    fi
    
    return 0
}

# Handle error with context and suggestions
# Usage: error_handle "package_not_found" "docker" "install"
error_handle() {
    local error_type="$1"
    local context="$2"
    local operation="${3:-unknown}"
    
    if [[ -z "$error_type" ]]; then
        log_error "error_handle: error_type is required"
        return 1
    fi
    
    # Initialize if needed
    error_init
    
    # Get error template
    local error_message
    local error_suggestion
    local error_fix_command
    
    case "$error_type" in
        "$ERROR_PACKAGE_NOT_FOUND")
            error_message="Package '$context' not found"
            error_suggestion="Try searching for similar packages or check the package name spelling"
            error_fix_command="pkg_search \"$context\""
            ;;
        "$ERROR_NETWORK")
            error_message="Network error occurred"
            error_suggestion="Please check your internet connection and try again"
            error_fix_command="ping -c 1 8.8.8.8"
            ;;
        "$ERROR_DISK_SPACE")
            error_message="Insufficient disk space"
            error_suggestion="Please free up some disk space and try again"
            error_fix_command="df -h"
            ;;
        "$ERROR_PERMISSION_DENIED")
            error_message="Permission denied"
            error_suggestion="Please run with sudo or check file permissions"
            error_fix_command="sudo $operation"
            ;;
        "$ERROR_DEPENDENCY_CONFLICT")
            error_message="Dependency conflict detected"
            error_suggestion="Please resolve conflicts manually or contact support"
            error_fix_command=""
            ;;
        "$ERROR_UNKNOWN")
            error_message="An unknown error occurred"
            error_suggestion="Please check logs for more details"
            error_fix_command="tail -n 50 $ERROR_LOG_FILE"
            ;;
        *)
            error_message="Error: $error_type"
            error_suggestion="No suggestion available"
            error_fix_command=""
            ;;
    esac
    
    # Log error
    error_log "$error_type" "$error_message" "$operation" "$context"
    
    # Display error
    echo ""
    log_error "$error_message"
    echo ""
    echo "💡 Suggestion: $error_suggestion"
    
    if [[ -n "$error_fix_command" ]]; then
        echo ""
        echo "🔧 Try running: $error_fix_command"
    fi
    echo ""
    
    return 1
}

# Log error with context
# Usage: error_log "package_not_found" "Package not found" "install" "docker"
error_log() {
    local error_type="$1"
    local error_message="$2"
    local operation="$3"
    local context="$4"
    
    # Initialize if needed
    error_init
    
    # Create log entry
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local log_entry="[$timestamp] [$error_type] [$operation] $error_message"
    
    if [[ -n "$context" ]]; then
        log_entry="$log_entry (context: $context)"
    fi
    
    # Append to log file
    echo "$log_entry" >> "$ERROR_LOG_FILE" 2>/dev/null
    
    return 0
}

# Get error template
# Usage: error_get_template "package_not_found"
error_get_template() {
    local error_type="$1"
    
    case "$error_type" in
        "$ERROR_PACKAGE_NOT_FOUND")
            cat <<EOF
{
    "type": "$ERROR_PACKAGE_NOT_FOUND",
    "message": "Package '{package}' not found",
    "suggestion": "Try searching for similar packages or check the package name spelling",
    "fix_command": "pkg_search \"{package}\"",
    "severity": "error"
}
EOF
            ;;
        "$ERROR_NETWORK")
            cat <<EOF
{
    "type": "$ERROR_NETWORK",
    "message": "Network error occurred",
    "suggestion": "Please check your internet connection and try again",
    "fix_command": "ping -c 1 8.8.8.8",
    "severity": "error"
}
EOF
            ;;
        "$ERROR_DISK_SPACE")
            cat <<EOF
{
    "type": "$ERROR_DISK_SPACE",
    "message": "Insufficient disk space",
    "suggestion": "Please free up some disk space and try again",
    "fix_command": "df -h",
    "severity": "error"
}
EOF
            ;;
        "$ERROR_PERMISSION_DENIED")
            cat <<EOF
{
    "type": "$ERROR_PERMISSION_DENIED",
    "message": "Permission denied",
    "suggestion": "Please run with sudo or check file permissions",
    "fix_command": "sudo {operation}",
    "severity": "error"
}
EOF
            ;;
        "$ERROR_DEPENDENCY_CONFLICT")
            cat <<EOF
{
    "type": "$ERROR_DEPENDENCY_CONFLICT",
    "message": "Dependency conflict detected",
    "suggestion": "Please resolve conflicts manually or contact support",
    "fix_command": "",
    "severity": "warning"
}
EOF
            ;;
        *)
            cat <<EOF
{
    "type": "$ERROR_UNKNOWN",
    "message": "An unknown error occurred",
    "suggestion": "Please check logs for more details",
    "fix_command": "tail -n 50 $ERROR_LOG_FILE",
    "severity": "error"
}
EOF
            ;;
    esac
    
    return 0
}

# Apply automatic fix for known errors
# Usage: error_apply_fix "package_not_found" "docker"
error_apply_fix() {
    local error_type="$1"
    local context="$2"
    
    log_info "Attempting to apply automatic fix for: $error_type"
    
    case "$error_type" in
        "$ERROR_PACKAGE_NOT_FOUND")
            log_info "Searching for similar packages..."
            if declare -f pkg_search &>/dev/null; then
                pkg_search "$context"
            else
                log_error "Package search function not available"
                return 1
            fi
            ;;
        "$ERROR_NETWORK")
            log_info "Testing network connectivity..."
            if ping -c 1 8.8.8.8 >/dev/null 2>&1; then
                log_info "Network is reachable"
                return 0
            else
                log_error "Network is not reachable"
                return 1
            fi
            ;;
        "$ERROR_DISK_SPACE")
            log_info "Checking disk space..."
            df -h
            return 1
            ;;
        *)
            log_error "No automatic fix available for: $error_type"
            return 1
            ;;
    esac
    
    return 0
}

# View error log
# Usage: error_view_log [lines]
error_view_log() {
    local lines="${1:-50}"
    
    if [[ ! -f "$ERROR_LOG_FILE" ]]; then
        log_info "No error log found"
        return 0
    fi
    
    echo "=== Error Log (last $lines lines) ==="
    echo ""
    tail -n "$lines" "$ERROR_LOG_FILE"
    echo ""
    
    return 0
}

# Clear error log
# Usage: error_clear_log
error_clear_log() {
    if [[ -f "$ERROR_LOG_FILE" ]]; then
        > "$ERROR_LOG_FILE"
        log_info "Error log cleared"
    else
        log_info "No error log to clear"
    fi
    
    return 0
}

# Get error statistics
# Usage: error_get_stats
error_get_stats() {
    if [[ ! -f "$ERROR_LOG_FILE" ]]; then
        echo '{"total":0,"by_type":{}}'
        return 0
    fi
    
    local total=$(wc -l < "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    
    # Count by error type (handle empty file)
    if [[ $total -eq 0 ]]; then
        echo '{"total":0,"by_type":{"package_not_found":0,"network":0,"disk_space":0,"permission_denied":0,"dependency_conflict":0,"unknown":0}}'
        return 0
    fi
    
    local package_not_found=$(grep -c "\[package_not_found\]" "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    local network=$(grep -c "\[network_error\]" "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    local disk_space=$(grep -c "\[disk_space\]" "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    local permission=$(grep -c "\[permission_denied\]" "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    local dependency=$(grep -c "\[dependency_conflict\]" "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    local unknown=$(grep -c "\[unknown_error\]" "$ERROR_LOG_FILE" 2>/dev/null || echo 0)
    
    jq -n \
        --argjson total "$total" \
        --argjson package_not_found "$package_not_found" \
        --argjson network "$network" \
        --argjson disk_space "$disk_space" \
        --argjson permission "$permission" \
        --argjson dependency "$dependency" \
        --argjson unknown "$unknown" \
        '{
            total: $total,
            by_type: {
                package_not_found: $package_not_found,
                network: $network,
                disk_space: $disk_space,
                permission_denied: $permission,
                dependency_conflict: $dependency,
                unknown: $unknown
            }
        }'
    
    return 0
}

# Check if error log exists
# Usage: error_log_exists
error_log_exists() {
    [[ -f "$ERROR_LOG_FILE" ]]
    return $?
}

# Get error log size
# Usage: error_log_size
error_log_size() {
    if [[ -f "$ERROR_LOG_FILE" ]]; then
        du -h "$ERROR_LOG_FILE" | cut -f1
    else
        echo "0"
    fi
    
    return 0
}

# Suggest fix for error
# Usage: error_suggest_fix "package_not_found" "docker"
error_suggest_fix() {
    local error_type="$1"
    local context="$2"
    
    case "$error_type" in
        "$ERROR_PACKAGE_NOT_FOUND")
            echo "Try: pkg_search \"$context\""
            ;;
        "$ERROR_NETWORK")
            echo "Try: ping -c 1 8.8.8.8"
            ;;
        "$ERROR_DISK_SPACE")
            echo "Try: df -h && sudo apt clean"
            ;;
        "$ERROR_PERMISSION_DENIED")
            echo "Try: sudo <command>"
            ;;
        "$ERROR_DEPENDENCY_CONFLICT")
            echo "Try: Check package dependencies manually"
            ;;
        *)
            echo "No suggestion available"
            ;;
    esac
    
    return 0
}

# Export error log
# Usage: error_export_log [format]
error_export_log() {
    local format="${1:-txt}"
    
    if [[ ! -f "$ERROR_LOG_FILE" ]]; then
        log_error "No error log to export"
        return 1
    fi
    
    case "$format" in
        "txt")
            cat "$ERROR_LOG_FILE"
            ;;
        "json")
            # Convert log to JSON format
            echo "["
            local first=true
            while IFS= read -r line; do
                if [[ "$first" == true ]]; then
                    first=false
                else
                    echo ","
                fi
                echo -n "  {\"log\":\"$(echo "$line" | sed 's/"/\\"/g')\"}"
            done < "$ERROR_LOG_FILE"
            echo ""
            echo "]"
            ;;
        *)
            log_error "Unknown format: $format"
            return 1
            ;;
    esac
    
    return 0
}
