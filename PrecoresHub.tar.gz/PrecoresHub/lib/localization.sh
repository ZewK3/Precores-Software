#!/bin/bash
# lib/localization.sh - Multi-language support for PrecoresHub
# Provides translation and localization functionality

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"

# Localization configuration
readonly LANG_DIR="${SCRIPT_DIR}/lang"
readonly DEFAULT_LANG="en"
CURRENT_LANG="${DEFAULT_LANG}"

# Translation cache
declare -gA TRANSLATION_CACHE

# Initialize localization system
# Usage: lang_init [language_code]
lang_init() {
    local lang="${1:-}"
    
    # Detect language if not provided
    if [[ -z "$lang" ]]; then
        lang=$(lang_detect)
    fi
    
    # Set language
    if lang_set "$lang" 2>/dev/null; then
        log_info "Localization initialized: $CURRENT_LANG"
        return 0
    else
        log_error "Failed to initialize localization, using default: $DEFAULT_LANG"
        CURRENT_LANG="$DEFAULT_LANG"
        return 1
    fi
}

# Detect system language
# Usage: lang_detect
# Returns: language code (e.g., "en", "vi")
lang_detect() {
    local detected_lang="$DEFAULT_LANG"
    
    # Try to detect from LANG environment variable
    if [[ -n "$LANG" ]]; then
        # Extract language code (e.g., "en_US.UTF-8" -> "en")
        detected_lang=$(echo "$LANG" | cut -d'_' -f1 | cut -d'.' -f1)
    fi
    
    # Try to detect from LC_ALL
    if [[ -z "$detected_lang" || "$detected_lang" == "C" ]] && [[ -n "$LC_ALL" ]]; then
        detected_lang=$(echo "$LC_ALL" | cut -d'_' -f1 | cut -d'.' -f1)
    fi
    
    # Try to detect from LC_MESSAGES
    if [[ -z "$detected_lang" || "$detected_lang" == "C" ]] && [[ -n "$LC_MESSAGES" ]]; then
        detected_lang=$(echo "$LC_MESSAGES" | cut -d'_' -f1 | cut -d'.' -f1)
    fi
    
    # Fallback to default if detection failed
    if [[ -z "$detected_lang" || "$detected_lang" == "C" ]]; then
        detected_lang="$DEFAULT_LANG"
    fi
    
    # Check if language file exists
    if [[ ! -f "${LANG_DIR}/${detected_lang}.json" ]]; then
        log_debug "Language file not found for '$detected_lang', using default"
        detected_lang="$DEFAULT_LANG"
    fi
    
    echo "$detected_lang"
    return 0
}

# Set current language
# Usage: lang_set "vi"
lang_set() {
    local lang="$1"
    
    if [[ -z "$lang" ]]; then
        log_error "lang_set: language code is required"
        return 1
    fi
    
    # Check if language file exists
    local lang_file="${LANG_DIR}/${lang}.json"
    if [[ ! -f "$lang_file" ]]; then
        log_error "Language file not found: $lang_file"
        return 1
    fi
    
    # Validate JSON
    if ! jq empty "$lang_file" 2>/dev/null; then
        log_error "Invalid JSON in language file: $lang_file"
        return 1
    fi
    
    # Set current language
    CURRENT_LANG="$lang"
    
    # Clear translation cache
    TRANSLATION_CACHE=()
    
    log_info "Language set to: $CURRENT_LANG"
    return 0
}

# Get translation for a key
# Usage: lang_get "menu.main.title"
# Usage: lang_get "error.not_found" "package_name"
lang_get() {
    local key="$1"
    shift
    local args=("$@")
    
    if [[ -z "$key" ]]; then
        log_error "lang_get: key is required"
        return 1
    fi
    
    # Check cache first
    if [[ -n "${TRANSLATION_CACHE[$key]}" ]]; then
        local translation="${TRANSLATION_CACHE[$key]}"
    else
        # Load from file
        local lang_file="${LANG_DIR}/${CURRENT_LANG}.json"
        
        if [[ ! -f "$lang_file" ]]; then
            log_error "Language file not found: $lang_file"
            echo "$key"
            return 1
        fi
        
        # Get translation using jq
        local translation
        translation=$(jq -r ".$key // \"$key\"" "$lang_file" 2>/dev/null)
        
        if [[ -z "$translation" || "$translation" == "null" ]]; then
            log_debug "Translation not found for key: $key"
            echo "$key"
            return 1
        fi
        
        # Cache translation
        TRANSLATION_CACHE[$key]="$translation"
    fi
    
    # Perform variable substitution
    if [[ ${#args[@]} -gt 0 ]]; then
        local i=0
        for arg in "${args[@]}"; do
            translation="${translation//\{$i\}/$arg}"
            ((i++))
        done
        
        # Also support named placeholders
        translation="${translation//\{error\}/${args[0]}}"
        translation="${translation//\{name\}/${args[0]}}"
        translation="${translation//\{count\}/${args[0]}}"
    fi
    
    echo "$translation"
    return 0
}

# List available languages
# Usage: lang_list
# Returns: JSON array of available languages
lang_list() {
    local languages=()
    
    # Find all .json files in lang directory
    if [[ ! -d "$LANG_DIR" ]]; then
        log_error "Language directory not found: $LANG_DIR"
        echo "[]"
        return 1
    fi
    
    # Build JSON array
    local json="["
    local first=true
    
    for lang_file in "$LANG_DIR"/*.json; do
        if [[ -f "$lang_file" ]]; then
            local lang_code=$(basename "$lang_file" .json)
            
            # Get language name from file
            local lang_name
            lang_name=$(jq -r '.meta.name // "Unknown"' "$lang_file" 2>/dev/null)
            
            if [[ "$first" == true ]]; then
                first=false
            else
                json+=","
            fi
            
            json+="{\"code\":\"$lang_code\",\"name\":\"$lang_name\"}"
        fi
    done
    
    json+="]"
    
    echo "$json"
    return 0
}

# Get current language
# Usage: lang_get_current
lang_get_current() {
    echo "$CURRENT_LANG"
    return 0
}

# Check if translation key exists
# Usage: lang_has_key "menu.main.title"
lang_has_key() {
    local key="$1"
    
    if [[ -z "$key" ]]; then
        return 1
    fi
    
    local lang_file="${LANG_DIR}/${CURRENT_LANG}.json"
    
    if [[ ! -f "$lang_file" ]]; then
        return 1
    fi
    
    # Check if key exists
    local value
    value=$(jq -r ".$key // null" "$lang_file" 2>/dev/null)
    
    if [[ "$value" == "null" || -z "$value" ]]; then
        return 1
    else
        return 0
    fi
}

# Get all translations for current language
# Usage: lang_get_all
# Returns: JSON object with all translations
lang_get_all() {
    local lang_file="${LANG_DIR}/${CURRENT_LANG}.json"
    
    if [[ ! -f "$lang_file" ]]; then
        log_error "Language file not found: $lang_file"
        echo "{}"
        return 1
    fi
    
    read_json "$lang_file" 2>/dev/null
    return $?
}

# Reload translations (clear cache)
# Usage: lang_reload
lang_reload() {
    TRANSLATION_CACHE=()
    log_info "Translation cache cleared"
    return 0
}

# Format message with translations
# Usage: lang_format "Installing {0}..." "docker"
lang_format() {
    local message="$1"
    shift
    local args=("$@")
    
    if [[ -z "$message" ]]; then
        return 1
    fi
    
    # Perform variable substitution
    local i=0
    for arg in "${args[@]}"; do
        message="${message//\{$i\}/$arg}"
        ((i++))
    done
    
    echo "$message"
    return 0
}

# Get language metadata
# Usage: lang_get_meta "name"
lang_get_meta() {
    local meta_key="$1"
    
    if [[ -z "$meta_key" ]]; then
        log_error "lang_get_meta: meta_key is required"
        return 1
    fi
    
    local lang_file="${LANG_DIR}/${CURRENT_LANG}.json"
    
    if [[ ! -f "$lang_file" ]]; then
        log_error "Language file not found: $lang_file"
        return 1
    fi
    
    # Get metadata
    local value
    value=$(jq -r ".meta.$meta_key // null" "$lang_file" 2>/dev/null)
    
    if [[ "$value" == "null" || -z "$value" ]]; then
        log_debug "Metadata not found: $meta_key"
        return 1
    fi
    
    echo "$value"
    return 0
}

# Validate language file
# Usage: lang_validate "en"
lang_validate() {
    local lang="$1"
    
    if [[ -z "$lang" ]]; then
        log_error "lang_validate: language code is required"
        return 1
    fi
    
    local lang_file="${LANG_DIR}/${lang}.json"
    
    if [[ ! -f "$lang_file" ]]; then
        log_error "Language file not found: $lang_file"
        return 1
    fi
    
    # Validate JSON structure
    if ! jq empty "$lang_file" 2>/dev/null; then
        log_error "Invalid JSON in language file: $lang_file"
        return 1
    fi
    
    # Check required metadata
    local required_meta=("name" "code" "version")
    for meta in "${required_meta[@]}"; do
        local value
        value=$(jq -r ".meta.$meta // null" "$lang_file" 2>/dev/null)
        
        if [[ "$value" == "null" || -z "$value" ]]; then
            log_error "Missing required metadata: $meta"
            return 1
        fi
    done
    
    log_info "Language file validated: $lang"
    return 0
}

# Get translation with fallback
# Usage: lang_get_or "menu.main.title" "Main Menu"
lang_get_or() {
    local key="$1"
    local fallback="$2"
    
    if [[ -z "$key" ]]; then
        echo "$fallback"
        return 0
    fi
    
    local translation
    translation=$(lang_get "$key" 2>/dev/null)
    
    if [[ -z "$translation" || "$translation" == "$key" ]]; then
        echo "$fallback"
    else
        echo "$translation"
    fi
    
    return 0
}
