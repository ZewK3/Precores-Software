#!/bin/bash
# lib/distro.sh - Distribution detection for PrecoresHub
# Detects Linux distribution and maps to appropriate package manager

# Source core utilities
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/core.sh"

# Distribution configuration file
readonly DISTROS_CONFIG="config/distros.json"

# Global variables for detected distribution
DETECTED_DISTRO=""
DETECTED_DISTRO_NAME=""
DETECTED_PKG_MANAGER=""

# Detect Linux distribution
# Sets global variables: DETECTED_DISTRO, DETECTED_DISTRO_NAME, DETECTED_PKG_MANAGER
# Usage: detect_distro
# Exit codes: 0 = success, 1 = unsupported distro
detect_distro() {
    log_debug "Detecting Linux distribution..."
    
    # Check if distros config exists
    if [[ ! -f "$DISTROS_CONFIG" ]]; then
        log_error "Distros configuration file not found: $DISTROS_CONFIG"
        return 1
    fi
    
    # Try to read /etc/os-release first (standard method)
    if [[ -f "/etc/os-release" ]]; then
        source /etc/os-release
        local os_id="${ID:-}"
        local os_id_like="${ID_LIKE:-}"
        
        log_debug "Found /etc/os-release: ID=$os_id, ID_LIKE=$os_id_like"
        
        # Check if this ID matches any distro
        if _check_distro_by_id "$os_id"; then
            return 0
        fi
        
        # Try ID_LIKE as fallback
        if [[ -n "$os_id_like" ]]; then
            for like_id in $os_id_like; do
                if _check_distro_by_id "$like_id"; then
                    return 0
                fi
            done
        fi
    fi
    
    # Fallback: Check for specific release files
    log_debug "Trying fallback detection methods..."
    
    if [[ -f "/etc/alpine-release" ]]; then
        _set_distro "alpine"
        return 0
    elif [[ -f "/etc/arch-release" ]]; then
        _set_distro "arch"
        return 0
    elif [[ -f "/etc/debian_version" ]]; then
        _set_distro "debian"
        return 0
    elif [[ -f "/etc/fedora-release" ]]; then
        _set_distro "fedora"
        return 0
    elif [[ -f "/etc/redhat-release" ]]; then
        if grep -q "CentOS" /etc/redhat-release 2>/dev/null; then
            _set_distro "centos"
        else
            _set_distro "rhel"
        fi
        return 0
    elif [[ -f "/etc/gentoo-release" ]]; then
        _set_distro "gentoo"
        return 0
    elif [[ -f "/etc/SUSE-release" ]] || [[ -f "/etc/SuSE-release" ]]; then
        _set_distro "opensuse"
        return 0
    elif [[ -f "/etc/solus-release" ]]; then
        _set_distro "solus"
        return 0
    elif [[ -f "/etc/NIXOS" ]]; then
        _set_distro "nixos"
        return 0
    elif [[ -f "/usr/share/clear/version" ]]; then
        _set_distro "clearlinux"
        return 0
    fi
    
    # No supported distro found
    log_error "Unsupported Linux distribution"
    log_info "Supported distributions:"
    _list_supported_distros
    return 1
}

# Check distro by os-release ID
# Usage: _check_distro_by_id "ubuntu"
# Returns: 0 if found and set, 1 if not found
_check_distro_by_id() {
    local id="$1"
    
    # Get list of distro IDs from config
    local distro_ids
    distro_ids=$(read_json "$DISTROS_CONFIG" 'keys[]' 2>/dev/null)
    
    for distro_id in $distro_ids; do
        local config_id
        config_id=$(read_json "$DISTROS_CONFIG" ".${distro_id}.detection.os_release_id" 2>/dev/null)
        
        if [[ "$config_id" == "$id" ]]; then
            _set_distro "$distro_id"
            return 0
        fi
    done
    
    return 1
}

# Set detected distribution
# Usage: _set_distro "alpine"
_set_distro() {
    local distro_id="$1"
    
    DETECTED_DISTRO="$distro_id"
    DETECTED_DISTRO_NAME=$(read_json "$DISTROS_CONFIG" ".${distro_id}.name" 2>/dev/null)
    DETECTED_PKG_MANAGER=$(read_json "$DISTROS_CONFIG" ".${distro_id}.package_manager" 2>/dev/null)
    
    log_info "Detected distribution: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)"
}

# List supported distributions
_list_supported_distros() {
    local distro_ids
    distro_ids=$(read_json "$DISTROS_CONFIG" 'keys[]' 2>/dev/null)
    
    for distro_id in $distro_ids; do
        local name
        name=$(read_json "$DISTROS_CONFIG" ".${distro_id}.name" 2>/dev/null)
        log_info "  - $name ($distro_id)"
    done
}

# Get package manager for detected distribution
# Usage: get_package_manager
# Returns: package manager name (e.g., "apk", "apt", "pacman")
# Exit codes: 0 = success, 1 = no distro detected
get_package_manager() {
    if [[ -z "$DETECTED_PKG_MANAGER" ]]; then
        log_error "No distribution detected. Run detect_distro first."
        return 1
    fi
    
    echo "$DETECTED_PKG_MANAGER"
    return 0
}

# Get package manager command
# Usage: get_package_manager_command "install"
# Returns: full command (e.g., "apk add", "apt-get install -y")
# Exit codes: 0 = success, 1 = failed
get_package_manager_command() {
    local operation="$1"
    
    if [[ -z "$DETECTED_DISTRO" ]]; then
        log_error "No distribution detected. Run detect_distro first."
        return 1
    fi
    
    if [[ -z "$operation" ]]; then
        log_error "Operation is required (install, remove, update, upgrade, search, clean)"
        return 1
    fi
    
    local command
    command=$(read_json "$DISTROS_CONFIG" ".${DETECTED_DISTRO}.commands.${operation}" 2>/dev/null)
    
    if [[ -z "$command" || "$command" == "null" ]]; then
        log_error "Command not found for operation: $operation"
        return 1
    fi
    
    echo "$command"
    return 0
}

# Validate distribution support
# Usage: validate_distro_support
# Exit codes: 0 = supported, 1 = unsupported
validate_distro_support() {
    if [[ -z "$DETECTED_DISTRO" ]]; then
        log_error "No distribution detected"
        log_info "Please run detect_distro first"
        return 1
    fi
    
    # Check if distro exists in config
    local distro_name
    distro_name=$(read_json "$DISTROS_CONFIG" ".${DETECTED_DISTRO}.name" 2>/dev/null)
    
    if [[ -z "$distro_name" || "$distro_name" == "null" ]]; then
        log_error "Distribution not supported: $DETECTED_DISTRO"
        log_info "Supported distributions:"
        _list_supported_distros
        return 1
    fi
    
    log_info "Distribution is supported: $distro_name"
    return 0
}

# Get distribution information
# Usage: get_distro_info
# Returns: JSON object with distro information
get_distro_info() {
    if [[ -z "$DETECTED_DISTRO" ]]; then
        log_error "No distribution detected. Run detect_distro first."
        return 1
    fi
    
    read_json "$DISTROS_CONFIG" ".${DETECTED_DISTRO}" 2>/dev/null
    return $?
}
