#!/bin/bash
# lib/core.sh - Core utility functions for PrecoresHub
# Provides logging, file I/O, string manipulation, and validation utilities

# Color codes for terminal output (only set if not already defined)
if [[ -z "${COLOR_RESET}" ]]; then
    COLOR_RESET='\033[0m'
    COLOR_RED='\033[0;31m'
    COLOR_BLUE='\033[0;34m'
    COLOR_GRAY='\033[0;90m'
fi

# Log file location (only set if not already defined)
if [[ -z "${LOG_DIR}" ]]; then
    LOG_DIR="${HOME}/.cache/precoreshub/logs"
    LOG_FILE="${LOG_DIR}/precoreshub.log"
fi

# Ensure log directory exists
_ensure_log_dir() {
    if [[ ! -d "$LOG_DIR" ]]; then
        mkdir -p "$LOG_DIR" 2>/dev/null || true
    fi
}

# Log informational message
# Usage: log_info "message"
# Output: [timestamp] [INFO] message (in blue)
log_info() {
    local message="$1"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Output to stderr with color
    echo -e "${COLOR_BLUE}[${timestamp}] [INFO] ${message}${COLOR_RESET}" >&2
    
    # Log to file (without color codes)
    _ensure_log_dir
    echo "[${timestamp}] [INFO] ${message}" >> "$LOG_FILE" 2>/dev/null || true
}

# Log error message
# Usage: log_error "message"
# Output: [timestamp] [ERROR] message (in red)
log_error() {
    local message="$1"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Output to stderr with color
    echo -e "${COLOR_RED}[${timestamp}] [ERROR] ${message}${COLOR_RESET}" >&2
    
    # Log to file (without color codes)
    _ensure_log_dir
    echo "[${timestamp}] [ERROR] ${message}" >> "$LOG_FILE" 2>/dev/null || true
}

# Log debug message
# Usage: log_debug "message"
# Output: [timestamp] [DEBUG] message (in gray)
log_debug() {
    local message="$1"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Output to stderr with color
    echo -e "${COLOR_GRAY}[${timestamp}] [DEBUG] ${message}${COLOR_RESET}" >&2
    
    # Log to file (without color codes)
    _ensure_log_dir
    echo "[${timestamp}] [DEBUG] ${message}" >> "$LOG_FILE" 2>/dev/null || true
}

# Read and parse JSON file
# Usage: read_json "file_path" ["jq_filter"]
# Returns: JSON content or filtered result
# Exit codes: 0 = success, 1 = file not found, 2 = invalid JSON, 3 = jq not available
read_json() {
    local file_path="$1"
    local jq_filter="${2:-.}"  # Default to '.' (entire document)
    
    # Check if jq is available
    if ! command -v jq &> /dev/null; then
        log_error "jq is not installed. Please install jq to use JSON functionality."
        return 3
    fi
    
    # Validate file path is provided
    if [[ -z "$file_path" ]]; then
        log_error "read_json: file path is required"
        return 1
    fi
    
    # Check if file exists
    if [[ ! -f "$file_path" ]]; then
        log_error "read_json: file not found: $file_path"
        return 1
    fi
    
    # Check if file is readable
    if [[ ! -r "$file_path" ]]; then
        log_error "read_json: file not readable: $file_path"
        return 1
    fi
    
    # Parse JSON with jq
    local result
    if ! result=$(jq -r "$jq_filter" "$file_path" 2>&1); then
        log_error "read_json: invalid JSON or filter in file: $file_path"
        log_debug "jq error: $result"
        return 2
    fi
    
    echo "$result"
    return 0
}

# Write data to JSON file
# Usage: write_json "file_path" "json_content"
# Exit codes: 0 = success, 1 = invalid input, 2 = write failed, 3 = jq not available
write_json() {
    local file_path="$1"
    local json_content="$2"
    
    # Check if jq is available
    if ! command -v jq &> /dev/null; then
        log_error "jq is not installed. Please install jq to use JSON functionality."
        return 3
    fi
    
    # Validate inputs
    if [[ -z "$file_path" ]]; then
        log_error "write_json: file path is required"
        return 1
    fi
    
    if [[ -z "$json_content" ]]; then
        log_error "write_json: JSON content is required"
        return 1
    fi
    
    # Ensure parent directory exists
    local dir_path
    dir_path=$(dirname "$file_path")
    if [[ ! -d "$dir_path" ]]; then
        if ! mkdir -p "$dir_path" 2>/dev/null; then
            log_error "write_json: failed to create directory: $dir_path"
            return 2
        fi
    fi
    
    # Validate and format JSON content
    local formatted_json
    if ! formatted_json=$(echo "$json_content" | jq '.' 2>&1); then
        log_error "write_json: invalid JSON content"
        log_debug "jq error: $formatted_json"
        return 1
    fi
    
    # Write to file
    if ! echo "$formatted_json" > "$file_path" 2>/dev/null; then
        log_error "write_json: failed to write to file: $file_path"
        return 2
    fi
    
    log_debug "write_json: successfully wrote to $file_path"
    return 0
}

# ============================================================================
# String Manipulation Utilities
# ============================================================================

# Remove leading and trailing whitespace from string
# Usage: trim "  text  "
# Returns: trimmed string
# Exit codes: 0 = success
trim() {
    local text="$1"
    
    # Remove leading whitespace
    text="${text#"${text%%[![:space:]]*}"}"
    
    # Remove trailing whitespace
    text="${text%"${text##*[![:space:]]}"}"
    
    echo "$text"
    return 0
}

# Convert string to lowercase
# Usage: to_lower "TEXT"
# Returns: lowercase string
# Exit codes: 0 = success
to_lower() {
    local text="$1"
    echo "${text,,}"
    return 0
}

# Convert string to uppercase
# Usage: to_upper "text"
# Returns: uppercase string
# Exit codes: 0 = success
to_upper() {
    local text="$1"
    echo "${text^^}"
    return 0
}

# Check if string contains substring
# Usage: str_contains "haystack" "needle"
# Exit codes: 0 = contains, 1 = does not contain
str_contains() {
    local haystack="$1"
    local needle="$2"
    
    if [[ -z "$needle" ]]; then
        # Empty needle is always contained
        return 0
    fi
    
    if [[ "$haystack" == *"$needle"* ]]; then
        return 0
    else
        return 1
    fi
}

# Replace substring in string
# Usage: str_replace "original text" "search" "replace"
# Returns: modified string
# Exit codes: 0 = success
str_replace() {
    local text="$1"
    local search="$2"
    local replace="$3"
    
    # Use bash parameter expansion for replacement
    echo "${text//$search/$replace}"
    return 0
}

# Split string by delimiter
# Usage: str_split "a,b,c" ","
# Returns: array elements on separate lines
# Exit codes: 0 = success
str_split() {
    local text="$1"
    local delimiter="$2"
    
    if [[ -z "$delimiter" ]]; then
        log_error "str_split: delimiter is required"
        return 1
    fi
    
    # Use IFS to split string
    local IFS="$delimiter"
    local -a parts
    read -ra parts <<< "$text"
    
    # Output each part on a separate line
    printf '%s\n' "${parts[@]}"
    return 0
}

# ============================================================================
# Validation Functions
# ============================================================================

# Check if string is empty
# Usage: is_empty "text"
# Exit codes: 0 = empty (true), 1 = not empty (false)
is_empty() {
    local text="$1"
    
    if [[ -z "$text" ]]; then
        return 0  # Empty
    else
        return 1  # Not empty
    fi
}

# Check if string is a valid number (integer or decimal)
# Usage: is_number "123" or is_number "123.45"
# Exit codes: 0 = is number (true), 1 = not a number (false)
is_number() {
    local text="$1"
    
    # Check if empty
    if [[ -z "$text" ]]; then
        return 1
    fi
    
    # Check if it matches number pattern (optional sign, digits, optional decimal)
    if [[ "$text" =~ ^[+-]?[0-9]+\.?[0-9]*$ ]] || [[ "$text" =~ ^[+-]?[0-9]*\.[0-9]+$ ]]; then
        return 0  # Is a number
    else
        return 1  # Not a number
    fi
}

# Check if path is valid (exists and is accessible)
# Usage: is_valid_path "/path/to/file"
# Exit codes: 0 = valid path (true), 1 = invalid path (false)
is_valid_path() {
    local path="$1"
    
    # Check if empty
    if [[ -z "$path" ]]; then
        return 1
    fi
    
    # Expand tilde and environment variables
    path="${path/#\~/$HOME}"
    
    # Check if path exists (file or directory)
    if [[ -e "$path" ]]; then
        return 0  # Valid path
    else
        return 1  # Invalid path
    fi
}

# Check if string is valid JSON
# Usage: is_valid_json '{"key": "value"}'
# Exit codes: 0 = valid JSON (true), 1 = invalid JSON (false), 2 = jq not available
is_valid_json() {
    local json_string="$1"
    
    # Check if jq is available
    if ! command -v jq &> /dev/null; then
        log_error "jq is not installed. Please install jq to use JSON validation."
        return 2
    fi
    
    # Check if empty
    if [[ -z "$json_string" ]]; then
        return 1
    fi
    
    # Try to parse with jq
    if echo "$json_string" | jq empty 2>/dev/null; then
        return 0  # Valid JSON
    else
        return 1  # Invalid JSON
    fi
}

# Check if command is available in PATH
# Usage: is_command_available "git"
# Exit codes: 0 = command available (true), 1 = command not available (false)
is_command_available() {
    local command_name="$1"
    
    # Check if empty
    if [[ -z "$command_name" ]]; then
        return 1
    fi
    
    # Check if command exists in PATH
    if command -v "$command_name" &> /dev/null; then
        return 0  # Command available
    else
        return 1  # Command not available
    fi
}
