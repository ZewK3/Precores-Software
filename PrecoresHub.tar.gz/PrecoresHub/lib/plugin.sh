#!/bin/bash
# lib/plugin.sh - Plugin system for PrecoresHub
# Manages plugin discovery, loading, and execution

# Source dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/core.sh"

# Plugin configuration
readonly PLUGIN_DIR="${SCRIPT_DIR}/../plugins"
readonly USER_PLUGIN_DIR="${HOME}/.config/precoreshub/plugins"
readonly PLUGIN_EXTENSION=".phub"

# Plugin state
declare -gA LOADED_PLUGINS
declare -gA ENABLED_PLUGINS

# Initialize plugin system
# Usage: plugin_init
plugin_init() {
    log_debug "Initializing plugin system..."
    
    # Ensure plugin directories exist
    if [[ ! -d "$PLUGIN_DIR" ]]; then
        mkdir -p "$PLUGIN_DIR" 2>/dev/null || log_error "Failed to create plugin directory: $PLUGIN_DIR"
    fi
    
    if [[ ! -d "$USER_PLUGIN_DIR" ]]; then
        mkdir -p "$USER_PLUGIN_DIR" 2>/dev/null || log_error "Failed to create user plugin directory: $USER_PLUGIN_DIR"
    fi
    
    log_info "Plugin system initialized"
    return 0
}

# Discover available plugins
# Usage: plugin_discover
# Returns: JSON array of discovered plugins
plugin_discover() {
    log_debug "Discovering plugins..."
    
    local plugins="[]"
    
    # Search in system plugin directory
    if [[ -d "$PLUGIN_DIR" ]]; then
        for plugin_file in "$PLUGIN_DIR"/*"$PLUGIN_EXTENSION"; do
            if [[ -f "$plugin_file" ]]; then
                local plugin_name=$(basename "$plugin_file" "$PLUGIN_EXTENSION")
                plugins=$(echo "$plugins" | jq --arg name "$plugin_name" --arg path "$plugin_file" '. += [{"name": $name, "path": $path, "type": "system"}]')
            fi
        done
    fi
    
    # Search in user plugin directory
    if [[ -d "$USER_PLUGIN_DIR" ]]; then
        for plugin_file in "$USER_PLUGIN_DIR"/*"$PLUGIN_EXTENSION"; do
            if [[ -f "$plugin_file" ]]; then
                local plugin_name=$(basename "$plugin_file" "$PLUGIN_EXTENSION")
                plugins=$(echo "$plugins" | jq --arg name "$plugin_name" --arg path "$plugin_file" '. += [{"name": $name, "path": $path, "type": "user"}]')
            fi
        done
    fi
    
    echo "$plugins"
    return 0
}

# Load plugin
# Usage: plugin_load "plugin_name"
plugin_load() {
    local plugin_name="$1"
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_load: plugin_name is required"
        return 1
    fi
    
    # Check if already loaded
    if [[ -n "${LOADED_PLUGINS[$plugin_name]}" ]]; then
        log_debug "Plugin already loaded: $plugin_name"
        return 0
    fi
    
    # Find plugin file
    local plugin_file=""
    if [[ -f "$USER_PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}" ]]; then
        plugin_file="$USER_PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}"
    elif [[ -f "$PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}" ]]; then
        plugin_file="$PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}"
    else
        log_error "Plugin not found: $plugin_name"
        return 1
    fi
    
    # Validate plugin
    if ! plugin_validate "$plugin_file"; then
        log_error "Plugin validation failed: $plugin_name"
        return 1
    fi
    
    # Load plugin metadata
    local metadata=$(read_json "$plugin_file" 2>/dev/null)
    if [[ -z "$metadata" ]]; then
        log_error "Failed to read plugin metadata: $plugin_name"
        return 1
    fi
    
    # Mark as loaded
    LOADED_PLUGINS[$plugin_name]="$plugin_file"
    
    log_info "Plugin loaded: $plugin_name"
    return 0
}

# Validate plugin file
# Usage: plugin_validate "plugin_file"
plugin_validate() {
    local plugin_file="$1"
    
    if [[ -z "$plugin_file" ]]; then
        log_error "plugin_validate: plugin_file is required"
        return 1
    fi
    
    # Check if file exists
    if [[ ! -f "$plugin_file" ]]; then
        log_error "Plugin file not found: $plugin_file"
        return 1
    fi
    
    # Validate JSON structure
    if ! jq empty "$plugin_file" 2>/dev/null; then
        log_error "Invalid JSON in plugin file: $plugin_file"
        return 1
    fi
    
    # Check required fields
    local required_fields=("name" "version" "description")
    for field in "${required_fields[@]}"; do
        local value=$(jq -r ".$field // null" "$plugin_file" 2>/dev/null)
        if [[ "$value" == "null" || -z "$value" ]]; then
            log_error "Missing required field '$field' in plugin: $plugin_file"
            return 1
        fi
    done
    
    log_debug "Plugin validated: $plugin_file"
    return 0
}

# Enable plugin
# Usage: plugin_enable "plugin_name"
plugin_enable() {
    local plugin_name="$1"
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_enable: plugin_name is required"
        return 1
    fi
    
    # Load plugin if not already loaded
    if [[ -z "${LOADED_PLUGINS[$plugin_name]}" ]]; then
        if ! plugin_load "$plugin_name"; then
            return 1
        fi
    fi
    
    # Mark as enabled
    ENABLED_PLUGINS[$plugin_name]="true"
    
    log_info "Plugin enabled: $plugin_name"
    return 0
}

# Disable plugin
# Usage: plugin_disable "plugin_name"
plugin_disable() {
    local plugin_name="$1"
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_disable: plugin_name is required"
        return 1
    fi
    
    # Mark as disabled
    unset ENABLED_PLUGINS[$plugin_name]
    
    log_info "Plugin disabled: $plugin_name"
    return 0
}

# List all plugins
# Usage: plugin_list [filter]
# filter: "all", "loaded", "enabled"
plugin_list() {
    local filter="${1:-all}"
    
    case "$filter" in
        "all")
            plugin_discover
            ;;
        "loaded")
            local loaded="[]"
            for plugin_name in "${!LOADED_PLUGINS[@]}"; do
                loaded=$(echo "$loaded" | jq --arg name "$plugin_name" '. += [$name]')
            done
            echo "$loaded"
            ;;
        "enabled")
            local enabled="[]"
            for plugin_name in "${!ENABLED_PLUGINS[@]}"; do
                enabled=$(echo "$enabled" | jq --arg name "$plugin_name" '. += [$name]')
            done
            echo "$enabled"
            ;;
        *)
            log_error "Invalid filter: $filter"
            return 1
            ;;
    esac
    
    return 0
}

# Execute plugin function
# Usage: plugin_execute "plugin_name" "function_name" [args...]
plugin_execute() {
    local plugin_name="$1"
    local function_name="$2"
    shift 2
    local args=("$@")
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_execute: plugin_name is required"
        return 1
    fi
    
    if [[ -z "$function_name" ]]; then
        log_error "plugin_execute: function_name is required"
        return 1
    fi
    
    # Check if plugin is enabled
    if [[ -z "${ENABLED_PLUGINS[$plugin_name]}" ]]; then
        log_error "Plugin not enabled: $plugin_name"
        return 1
    fi
    
    # Get plugin file
    local plugin_file="${LOADED_PLUGINS[$plugin_name]}"
    if [[ -z "$plugin_file" ]]; then
        log_error "Plugin not loaded: $plugin_name"
        return 1
    fi
    
    # Execute plugin function with error isolation
    log_info "Executing plugin function: $plugin_name.$function_name"
    
    # Read plugin script
    local script=$(jq -r ".functions.\"$function_name\" // null" "$plugin_file" 2>/dev/null)
    if [[ "$script" == "null" || -z "$script" ]]; then
        log_error "Function not found in plugin: $function_name"
        return 1
    fi
    
    # Execute in subshell for isolation
    (
        eval "$script"
    )
    local exit_code=$?
    
    if [[ $exit_code -ne 0 ]]; then
        log_error "Plugin function failed: $plugin_name.$function_name (exit code: $exit_code)"
        return 1
    fi
    
    log_info "Plugin function completed: $plugin_name.$function_name"
    return 0
}

# Get plugin metadata
# Usage: plugin_get_metadata "plugin_name" [field]
plugin_get_metadata() {
    local plugin_name="$1"
    local field="${2:-}"
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_get_metadata: plugin_name is required"
        return 1
    fi
    
    # Get plugin file
    local plugin_file="${LOADED_PLUGINS[$plugin_name]}"
    if [[ -z "$plugin_file" ]]; then
        # Try to find plugin file
        if [[ -f "$USER_PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}" ]]; then
            plugin_file="$USER_PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}"
        elif [[ -f "$PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}" ]]; then
            plugin_file="$PLUGIN_DIR/${plugin_name}${PLUGIN_EXTENSION}"
        else
            log_error "Plugin not found: $plugin_name"
            return 1
        fi
    fi
    
    # Read metadata
    if [[ -n "$field" ]]; then
        jq -r ".$field // null" "$plugin_file" 2>/dev/null
    else
        read_json "$plugin_file" 2>/dev/null
    fi
    
    return 0
}

# Check if plugin is loaded
# Usage: plugin_is_loaded "plugin_name"
plugin_is_loaded() {
    local plugin_name="$1"
    
    [[ -n "${LOADED_PLUGINS[$plugin_name]}" ]]
    return $?
}

# Check if plugin is enabled
# Usage: plugin_is_enabled "plugin_name"
plugin_is_enabled() {
    local plugin_name="$1"
    
    [[ -n "${ENABLED_PLUGINS[$plugin_name]}" ]]
    return $?
}

# Unload plugin
# Usage: plugin_unload "plugin_name"
plugin_unload() {
    local plugin_name="$1"
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_unload: plugin_name is required"
        return 1
    fi
    
    # Disable first
    plugin_disable "$plugin_name"
    
    # Unload
    unset LOADED_PLUGINS[$plugin_name]
    
    log_info "Plugin unloaded: $plugin_name"
    return 0
}

# Get plugin count
# Usage: plugin_count [filter]
plugin_count() {
    local filter="${1:-all}"
    
    case "$filter" in
        "all")
            plugin_discover | jq 'length'
            ;;
        "loaded")
            echo "${#LOADED_PLUGINS[@]}"
            ;;
        "enabled")
            echo "${#ENABLED_PLUGINS[@]}"
            ;;
        *)
            echo "0"
            ;;
    esac
    
    return 0
}

# Check plugin dependencies
# Usage: plugin_check_dependencies "plugin_name"
plugin_check_dependencies() {
    local plugin_name="$1"
    
    if [[ -z "$plugin_name" ]]; then
        log_error "plugin_check_dependencies: plugin_name is required"
        return 1
    fi
    
    # Get dependencies
    local dependencies=$(plugin_get_metadata "$plugin_name" "dependencies" 2>/dev/null)
    
    if [[ "$dependencies" == "null" || -z "$dependencies" ]]; then
        log_debug "No dependencies for plugin: $plugin_name"
        return 0
    fi
    
    # Check each dependency
    local missing_deps=()
    while IFS= read -r dep; do
        if ! command -v "$dep" &>/dev/null; then
            missing_deps+=("$dep")
        fi
    done < <(echo "$dependencies" | jq -r '.[]' 2>/dev/null)
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        log_error "Missing dependencies for plugin $plugin_name: ${missing_deps[*]}"
        return 1
    fi
    
    log_debug "All dependencies satisfied for plugin: $plugin_name"
    return 0
}

# ============================================================================
# Plugin API Functions
# These functions are available to plugins for interacting with PrecoresHub
# ============================================================================

# Install package using current package manager
# Usage: phub_install_package "package_name"
# Exit codes: 0 = success, 1 = failed
phub_install_package() {
    local package_name="$1"
    
    if [[ -z "$package_name" ]]; then
        log_error "phub_install_package: package_name is required"
        return 1
    fi
    
    log_info "Plugin API: Installing package: $package_name"
    
    # Source package manager if not already loaded
    if ! declare -f pkg_install &>/dev/null; then
        source "${SCRIPT_DIR}/package_manager.sh" || {
            log_error "Failed to load package manager"
            return 1
        }
    fi
    
    # Install package
    if pkg_install "$package_name"; then
        log_info "Plugin API: Successfully installed $package_name"
        return 0
    else
        log_error "Plugin API: Failed to install $package_name"
        return 1
    fi
}

# Execute command with progress tracking
# Usage: phub_execute_command "command"
# Exit codes: 0 = success, non-zero = command exit code
phub_execute_command() {
    local command="$1"
    
    if [[ -z "$command" ]]; then
        log_error "phub_execute_command: command is required"
        return 1
    fi
    
    log_info "Plugin API: Executing command: $command"
    
    # Execute command and capture output
    local output
    local exit_code
    
    if output=$(eval "$command" 2>&1); then
        exit_code=0
        log_debug "Plugin API: Command succeeded"
        log_debug "Output: $output"
    else
        exit_code=$?
        log_error "Plugin API: Command failed with exit code $exit_code"
        log_debug "Output: $output"
    fi
    
    return $exit_code
}

# Display notification to user
# Usage: phub_notify "message" ["type"]
# type: "info" (default), "error", "success"
# Exit codes: 0 = success
phub_notify() {
    local message="$1"
    local type="${2:-info}"
    
    if [[ -z "$message" ]]; then
        log_error "phub_notify: message is required"
        return 1
    fi
    
    case "$type" in
        "info")
            log_info "Plugin Notification: $message"
            ;;
        "error")
            log_error "Plugin Notification: $message"
            ;;
        "success")
            log_info "Plugin Notification: ✓ $message"
            ;;
        *)
            log_info "Plugin Notification: $message"
            ;;
    esac
    
    return 0
}

# Get configuration value
# Usage: phub_config_get "key"
# Returns: configuration value
# Exit codes: 0 = success, 1 = failed
phub_config_get() {
    local key="$1"
    
    if [[ -z "$key" ]]; then
        log_error "phub_config_get: key is required"
        return 1
    fi
    
    log_debug "Plugin API: Getting config value for key: $key"
    
    # Source config if not already loaded
    if ! declare -f config_get &>/dev/null; then
        source "${SCRIPT_DIR}/config.sh" || {
            log_error "Failed to load config manager"
            return 1
        }
        # Initialize config if needed
        if [[ ! -f "${HOME}/.config/precoreshub/config.json" ]]; then
            config_init &>/dev/null || true
        else
            config_load &>/dev/null || true
        fi
    fi
    
    # Get config value
    local value
    if value=$(config_get "$key" 2>/dev/null); then
        echo "$value"
        return 0
    else
        log_debug "Plugin API: Config key not found: $key"
        return 1
    fi
}

# Set configuration value
# Usage: phub_config_set "key" "value"
# Exit codes: 0 = success, 1 = failed
phub_config_set() {
    local key="$1"
    local value="$2"
    
    if [[ -z "$key" ]]; then
        log_error "phub_config_set: key is required"
        return 1
    fi
    
    if [[ -z "$value" ]]; then
        log_error "phub_config_set: value is required"
        return 1
    fi
    
    log_debug "Plugin API: Setting config value: $key=$value"
    
    # Source config if not already loaded
    if ! declare -f config_set &>/dev/null; then
        source "${SCRIPT_DIR}/config.sh" || {
            log_error "Failed to load config manager"
            return 1
        }
        # Initialize config if needed
        if [[ ! -f "${HOME}/.config/precoreshub/config.json" ]]; then
            config_init &>/dev/null || true
        else
            config_load &>/dev/null || true
        fi
    fi
    
    # Set config value
    if config_set "$key" "$value"; then
        log_info "Plugin API: Config value set: $key=$value"
        return 0
    else
        log_error "Plugin API: Failed to set config value: $key=$value"
        return 1
    fi
}

# Get current distribution information
# Usage: phub_get_distro
# Returns: JSON object with distro info
# Exit codes: 0 = success, 1 = failed
phub_get_distro() {
    log_debug "Plugin API: Getting distribution information"
    
    # Source distro if not already loaded
    if ! declare -f detect_distro &>/dev/null; then
        source "${SCRIPT_DIR}/distro.sh" || {
            log_error "Failed to load distro detector"
            return 1
        }
    fi
    
    # Detect distro if not already detected
    if [[ -z "$DETECTED_DISTRO" ]]; then
        if ! detect_distro &>/dev/null; then
            log_error "Plugin API: Failed to detect distribution"
            return 1
        fi
    fi
    
    # Return distro info as JSON
    local distro_json
    distro_json=$(jq -n \
        --arg id "$DETECTED_DISTRO" \
        --arg name "$DETECTED_DISTRO_NAME" \
        --arg pkg_manager "$DETECTED_PKG_MANAGER" \
        '{
            id: $id,
            name: $name,
            package_manager: $pkg_manager
        }')
    
    echo "$distro_json"
    return 0
}

# Check if package is installed
# Usage: phub_is_installed "package_name"
# Exit codes: 0 = installed, 1 = not installed
phub_is_installed() {
    local package_name="$1"
    
    if [[ -z "$package_name" ]]; then
        log_error "phub_is_installed: package_name is required"
        return 1
    fi
    
    log_debug "Plugin API: Checking if package is installed: $package_name"
    
    # Source package manager if not already loaded
    if ! declare -f pkg_is_installed &>/dev/null; then
        source "${SCRIPT_DIR}/package_manager.sh" || {
            log_error "Failed to load package manager"
            return 1
        }
    fi
    
    # Check if package is installed
    if pkg_is_installed "$package_name" &>/dev/null; then
        log_debug "Plugin API: Package is installed: $package_name"
        return 0
    else
        log_debug "Plugin API: Package is not installed: $package_name"
        return 1
    fi
}
