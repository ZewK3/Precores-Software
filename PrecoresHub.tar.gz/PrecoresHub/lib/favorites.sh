#!/bin/bash
# lib/favorites.sh - Favorites/bookmarks system for PrecoresHub
# Manages user's favorite applications for quick access

# Source dependencies
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/core.sh"

# Favorites configuration
readonly FAVORITES_DIR="${HOME}/.config/precoreshub"
readonly FAVORITES_FILE="${FAVORITES_DIR}/favorites.json"

# Initialize favorites system
_favorites_init() {
    # Ensure favorites directory exists
    if [[ ! -d "$FAVORITES_DIR" ]]; then
        mkdir -p "$FAVORITES_DIR" 2>/dev/null || return 1
    fi
    
    # Create empty favorites file if it doesn't exist
    if [[ ! -f "$FAVORITES_FILE" ]]; then
        local empty_favorites='{"applications":[]}'
        write_json "$FAVORITES_FILE" "$empty_favorites" 2>/dev/null || return 1
    fi
    
    return 0
}

# Add application to favorites
# Usage: favorites_add "docker"
favorites_add() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "favorites_add: app_name is required"
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Check if already favorited
    if favorites_is_favorite "$app_name" 2>/dev/null; then
        log_info "Application already in favorites: $app_name"
        return 0
    fi
    
    # Read current favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        log_error "Failed to read favorites file"
        return 1
    fi
    
    # Add to favorites
    local updated_favorites
    updated_favorites=$(echo "$favorites_json" | jq \
        --arg app "$app_name" \
        '.applications += [$app] | .applications |= unique')
    
    # Write updated favorites
    if ! write_json "$FAVORITES_FILE" "$updated_favorites" 2>/dev/null; then
        log_error "Failed to write favorites file"
        return 1
    fi
    
    log_info "Added to favorites: $app_name"
    return 0
}

# Remove application from favorites
# Usage: favorites_remove "docker"
favorites_remove() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "favorites_remove: app_name is required"
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Read current favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        log_error "Failed to read favorites file"
        return 1
    fi
    
    # Remove from favorites
    local updated_favorites
    updated_favorites=$(echo "$favorites_json" | jq \
        --arg app "$app_name" \
        '.applications -= [$app]')
    
    # Write updated favorites
    if ! write_json "$FAVORITES_FILE" "$updated_favorites" 2>/dev/null; then
        log_error "Failed to write favorites file"
        return 1
    fi
    
    log_info "Removed from favorites: $app_name"
    return 0
}

# List all favorite applications
# Usage: favorites_list
# Returns: JSON array of favorite applications
favorites_list() {
    # Initialize if needed
    _favorites_init || return 1
    
    # Read favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        log_error "Failed to read favorites file"
        return 1
    fi
    
    # Return applications array
    echo "$favorites_json" | jq -r '.applications[]'
    return 0
}

# Check if application is favorited
# Usage: favorites_is_favorite "docker"
# Exit codes: 0 = is favorite, 1 = not favorite
favorites_is_favorite() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Read favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        return 1
    fi
    
    # Check if app is in favorites
    local is_favorite
    is_favorite=$(echo "$favorites_json" | jq \
        --arg app "$app_name" \
        '.applications | contains([$app])')
    
    if [[ "$is_favorite" == "true" ]]; then
        return 0
    else
        return 1
    fi
}

# Install all favorite applications
# Usage: favorites_install_all
favorites_install_all() {
    log_info "Installing all favorite applications..."
    
    # Get list of favorites
    local favorites
    if ! favorites=$(favorites_list 2>/dev/null); then
        log_error "Failed to get favorites list"
        return 1
    fi
    
    # Check if there are any favorites
    if [[ -z "$favorites" ]]; then
        log_info "No favorite applications to install"
        return 0
    fi
    
    # Count favorites
    local count=$(echo "$favorites" | wc -l)
    log_info "Found $count favorite application(s)"
    
    # Source package manager if not already loaded
    if ! declare -f pkg_install &>/dev/null; then
        source "${SCRIPT_DIR}/package_manager.sh"
    fi
    
    # Install each favorite
    local success=0
    local failed=0
    
    while IFS= read -r app; do
        log_info "Installing: $app"
        if pkg_install "$app" 2>/dev/null; then
            ((success++))
        else
            ((failed++))
            log_error "Failed to install: $app"
        fi
    done <<< "$favorites"
    
    log_info "Installation complete: $success succeeded, $failed failed"
    
    if [[ $failed -eq 0 ]]; then
        return 0
    else
        return 1
    fi
}

# Display favorites menu
# Usage: favorites_menu
favorites_menu() {
    log_info "=== Favorites Menu ==="
    
    # Get list of favorites
    local favorites
    if ! favorites=$(favorites_list 2>/dev/null); then
        log_error "Failed to get favorites list"
        return 1
    fi
    
    # Check if there are any favorites
    if [[ -z "$favorites" ]]; then
        echo ""
        echo "No favorite applications yet."
        echo ""
        echo "To add favorites:"
        echo "  1. Navigate to an application in QuickInstall"
        echo "  2. Select 'Add to Favorites'"
        echo ""
        return 0
    fi
    
    # Display favorites
    echo ""
    echo "Your Favorite Applications:"
    echo ""
    
    local index=1
    while IFS= read -r app; do
        echo "  ★ $index. $app"
        ((index++))
    done <<< "$favorites"
    
    echo ""
    echo "Options:"
    echo "  [I] Install all favorites"
    echo "  [R] Remove from favorites"
    echo "  [Q] Back to main menu"
    echo ""
    
    return 0
}

# Get favorites count
# Usage: favorites_count
# Returns: number of favorite applications
favorites_count() {
    # Initialize if needed
    _favorites_init || return 1
    
    # Read favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        echo "0"
        return 0
    fi
    
    # Count applications
    echo "$favorites_json" | jq '.applications | length'
    return 0
}

# Toggle favorite status
# Usage: favorites_toggle "docker"
favorites_toggle() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "favorites_toggle: app_name is required"
        return 1
    fi
    
    if favorites_is_favorite "$app_name" 2>/dev/null; then
        favorites_remove "$app_name"
    else
        favorites_add "$app_name"
    fi
    
    return $?
}

# Get favorite indicator for display
# Usage: favorites_get_indicator "docker"
# Returns: "★" if favorite, "" if not
favorites_get_indicator() {
    local app_name="$1"
    
    if favorites_is_favorite "$app_name" 2>/dev/null; then
        echo "★"
    else
        echo ""
    fi
    
    return 0
}

# Export favorites
# Usage: favorites_export > favorites.json
favorites_export() {
    # Initialize if needed
    _favorites_init || return 1
    
    # Read and output favorites
    read_json "$FAVORITES_FILE" 2>/dev/null
    return $?
}

# Import favorites
# Usage: favorites_import < favorites.json
favorites_import() {
    local import_json="$1"
    
    if [[ -z "$import_json" ]]; then
        log_error "favorites_import: JSON data is required"
        return 1
    fi
    
    # Validate JSON
    if ! echo "$import_json" | jq empty 2>/dev/null; then
        log_error "Invalid JSON data"
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Write imported favorites
    if ! write_json "$FAVORITES_FILE" "$import_json" 2>/dev/null; then
        log_error "Failed to import favorites"
        return 1
    fi
    
    log_info "Favorites imported successfully"
    return 0
}
