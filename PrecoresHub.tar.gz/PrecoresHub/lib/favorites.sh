#!/bin/bash
# lib/favorites.sh - Favorites/bookmarks system for PrecoresHub
# Manages user's favorite applications for quick access

# Source dependencies
if [[ -z "$SCRIPT_DIR" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fi
source "${SCRIPT_DIR}/lib/core.sh"

# Favorites configuration
readonly FAVORITES_DIR="${HOME}/.config/precoreshub"
readonly FAVORITES_FILE="${FAVORITES_DIR}/favorites.json"

# Initialize favorites system
_favorites_init() {
    # Ensure favorites directory exists
    if [[ ! -d "$FAVORITES_DIR" ]]; then
        mkdir -p "$FAVORITES_DIR" 2>/dev/null || return 1
    fi
    
    # Create empty favorites file if it doesn't exist
    if [[ ! -f "$FAVORITES_FILE" ]]; then
        local empty_favorites='{"applications":[]}'
        write_json "$FAVORITES_FILE" "$empty_favorites" 2>/dev/null || return 1
    fi
    
    return 0
}

# Add application to favorites
# Usage: favorites_add "docker"
favorites_add() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "favorites_add: app_name is required"
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Check if already favorited
    if favorites_is_favorite "$app_name" 2>/dev/null; then
        log_info "Application already in favorites: $app_name"
        return 0
    fi
    
    # Read current favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        log_error "Failed to read favorites file"
        return 1
    fi
    
    # Add to favorites
    local updated_favorites
    updated_favorites=$(echo "$favorites_json" | jq \
        --arg app "$app_name" \
        '.applications += [$app] | .applications |= unique')
    
    # Write updated favorites
    if ! write_json "$FAVORITES_FILE" "$updated_favorites" 2>/dev/null; then
        log_error "Failed to write favorites file"
        return 1
    fi
    
    log_info "Added to favorites: $app_name"
    return 0
}

# Remove application from favorites
# Usage: favorites_remove "docker"
favorites_remove() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "favorites_remove: app_name is required"
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Read current favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        log_error "Failed to read favorites file"
        return 1
    fi
    
    # Remove from favorites
    local updated_favorites
    updated_favorites=$(echo "$favorites_json" | jq \
        --arg app "$app_name" \
        '.applications -= [$app]')
    
    # Write updated favorites
    if ! write_json "$FAVORITES_FILE" "$updated_favorites" 2>/dev/null; then
        log_error "Failed to write favorites file"
        return 1
    fi
    
    log_info "Removed from favorites: $app_name"
    return 0
}

# List all favorite applications
# Usage: favorites_list
# Returns: JSON array of favorite applications
favorites_list() {
    # Initialize if needed
    _favorites_init || return 1
    
    # Read favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        log_error "Failed to read favorites file"
        return 1
    fi
    
    # Return applications array
    echo "$favorites_json" | jq -r '.applications[]'
    return 0
}

# Check if application is favorited
# Usage: favorites_is_favorite "docker"
# Exit codes: 0 = is favorite, 1 = not favorite
favorites_is_favorite() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Read favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        return 1
    fi
    
    # Check if app is in favorites
    local is_favorite
    is_favorite=$(echo "$favorites_json" | jq \
        --arg app "$app_name" \
        '.applications | contains([$app])')
    
    if [[ "$is_favorite" == "true" ]]; then
        return 0
    else
        return 1
    fi
}

# Install all favorite applications
# Usage: favorites_install_all
favorites_install_all() {
    log_info "Installing all favorite applications..."
    
    # Get list of favorites
    local favorites
    if ! favorites=$(favorites_list 2>/dev/null); then
        log_error "Failed to get favorites list"
        return 1
    fi
    
    # Check if there are any favorites
    if [[ -z "$favorites" ]]; then
        log_info "No favorite applications to install"
        return 0
    fi
    
    # Count favorites
    local count=$(echo "$favorites" | wc -l)
    log_info "Found $count favorite application(s)"
    
    # Source package manager if not already loaded
    if ! declare -f pkg_install &>/dev/null; then
        source "${SCRIPT_DIR}/package_manager.sh"
    fi
    
    # Install each favorite
    local success=0
    local failed=0
    
    while IFS= read -r app; do
        log_info "Installing: $app"
        if pkg_install "$app" 2>/dev/null; then
            ((success++))
        else
            ((failed++))
            log_error "Failed to install: $app"
        fi
    done <<< "$favorites"
    
    log_info "Installation complete: $success succeeded, $failed failed"
    
    if [[ $failed -eq 0 ]]; then
        return 0
    else
        return 1
    fi
}

# Display favorites menu with fzf interface
# Usage: favorites_menu
favorites_menu() {
    log_info "=== Favorites Menu ==="
    
    while true; do
        # Get list of favorites
        local favorites
        if ! favorites=$(favorites_list 2>/dev/null); then
            log_error "Failed to get favorites list"
            return 1
        fi
        
        # Check if there are any favorites
        if [[ -z "$favorites" ]]; then
            local choice=$(cat <<EOF | fzf --ansi --reverse --height=50% --border=rounded --prompt="No favorites > " --header="╔══════════════════════════════════════════════════════════╗
║              NO FAVORITE APPLICATIONS                ║
╚══════════════════════════════════════════════════════════╝

To add favorites:
  1. Navigate to an application in QuickInstall
  2. Select 'Add to Favorites'
" --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af"
[OK] Back to Main Menu
EOF
)
            return 0
        fi
        
        # Count favorites
        local count=$(echo "$favorites" | wc -l)
        
        # Build favorites list with star indicator
        local fav_list=""
        while IFS= read -r app; do
            fav_list="${fav_list}★ ${app}\n"
        done <<< "$favorites"
        
        # Show menu
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║              FAVORITES - BOOKMARKED APPS             ║
╚══════════════════════════════════════════════════════════╝

Your Favorite Applications ($count):

$(echo -e "$fav_list")
" --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af"
[01] Install All Favorites  - Install all bookmarked apps
[02] Remove from Favorites  - Remove an app from favorites
[03] Install Single App     - Install one favorite app
[04] Export Favorites       - Export to JSON file
[05] Import Favorites       - Import from JSON file
[00] Back to Main Menu      - Return
EOF
)
        
        [[ -z "$choice" ]] && return 0
        
        case "${choice:1:2}" in
            01) favorites_install_all_ui ;;
            02) favorites_remove_ui ;;
            03) favorites_install_single_ui ;;
            04) favorites_export_ui ;;
            05) favorites_import_ui ;;
            00) return 0 ;;
        esac
    done
}

# Install all favorites with UI
favorites_install_all_ui() {
    log_info "Installing all favorite applications..."
    
    # Get list of favorites
    local favorites
    if ! favorites=$(favorites_list 2>/dev/null); then
        log_error "Failed to get favorites list"
        sleep 2
        return 1
    fi
    
    if [[ -z "$favorites" ]]; then
        log_info "No favorite applications to install"
        sleep 2
        return 0
    fi
    
    # Count favorites
    local count=$(echo "$favorites" | wc -l)
    
    # Confirm installation
    local confirm=$(cat <<EOF | fzf --ansi --reverse --height=50% --border=rounded --prompt="Confirm? > " --header="╔══════════════════════════════════════════════════════════╗
║            INSTALL ALL FAVORITES                     ║
╚══════════════════════════════════════════════════════════╝

This will install $count application(s):
$(echo "$favorites" | sed 's/^/  - /')

" --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1"
[Yes] Install all
[No] Cancel
EOF
)
    
    [[ "$confirm" != "[Yes]"* ]] && return 0
    
    # Source package manager if not already loaded
    if ! declare -f pkg_install &>/dev/null; then
        source "${SCRIPT_DIR}/lib/package_manager.sh"
    fi
    
    # Install each favorite
    clear
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║         Installing Favorite Applications                ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    local success=0
    local failed=0
    
    while IFS= read -r app; do
        echo "Installing: $app"
        if pkg_install "$app" 2>/dev/null; then
            echo "  ✓ Success"
            ((success++))
        else
            echo "  ✗ Failed"
            ((failed++))
        fi
        echo ""
    done <<< "$favorites"
    
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║              Installation Complete                       ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    echo "Results: $success succeeded, $failed failed"
    echo ""
    read -p "Press Enter to continue..."
}

# Remove from favorites with UI
favorites_remove_ui() {
    # Get list of favorites
    local favorites
    if ! favorites=$(favorites_list 2>/dev/null); then
        log_error "Failed to get favorites list"
        sleep 2
        return 1
    fi
    
    if [[ -z "$favorites" ]]; then
        log_info "No favorites to remove"
        sleep 2
        return 0
    fi
    
    # Build selection list
    local fav_list=""
    while IFS= read -r app; do
        fav_list="${fav_list}★ ${app}\n"
    done <<< "$favorites"
    
    # Select app to remove
    local selection=$(echo -e "$fav_list" | fzf --ansi --reverse --height=70% --border=rounded \
        --prompt="Select app to remove > " \
        --header="╔══════════════════════════════════════════════════════════╗
║           REMOVE FROM FAVORITES                      ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#f38ba8,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#f38ba8")
    
    [[ -z "$selection" ]] && return 0
    
    # Extract app name
    local app_name=$(echo "$selection" | sed 's/^★ //')
    
    # Remove from favorites
    if favorites_remove "$app_name"; then
        log_success "Removed '$app_name' from favorites"
    else
        log_error "Failed to remove '$app_name' from favorites"
    fi
    sleep 2
}

# Install single favorite with UI
favorites_install_single_ui() {
    # Get list of favorites
    local favorites
    if ! favorites=$(favorites_list 2>/dev/null); then
        log_error "Failed to get favorites list"
        sleep 2
        return 1
    fi
    
    if [[ -z "$favorites" ]]; then
        log_info "No favorites to install"
        sleep 2
        return 0
    fi
    
    # Build selection list
    local fav_list=""
    while IFS= read -r app; do
        fav_list="${fav_list}★ ${app}\n"
    done <<< "$favorites"
    
    # Select app to install
    local selection=$(echo -e "$fav_list" | fzf --ansi --reverse --height=70% --border=rounded \
        --prompt="Select app to install > " \
        --header="╔══════════════════════════════════════════════════════════╗
║            INSTALL FAVORITE APP                      ║
╚══════════════════════════════════════════════════════════╝
" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1")
    
    [[ -z "$selection" ]] && return 0
    
    # Extract app name
    local app_name=$(echo "$selection" | sed 's/^★ //')
    
    # Source package manager if not already loaded
    if ! declare -f pkg_install &>/dev/null; then
        source "${SCRIPT_DIR}/lib/package_manager.sh"
    fi
    
    # Install app
    clear
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║              Installing: $app_name"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    if pkg_install "$app_name"; then
        echo ""
        echo "✓ Installation successful!"
    else
        echo ""
        echo "✗ Installation failed!"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Export favorites with UI
favorites_export_ui() {
    local export_file="${HOME}/precoreshub_favorites_$(date +%Y%m%d_%H%M%S).json"
    
    if favorites_export > "$export_file" 2>/dev/null; then
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=40% --border=rounded --prompt="Export complete > " --header="╔══════════════════════════════════════════════════════════╗
║              EXPORT SUCCESSFUL                       ║
╚══════════════════════════════════════════════════════════╝

Favorites exported to:
  $export_file
" --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1"
[OK] Continue
EOF
)
    else
        log_error "Failed to export favorites"
        sleep 2
    fi
}

# Import favorites with UI
favorites_import_ui() {
    log_info "Import favorites feature - Coming soon"
    sleep 2
}

# Get favorites count
# Usage: favorites_count
# Returns: number of favorite applications
favorites_count() {
    # Initialize if needed
    _favorites_init || return 1
    
    # Read favorites
    local favorites_json
    if ! favorites_json=$(read_json "$FAVORITES_FILE" 2>/dev/null); then
        echo "0"
        return 0
    fi
    
    # Count applications
    echo "$favorites_json" | jq '.applications | length'
    return 0
}

# Toggle favorite status
# Usage: favorites_toggle "docker"
favorites_toggle() {
    local app_name="$1"
    
    if [[ -z "$app_name" ]]; then
        log_error "favorites_toggle: app_name is required"
        return 1
    fi
    
    if favorites_is_favorite "$app_name" 2>/dev/null; then
        favorites_remove "$app_name"
    else
        favorites_add "$app_name"
    fi
    
    return $?
}

# Get favorite indicator for display
# Usage: favorites_get_indicator "docker"
# Returns: "★" if favorite, "" if not
favorites_get_indicator() {
    local app_name="$1"
    
    if favorites_is_favorite "$app_name" 2>/dev/null; then
        echo "★"
    else
        echo ""
    fi
    
    return 0
}

# Export favorites
# Usage: favorites_export > favorites.json
favorites_export() {
    # Initialize if needed
    _favorites_init || return 1
    
    # Read and output favorites
    read_json "$FAVORITES_FILE" 2>/dev/null
    return $?
}

# Import favorites
# Usage: favorites_import < favorites.json
favorites_import() {
    local import_json="$1"
    
    if [[ -z "$import_json" ]]; then
        log_error "favorites_import: JSON data is required"
        return 1
    fi
    
    # Validate JSON
    if ! echo "$import_json" | jq empty 2>/dev/null; then
        log_error "Invalid JSON data"
        return 1
    fi
    
    # Initialize if needed
    _favorites_init || return 1
    
    # Write imported favorites
    if ! write_json "$FAVORITES_FILE" "$import_json" 2>/dev/null; then
        log_error "Failed to import favorites"
        return 1
    fi
    
    log_info "Favorites imported successfully"
    return 0
}
