#!/bin/bash
# Test progress tracking integration with package manager

# Source libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/distro.sh"
source "${SCRIPT_DIR}/../lib/progress.sh"
source "${SCRIPT_DIR}/../lib/package_manager.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test function
test_case() {
    local test_name="$1"
    local test_func="$2"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "Running: $test_name"
    
    if $test_func; then
        TESTS_PASSED=$((TESTS_PASSED + 1))
        echo "✓ PASSED: $test_name"
    else
        TESTS_FAILED=$((TESTS_FAILED + 1))
        echo "✗ FAILED: $test_name"
    fi
    echo ""
}

# Test: Progress tracking is called during pkg_install
test_progress_in_pkg_install() {
    # Mock progress functions to track calls
    local progress_start_called=false
    local progress_complete_called=false
    
    progress_start() {
        progress_start_called=true
        return 0
    }
    
    progress_complete() {
        progress_complete_called=true
        return 0
    }
    
    # Detect distro first
    detect_distro || return 1
    
    # Try to install a package (will fail but should call progress functions)
    # Use NO_PROGRESS=0 to ensure progress is shown
    NO_PROGRESS=0 pkg_install "nonexistent-test-package-12345" 2>/dev/null || true
    
    # Check if progress functions were called
    if [[ "$progress_start_called" == "true" ]] && [[ "$progress_complete_called" == "true" ]]; then
        return 0
    else
        echo "Progress functions not called: start=$progress_start_called, complete=$progress_complete_called"
        return 1
    fi
}

# Test: Progress tracking can be disabled with NO_PROGRESS
test_no_progress_flag() {
    # Mock progress functions to track calls
    local progress_called=false
    
    progress_start() {
        progress_called=true
        return 0
    }
    
    progress_complete() {
        progress_called=true
        return 0
    }
    
    # Detect distro first
    detect_distro || return 1
    
    # Try to install with NO_PROGRESS=1
    NO_PROGRESS=1 pkg_install "nonexistent-test-package-12345" 2>/dev/null || true
    
    # Progress should NOT be called
    if [[ "$progress_called" == "false" ]]; then
        return 0
    else
        echo "Progress was called despite NO_PROGRESS=1"
        return 1
    fi
}

# Test: Progress tracking in pkg_update_system
test_progress_in_update_system() {
    # Mock progress functions to track calls
    local progress_start_called=false
    local progress_complete_called=false
    
    progress_start() {
        progress_start_called=true
        return 0
    }
    
    progress_complete() {
        progress_complete_called=true
        return 0
    }
    
    # Detect distro first
    detect_distro || return 1
    
    # Try to update system (may fail but should call progress functions)
    NO_PROGRESS=0 pkg_update_system 2>/dev/null || true
    
    # Check if progress functions were called
    if [[ "$progress_start_called" == "true" ]] && [[ "$progress_complete_called" == "true" ]]; then
        return 0
    else
        echo "Progress functions not called: start=$progress_start_called, complete=$progress_complete_called"
        return 1
    fi
}

# Test: Progress complete is called with correct status on success
test_progress_status_success() {
    local progress_status=""
    
    progress_start() {
        return 0
    }
    
    progress_complete() {
        progress_status="$1"
        return 0
    }
    
    # Detect distro first
    detect_distro || return 1
    
    # Mock successful install by overriding eval
    eval() {
        if [[ "$*" == *"install"* ]]; then
            return 0  # Success
        fi
        command eval "$@"
    }
    
    # Try to install
    NO_PROGRESS=0 pkg_install "test-package" 2>/dev/null
    
    # Check if progress_complete was called with "success"
    if [[ "$progress_status" == "success" ]]; then
        return 0
    else
        echo "Expected progress status 'success', got '$progress_status'"
        return 1
    fi
}

# Test: Progress complete is called with correct status on failure
test_progress_status_failure() {
    local progress_status=""
    
    progress_start() {
        return 0
    }
    
    progress_complete() {
        progress_status="$1"
        return 0
    }
    
    # Detect distro first
    detect_distro || return 1
    
    # Mock failed install by overriding eval
    eval() {
        if [[ "$*" == *"install"* ]]; then
            return 1  # Failure
        fi
        command eval "$@"
    }
    
    # Try to install
    NO_PROGRESS=0 pkg_install "test-package" 2>/dev/null || true
    
    # Check if progress_complete was called with "failed"
    if [[ "$progress_status" == "failed" ]]; then
        return 0
    else
        echo "Expected progress status 'failed', got '$progress_status'"
        return 1
    fi
}

################################################################################
# RUN TESTS
################################################################################

echo "========================================"
echo "Progress Integration Tests"
echo "========================================"
echo ""

test_case "Progress tracking in pkg_install" test_progress_in_pkg_install
test_case "NO_PROGRESS flag disables progress" test_no_progress_flag
test_case "Progress tracking in pkg_update_system" test_progress_in_update_system
test_case "Progress status on success" test_progress_status_success
test_case "Progress status on failure" test_progress_status_failure

echo "========================================"
echo "Test Summary"
echo "========================================"
echo "Total: $TESTS_RUN"
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
