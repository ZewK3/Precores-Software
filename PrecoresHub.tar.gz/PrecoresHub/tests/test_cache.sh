#!/bin/bash
# Unit tests for lib/cache.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/cache.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

# Backup and cleanup
backup_cache() {
    if [[ -f "$CACHE_FILE" ]]; then
        cp "$CACHE_FILE" "${CACHE_FILE}.backup"
    fi
}

restore_cache() {
    if [[ -f "${CACHE_FILE}.backup" ]]; then
        mv "${CACHE_FILE}.backup" "$CACHE_FILE"
    else
        rm -f "$CACHE_FILE"
    fi
}

echo "========================================"
echo "Testing lib/cache.sh"
echo "========================================"
echo ""

# Backup existing cache
backup_cache

# Test 1: cache_init creates cache file
echo "Test 1: cache_init creates cache file"
rm -f "$CACHE_FILE"
if cache_init 2>/dev/null; then
    if [[ -f "$CACHE_FILE" ]]; then
        assert_success "cache_init creates cache file"
    else
        assert_failure "cache_init creates cache file - file not found"
    fi
else
    assert_failure "cache_init creates cache file"
fi
echo ""

# Test 2: cache_set stores value
echo "Test 2: cache_set stores value"
cache_init 2>/dev/null
if cache_set "test_key" '{"value":"test"}' 2>/dev/null; then
    assert_success "cache_set stores value"
else
    assert_failure "cache_set stores value"
fi
echo ""

# Test 3: cache_get retrieves value
echo "Test 3: cache_get retrieves value"
cache_set "test_key" '{"value":"test"}' 2>/dev/null
value=$(cache_get "test_key" 2>/dev/null)
if [[ -n "$value" ]] && echo "$value" | jq empty 2>/dev/null; then
    assert_success "cache_get retrieves value"
else
    assert_failure "cache_get retrieves value"
fi
echo ""

# Test 4: cache_get returns empty for non-existent key
echo "Test 4: cache_get returns empty for non-existent key"
value=$(cache_get "nonexistent_key" 2>/dev/null)
if [[ -z "$value" ]]; then
    assert_success "cache_get returns empty for non-existent key"
else
    assert_failure "cache_get returns empty for non-existent key"
fi
echo ""

# Test 5: cache_invalidate removes key
echo "Test 5: cache_invalidate removes key"
cache_set "test_key" '{"value":"test"}' 2>/dev/null
cache_invalidate "test_key" 2>/dev/null
value=$(cache_get "test_key" 2>/dev/null)
if [[ -z "$value" ]]; then
    assert_success "cache_invalidate removes key"
else
    assert_failure "cache_invalidate removes key"
fi
echo ""

# Test 6: cache_is_valid checks validity
echo "Test 6: cache_is_valid checks validity"
cache_init 2>/dev/null
cache_set "test_key" '{"value":"test"}' 2>/dev/null
if cache_is_valid 2>/dev/null; then
    assert_success "cache_is_valid checks validity"
else
    assert_failure "cache_is_valid checks validity"
fi
echo ""

# Test 7: cache_refresh clears cache
echo "Test 7: cache_refresh clears cache"
cache_set "test_key" '{"value":"test"}' 2>/dev/null
cache_refresh 2>/dev/null
value=$(cache_get "test_key" 2>/dev/null)
if [[ -z "$value" ]]; then
    assert_success "cache_refresh clears cache"
else
    assert_failure "cache_refresh clears cache"
fi
echo ""

# Test 8: cache_get_age returns age
echo "Test 8: cache_get_age returns age"
cache_init 2>/dev/null
age=$(cache_get_age 2>/dev/null)
if [[ -n "$age" ]] && [[ "$age" =~ ^[0-9]+$ ]]; then
    assert_success "cache_get_age returns age ($age seconds)"
else
    assert_failure "cache_get_age returns age"
fi
echo ""

# Test 9: cache_get_age_human returns human-readable age
echo "Test 9: cache_get_age_human returns human-readable age"
age_human=$(cache_get_age_human 2>/dev/null)
if [[ -n "$age_human" ]]; then
    assert_success "cache_get_age_human returns human-readable age ($age_human)"
else
    assert_failure "cache_get_age_human returns human-readable age"
fi
echo ""

# Test 10: cache_get_stats returns statistics
echo "Test 10: cache_get_stats returns statistics"
cache_init 2>/dev/null
stats=$(cache_get_stats 2>/dev/null)
if [[ -n "$stats" ]] && echo "$stats" | jq empty 2>/dev/null; then
    assert_success "cache_get_stats returns valid JSON"
else
    assert_failure "cache_get_stats returns valid JSON"
fi
echo ""

# Test 11: cache_set requires key
echo "Test 11: cache_set requires key"
if ! cache_set "" '{"value":"test"}' 2>/dev/null; then
    assert_success "cache_set requires key"
else
    assert_failure "cache_set requires key"
fi
echo ""

# Test 12: cache_set requires value
echo "Test 12: cache_set requires value"
if ! cache_set "test_key" "" 2>/dev/null; then
    assert_success "cache_set requires value"
else
    assert_failure "cache_set requires value"
fi
echo ""

# Test 13: cache_get requires key
echo "Test 13: cache_get requires key"
if ! cache_get "" 2>/dev/null; then
    assert_success "cache_get requires key"
else
    assert_failure "cache_get requires key"
fi
echo ""

# Test 14: cache_invalidate requires key
echo "Test 14: cache_invalidate requires key"
if ! cache_invalidate "" 2>/dev/null; then
    assert_success "cache_invalidate requires key"
else
    assert_failure "cache_invalidate requires key"
fi
echo ""

# Test 15: Multiple cache entries work
echo "Test 15: Multiple cache entries work"
cache_init 2>/dev/null
cache_set "key1" '{"value":"test1"}' 2>/dev/null
cache_set "key2" '{"value":"test2"}' 2>/dev/null
cache_set "key3" '{"value":"test3"}' 2>/dev/null
value1=$(cache_get "key1" 2>/dev/null)
value2=$(cache_get "key2" 2>/dev/null)
value3=$(cache_get "key3" 2>/dev/null)
if [[ -n "$value1" ]] && [[ -n "$value2" ]] && [[ -n "$value3" ]]; then
    assert_success "Multiple cache entries work"
else
    assert_failure "Multiple cache entries work"
fi
echo ""

# Test 16: Cache file is valid JSON
echo "Test 16: Cache file is valid JSON"
cache_init 2>/dev/null
if jq empty "$CACHE_FILE" 2>/dev/null; then
    assert_success "Cache file is valid JSON"
else
    assert_failure "Cache file is valid JSON"
fi
echo ""

# Test 17: Cache statistics include package count
echo "Test 17: Cache statistics include package count"
cache_refresh 2>/dev/null  # Clear cache first
cache_set "key1" '{"value":"test1"}' 2>/dev/null
cache_set "key2" '{"value":"test2"}' 2>/dev/null
stats=$(cache_get_stats 2>/dev/null)
package_count=$(echo "$stats" | jq -r '.package_count')
if [[ "$package_count" -ge 2 ]]; then
    assert_success "Cache statistics include package count ($package_count)"
else
    assert_failure "Cache statistics include package count (expected >=2, got $package_count)"
fi
echo ""

# Test 18: Cache with custom TTL
echo "Test 18: Cache with custom TTL"
cache_init 2>/dev/null
if cache_set "test_key" '{"value":"test"}' 3600 2>/dev/null; then
    assert_success "Cache with custom TTL"
else
    assert_failure "Cache with custom TTL"
fi
echo ""

# Restore cache
restore_cache

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
