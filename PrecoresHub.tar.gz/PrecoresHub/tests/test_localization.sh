#!/bin/bash
# Unit tests for lib/localization.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/localization.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected" == "$actual" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - Expected: '$expected', Got: '$actual'"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

assert_contains() {
    local haystack="$1"
    local needle="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if echo "$haystack" | grep -q "$needle"; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - '$haystack' does not contain '$needle'"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

echo "========================================"
echo "Testing lib/localization.sh"
echo "========================================"
echo ""

# Test 1: lang_set sets language
echo "Test 1: lang_set sets language"
if lang_set "en" 2>/dev/null; then
    current=$(lang_get_current)
    assert_equals "en" "$current" "lang_set sets language to en"
else
    assert_failure "lang_set sets language to en"
fi
echo ""

# Test 2: lang_set fails for non-existent language
echo "Test 2: lang_set fails for non-existent language"
if ! lang_set "xx" 2>/dev/null; then
    assert_success "lang_set fails for non-existent language"
else
    assert_failure "lang_set fails for non-existent language"
fi
echo ""

# Test 3: lang_get retrieves translation
echo "Test 3: lang_get retrieves translation"
lang_set "en" 2>/dev/null
translation=$(lang_get "menu.main.title" 2>/dev/null)
assert_equals "Main Menu" "$translation" "lang_get retrieves translation"
echo ""

# Test 4: lang_get returns key for missing translation
echo "Test 4: lang_get returns key for missing translation"
translation=$(lang_get "nonexistent.key" 2>/dev/null)
assert_equals "nonexistent.key" "$translation" "lang_get returns key for missing translation"
echo ""

# Test 5: lang_get with variable substitution
echo "Test 5: lang_get with variable substitution"
translation=$(lang_get "messages.installing" "docker" 2>/dev/null)
assert_equals "Installing docker..." "$translation" "lang_get with variable substitution"
echo ""

# Test 6: lang_list returns available languages
echo "Test 6: lang_list returns available languages"
languages=$(lang_list 2>/dev/null)
if [[ -n "$languages" ]] && echo "$languages" | jq empty 2>/dev/null; then
    assert_success "lang_list returns valid JSON"
else
    assert_failure "lang_list returns valid JSON"
fi
echo ""

# Test 7: lang_list contains English
echo "Test 7: lang_list contains English"
languages=$(lang_list 2>/dev/null)
if echo "$languages" | jq -e '.[] | select(.code == "en")' >/dev/null 2>&1; then
    assert_success "lang_list contains English"
else
    assert_failure "lang_list contains English"
fi
echo ""

# Test 8: lang_list contains Vietnamese
echo "Test 8: lang_list contains Vietnamese"
languages=$(lang_list 2>/dev/null)
if echo "$languages" | jq -e '.[] | select(.code == "vi")' >/dev/null 2>&1; then
    assert_success "lang_list contains Vietnamese"
else
    assert_failure "lang_list contains Vietnamese"
fi
echo ""

# Test 9: lang_has_key detects existing key
echo "Test 9: lang_has_key detects existing key"
lang_set "en" 2>/dev/null
if lang_has_key "menu.main.title" 2>/dev/null; then
    assert_success "lang_has_key detects existing key"
else
    assert_failure "lang_has_key detects existing key"
fi
echo ""

# Test 10: lang_has_key returns false for non-existent key
echo "Test 10: lang_has_key returns false for non-existent key"
if ! lang_has_key "nonexistent.key" 2>/dev/null; then
    assert_success "lang_has_key returns false for non-existent key"
else
    assert_failure "lang_has_key returns false for non-existent key"
fi
echo ""

# Test 11: lang_get_meta retrieves metadata
echo "Test 11: lang_get_meta retrieves metadata"
lang_set "en" 2>/dev/null
meta_name=$(lang_get_meta "name" 2>/dev/null)
assert_equals "English" "$meta_name" "lang_get_meta retrieves metadata"
echo ""

# Test 12: lang_validate validates language file
echo "Test 12: lang_validate validates language file"
if lang_validate "en" 2>/dev/null; then
    assert_success "lang_validate validates language file"
else
    assert_failure "lang_validate validates language file"
fi
echo ""

# Test 13: lang_get_or returns translation
echo "Test 13: lang_get_or returns translation"
lang_set "en" 2>/dev/null
translation=$(lang_get_or "menu.main.title" "Fallback" 2>/dev/null)
assert_equals "Main Menu" "$translation" "lang_get_or returns translation"
echo ""

# Test 14: lang_get_or returns fallback for missing key
echo "Test 14: lang_get_or returns fallback for missing key"
translation=$(lang_get_or "nonexistent.key" "Fallback" 2>/dev/null)
assert_equals "Fallback" "$translation" "lang_get_or returns fallback for missing key"
echo ""

# Test 15: Vietnamese translations work
echo "Test 15: Vietnamese translations work"
if lang_set "vi" 2>/dev/null; then
    translation=$(lang_get "menu.main.title" 2>/dev/null)
    assert_equals "Menu Chính" "$translation" "Vietnamese translations work"
else
    assert_failure "Vietnamese translations work"
fi
echo ""

# Test 16: lang_format formats message
echo "Test 16: lang_format formats message"
formatted=$(lang_format "Installing {0}..." "docker" 2>/dev/null)
assert_equals "Installing docker..." "$formatted" "lang_format formats message"
echo ""

# Test 17: lang_get_all returns all translations
echo "Test 17: lang_get_all returns all translations"
lang_set "en" 2>/dev/null
all_translations=$(lang_get_all 2>/dev/null)
if [[ -n "$all_translations" ]] && echo "$all_translations" | jq empty 2>/dev/null; then
    assert_success "lang_get_all returns valid JSON"
else
    assert_failure "lang_get_all returns valid JSON"
fi
echo ""

# Test 18: lang_reload clears cache
echo "Test 18: lang_reload clears cache"
lang_set "en" 2>/dev/null
lang_get "menu.main.title" 2>/dev/null  # Cache it
if lang_reload 2>/dev/null; then
    assert_success "lang_reload clears cache"
else
    assert_failure "lang_reload clears cache"
fi
echo ""

# Test 19: lang_detect detects language
echo "Test 19: lang_detect detects language"
detected=$(lang_detect 2>/dev/null)
if [[ -n "$detected" ]]; then
    assert_success "lang_detect detects language ($detected)"
else
    assert_failure "lang_detect detects language"
fi
echo ""

# Test 20: lang_init initializes system
echo "Test 20: lang_init initializes system"
if lang_init "en" 2>/dev/null; then
    current=$(lang_get_current)
    assert_equals "en" "$current" "lang_init initializes system"
else
    assert_failure "lang_init initializes system"
fi
echo ""

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
