#!/bin/bash
# Unit tests for lib/core.sh JSON I/O functions

# Source the core library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected" == "$actual" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo "✗ FAIL: $test_name"
        echo "  Expected: $expected"
        echo "  Actual:   $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_file_exists() {
    local file="$1"
    local test_name="$2"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ -f "$file" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo "✗ FAIL: $test_name - File does not exist: $file"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Clean up test files
cleanup() {
    rm -f /tmp/test_precoreshub*.json 2>/dev/null
    rm -f /tmp/test_nested.json 2>/dev/null
    rm -rf /tmp/precoreshub_test 2>/dev/null
}

# Test suite
echo "========================================"
echo "Testing lib/core.sh JSON I/O Functions"
echo "========================================"
echo ""

# Check if jq is available
echo "Checking prerequisites..."
if ! command -v jq &> /dev/null; then
    echo "✗ ERROR: jq is not installed. Please install jq to run these tests."
    echo "  - Debian/Ubuntu: sudo apt install jq"
    echo "  - Arch: sudo pacman -S jq"
    echo "  - Fedora: sudo dnf install jq"
    echo "  - Alpine: sudo apk add jq"
    exit 1
fi
echo "✓ jq is installed"
echo ""

# Clean up before tests
cleanup

# Test 1: write_json creates file
echo "Test 1: write_json creates file"
test_file="/tmp/test_precoreshub.json"
test_json='{"name": "PrecoresHub", "version": "5.0.0"}'
if write_json "$test_file" "$test_json" 2>/dev/null; then
    assert_file_exists "$test_file" "write_json creates file"
else
    assert_failure "write_json creates file"
fi
echo ""

# Test 2: write_json formats JSON correctly
echo "Test 2: write_json formats JSON correctly"
if [[ -f "$test_file" ]]; then
    # Check if file contains properly formatted JSON
    if jq empty "$test_file" 2>/dev/null; then
        assert_success "write_json formats JSON correctly"
    else
        assert_failure "write_json formats JSON correctly - Invalid JSON"
    fi
else
    assert_failure "write_json formats JSON correctly - File not created"
fi
echo ""

# Test 3: read_json reads file successfully
echo "Test 3: read_json reads file successfully"
if result=$(read_json "$test_file" 2>/dev/null); then
    if [[ -n "$result" ]]; then
        assert_success "read_json reads file successfully"
    else
        assert_failure "read_json reads file successfully - Empty result"
    fi
else
    assert_failure "read_json reads file successfully"
fi
echo ""

# Test 4: read_json with filter extracts correct value
echo "Test 4: read_json with filter extracts correct value"
if result=$(read_json "$test_file" ".name" 2>/dev/null); then
    assert_equals "PrecoresHub" "$result" "read_json extracts .name correctly"
else
    assert_failure "read_json extracts .name correctly"
fi
echo ""

# Test 5: read_json with filter extracts version
echo "Test 5: read_json with filter extracts version"
if result=$(read_json "$test_file" ".version" 2>/dev/null); then
    assert_equals "5.0.0" "$result" "read_json extracts .version correctly"
else
    assert_failure "read_json extracts .version correctly"
fi
echo ""

# Test 6: write_json with nested structure
echo "Test 6: write_json with nested structure"
nested_json='{"config": {"language": "en", "parallel_installs": 3}, "plugins": ["plugin1", "plugin2"]}'
nested_file="/tmp/test_nested.json"
if write_json "$nested_file" "$nested_json" 2>/dev/null; then
    assert_file_exists "$nested_file" "write_json creates nested structure"
else
    assert_failure "write_json creates nested structure"
fi
echo ""

# Test 7: read_json with nested filter
echo "Test 7: read_json with nested filter"
if result=$(read_json "$nested_file" ".config.language" 2>/dev/null); then
    assert_equals "en" "$result" "read_json extracts nested value"
else
    assert_failure "read_json extracts nested value"
fi
echo ""

# Test 8: read_json with array length filter
echo "Test 8: read_json with array length filter"
if result=$(read_json "$nested_file" ".plugins | length" 2>/dev/null); then
    assert_equals "2" "$result" "read_json calculates array length"
else
    assert_failure "read_json calculates array length"
fi
echo ""

# Test 9: read_json fails on non-existent file
echo "Test 9: read_json fails on non-existent file"
if read_json "/tmp/nonexistent_file.json" 2>/dev/null; then
    assert_failure "read_json fails on non-existent file - Should have failed"
else
    assert_success "read_json fails on non-existent file"
fi
echo ""

# Test 10: write_json fails on invalid JSON
echo "Test 10: write_json fails on invalid JSON"
if write_json "/tmp/test_invalid.json" "not valid json" 2>/dev/null; then
    assert_failure "write_json fails on invalid JSON - Should have failed"
else
    assert_success "write_json fails on invalid JSON"
fi
echo ""

# Test 11: read_json fails on missing file path
echo "Test 11: read_json fails on missing file path"
if read_json "" 2>/dev/null; then
    assert_failure "read_json fails on missing file path - Should have failed"
else
    assert_success "read_json fails on missing file path"
fi
echo ""

# Test 12: write_json fails on missing file path
echo "Test 12: write_json fails on missing file path"
if write_json "" "$test_json" 2>/dev/null; then
    assert_failure "write_json fails on missing file path - Should have failed"
else
    assert_success "write_json fails on missing file path"
fi
echo ""

# Test 13: write_json fails on missing JSON content
echo "Test 13: write_json fails on missing JSON content"
if write_json "/tmp/test.json" "" 2>/dev/null; then
    assert_failure "write_json fails on missing JSON content - Should have failed"
else
    assert_success "write_json fails on missing JSON content"
fi
echo ""

# Test 14: write_json creates parent directories
echo "Test 14: write_json creates parent directories"
new_dir_file="/tmp/precoreshub_test/subdir/test.json"
if write_json "$new_dir_file" "$test_json" 2>/dev/null; then
    assert_file_exists "$new_dir_file" "write_json creates parent directories"
else
    assert_failure "write_json creates parent directories"
fi
echo ""

# Test 15: read_json with complex filter
echo "Test 15: read_json with complex filter"
complex_json='{"users": [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]}'
complex_file="/tmp/test_complex.json"
if write_json "$complex_file" "$complex_json" 2>/dev/null; then
    if result=$(read_json "$complex_file" ".users[0].name" 2>/dev/null); then
        assert_equals "Alice" "$result" "read_json with complex filter"
    else
        assert_failure "read_json with complex filter"
    fi
else
    assert_failure "read_json with complex filter - Failed to write test file"
fi
echo ""

# Test 16: Round-trip test (write then read)
echo "Test 16: Round-trip test (write then read)"
roundtrip_json='{"test": "round-trip", "number": 42, "array": [1, 2, 3]}'
roundtrip_file="/tmp/test_roundtrip.json"
if write_json "$roundtrip_file" "$roundtrip_json" 2>/dev/null; then
    if result=$(read_json "$roundtrip_file" ".test" 2>/dev/null); then
        assert_equals "round-trip" "$result" "Round-trip test"
    else
        assert_failure "Round-trip test - Failed to read"
    fi
else
    assert_failure "Round-trip test - Failed to write"
fi
echo ""

# Clean up after tests
cleanup
rm -f /tmp/test_complex.json /tmp/test_roundtrip.json 2>/dev/null

# Display test results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
