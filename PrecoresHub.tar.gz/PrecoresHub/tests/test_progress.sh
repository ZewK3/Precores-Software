#!/bin/bash
# Unit tests for lib/progress.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/progress.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected" == "$actual" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - Expected: '$expected', Got: '$actual'"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

echo "========================================"
echo "Testing lib/progress.sh"
echo "========================================"
echo ""

# Test 1: progress_start initializes progress
echo "Test 1: progress_start initializes progress"
if progress_start "Test Operation" >/dev/null 2>&1; then
    assert_success "progress_start initializes progress"
else
    assert_failure "progress_start initializes progress"
fi
echo ""

# Test 2: progress_start requires operation name
echo "Test 2: progress_start requires operation name"
if ! progress_start "" 2>/dev/null; then
    assert_success "progress_start requires operation name"
else
    assert_failure "progress_start requires operation name"
fi
echo ""

# Test 3: progress_update accepts valid percentage
echo "Test 3: progress_update accepts valid percentage"
progress_start "Test" >/dev/null 2>&1
if progress_update 50 "Halfway" >/dev/null 2>&1; then
    assert_success "progress_update accepts valid percentage"
else
    assert_failure "progress_update accepts valid percentage"
fi
echo ""

# Test 4: progress_update rejects invalid percentage (negative)
echo "Test 4: progress_update rejects invalid percentage (negative)"
if ! progress_update -10 "Invalid" 2>/dev/null; then
    assert_success "progress_update rejects negative percentage"
else
    assert_failure "progress_update rejects negative percentage"
fi
echo ""

# Test 5: progress_update rejects invalid percentage (>100)
echo "Test 5: progress_update rejects invalid percentage (>100)"
if ! progress_update 150 "Invalid" 2>/dev/null; then
    assert_success "progress_update rejects percentage >100"
else
    assert_failure "progress_update rejects percentage >100"
fi
echo ""

# Test 6: progress_update rejects non-numeric percentage
echo "Test 6: progress_update rejects non-numeric percentage"
if ! progress_update "abc" "Invalid" 2>/dev/null; then
    assert_success "progress_update rejects non-numeric percentage"
else
    assert_failure "progress_update rejects non-numeric percentage"
fi
echo ""

# Test 7: progress_complete with success status
echo "Test 7: progress_complete with success status"
progress_start "Test" >/dev/null 2>&1
if progress_complete "success" "Completed" >/dev/null 2>&1; then
    assert_success "progress_complete with success status"
else
    assert_failure "progress_complete with success status"
fi
echo ""

# Test 8: progress_complete with failure status
echo "Test 8: progress_complete with failure status"
progress_start "Test" >/dev/null 2>&1
if progress_complete "failure" "Failed" >/dev/null 2>&1; then
    assert_success "progress_complete with failure status"
else
    assert_failure "progress_complete with failure status"
fi
echo ""

# Test 9: progress_simple displays message
echo "Test 9: progress_simple displays message"
output=$(progress_simple "Testing" 2>&1)
if [[ -n "$output" ]]; then
    assert_success "progress_simple displays message"
else
    assert_failure "progress_simple displays message"
fi
echo ""

# Test 10: progress_simple_done completes
echo "Test 10: progress_simple_done completes"
if progress_simple_done >/dev/null 2>&1; then
    assert_success "progress_simple_done completes"
else
    assert_failure "progress_simple_done completes"
fi
echo ""

# Test 11: progress_simple_failed completes
echo "Test 11: progress_simple_failed completes"
if progress_simple_failed >/dev/null 2>&1; then
    assert_success "progress_simple_failed completes"
else
    assert_failure "progress_simple_failed completes"
fi
echo ""

# Test 12: progress_parallel_start initializes
echo "Test 12: progress_parallel_start initializes"
if progress_parallel_start 3 >/dev/null 2>&1; then
    assert_success "progress_parallel_start initializes"
else
    assert_failure "progress_parallel_start initializes"
fi
echo ""

# Test 13: progress_parallel_start rejects invalid count
echo "Test 13: progress_parallel_start rejects invalid count"
if ! progress_parallel_start 0 2>/dev/null; then
    assert_success "progress_parallel_start rejects invalid count"
else
    assert_failure "progress_parallel_start rejects invalid count"
fi
echo ""

# Test 14: progress_parallel_update updates task
echo "Test 14: progress_parallel_update updates task"
progress_parallel_start 3 >/dev/null 2>&1
if progress_parallel_update 0 50 "Task 1" >/dev/null 2>&1; then
    assert_success "progress_parallel_update updates task"
else
    assert_failure "progress_parallel_update updates task"
fi
echo ""

# Test 15: progress_parallel_complete finishes
echo "Test 15: progress_parallel_complete finishes"
if progress_parallel_complete >/dev/null 2>&1; then
    assert_success "progress_parallel_complete finishes"
else
    assert_failure "progress_parallel_complete finishes"
fi
echo ""

# Test 16: Multiple progress updates work
echo "Test 16: Multiple progress updates work"
progress_start "Multi-step" >/dev/null 2>&1
success=true
for i in 0 25 50 75 100; do
    if ! progress_update $i "Step $i%" >/dev/null 2>&1; then
        success=false
        break
    fi
done
if $success; then
    assert_success "Multiple progress updates work"
else
    assert_failure "Multiple progress updates work"
fi
progress_complete "success" "Done" >/dev/null 2>&1
echo ""

# Test 17: Progress bar width constant is defined
echo "Test 17: Progress bar width constant is defined"
if [[ -n "$PROGRESS_BAR_WIDTH" ]]; then
    assert_success "Progress bar width constant is defined ($PROGRESS_BAR_WIDTH)"
else
    assert_failure "Progress bar width constant is defined"
fi
echo ""

# Test 18: Progress spinner array is defined
echo "Test 18: Progress spinner array is defined"
if [[ ${#PROGRESS_SPINNER[@]} -gt 0 ]]; then
    assert_success "Progress spinner array is defined (${#PROGRESS_SPINNER[@]} frames)"
else
    assert_failure "Progress spinner array is defined"
fi
echo ""

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
