#!/bin/bash
# Unit tests for lib/history.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/history.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_not_empty() {
    local value="$1"
    local test_name="$2"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ -n "$value" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - Value is empty"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# Backup and cleanup
backup_history() {
    if [[ -f "$HISTORY_FILE" ]]; then
        cp "$HISTORY_FILE" "${HISTORY_FILE}.backup"
    fi
}

restore_history() {
    if [[ -f "${HISTORY_FILE}.backup" ]]; then
        mv "${HISTORY_FILE}.backup" "$HISTORY_FILE"
    else
        rm -f "$HISTORY_FILE"
    fi
}

echo "========================================"
echo "Testing lib/history.sh"
echo "========================================"
echo ""

# Backup existing history
backup_history

# Test 1: history_record creates entry
echo "Test 1: history_record creates entry"
rm -f "$HISTORY_FILE"
if history_record "install" "docker" "success" 45 2>/dev/null; then
    assert_success "history_record creates entry"
else
    assert_failure "history_record creates entry"
fi
echo ""

# Test 2: history_list returns entries
echo "Test 2: history_list returns entries"
entries=$(history_list "all" 2>/dev/null)
if [[ -n "$entries" ]] && echo "$entries" | jq empty 2>/dev/null; then
    assert_success "history_list returns valid JSON"
else
    assert_failure "history_list returns valid JSON"
fi
echo ""

# Test 3: history_list filters by success
echo "Test 3: history_list filters by success"
history_record "install" "nginx" "success" 30 2>/dev/null
history_record "install" "mysql" "failure" 15 2>/dev/null
success_entries=$(history_list "success" 2>/dev/null | jq 'length')
if [[ "$success_entries" -ge 2 ]]; then
    assert_success "history_list filters by success"
else
    assert_failure "history_list filters by success"
fi
echo "  Success entries: $success_entries"
echo ""

# Test 4: history_list filters by failure
echo "Test 4: history_list filters by failure"
failure_entries=$(history_list "failure" 2>/dev/null | jq 'length')
if [[ "$failure_entries" -ge 1 ]]; then
    assert_success "history_list filters by failure"
else
    assert_failure "history_list filters by failure"
fi
echo "  Failure entries: $failure_entries"
echo ""

# Test 5: history_get retrieves specific entry
echo "Test 5: history_get retrieves specific entry"
# Get first entry ID
first_id=$(history_list "all" 2>/dev/null | jq -r '.[0].id')
if [[ -n "$first_id" && "$first_id" != "null" ]]; then
    entry=$(history_get "$first_id" 2>/dev/null)
    if [[ -n "$entry" ]] && echo "$entry" | jq empty 2>/dev/null; then
        assert_success "history_get retrieves specific entry"
    else
        assert_failure "history_get retrieves specific entry"
    fi
else
    assert_failure "history_get retrieves specific entry - No ID found"
fi
echo ""

# Test 6: history_export JSON format
echo "Test 6: history_export JSON format"
export_json=$(history_export "json" 2>/dev/null)
if [[ -n "$export_json" ]] && echo "$export_json" | jq empty 2>/dev/null; then
    assert_success "history_export JSON format"
else
    assert_failure "history_export JSON format"
fi
echo ""

# Test 7: history_export CSV format
echo "Test 7: history_export CSV format"
export_csv=$(history_export "csv" 2>/dev/null)
if [[ -n "$export_csv" ]] && echo "$export_csv" | grep -q "ID,Timestamp"; then
    assert_success "history_export CSV format"
else
    assert_failure "history_export CSV format"
fi
echo ""

# Test 8: history_get_stats returns statistics
echo "Test 8: history_get_stats returns statistics"
stats=$(history_get_stats 2>/dev/null)
if [[ -n "$stats" ]] && echo "$stats" | jq empty 2>/dev/null; then
    total=$(echo "$stats" | jq -r '.total')
    success=$(echo "$stats" | jq -r '.success')
    failure=$(echo "$stats" | jq -r '.failure')
    echo "  Total: $total, Success: $success, Failure: $failure"
    assert_success "history_get_stats returns statistics"
else
    assert_failure "history_get_stats returns statistics"
fi
echo ""

# Test 9: Multiple entries are stored
echo "Test 9: Multiple entries are stored"
history_record "install" "git" "success" 20 2>/dev/null
history_record "remove" "vim" "success" 10 2>/dev/null
total_entries=$(history_list "all" 2>/dev/null | jq 'length')
if [[ "$total_entries" -ge 5 ]]; then
    assert_success "Multiple entries are stored ($total_entries entries)"
else
    assert_failure "Multiple entries are stored (only $total_entries entries)"
fi
echo ""

# Test 10: History file is valid JSON
echo "Test 10: History file is valid JSON"
if jq empty "$HISTORY_FILE" 2>/dev/null; then
    assert_success "History file is valid JSON"
else
    assert_failure "History file is valid JSON"
fi
echo ""

# Restore history
restore_history

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
