#!/bin/bash
# Unit tests for lib/plugin.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/plugin.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

echo "========================================"
echo "Testing lib/plugin.sh"
echo "========================================"
echo ""

# Test 1: plugin_init creates directories
echo "Test 1: plugin_init creates directories"
if plugin_init 2>/dev/null; then
    if [[ -d "$PLUGIN_DIR" ]] && [[ -d "$USER_PLUGIN_DIR" ]]; then
        assert_success "plugin_init creates directories"
    else
        assert_failure "plugin_init creates directories - directories not found"
    fi
else
    assert_failure "plugin_init creates directories"
fi
echo ""

# Test 2: plugin_discover finds plugins
echo "Test 2: plugin_discover finds plugins"
plugins=$(plugin_discover 2>/dev/null)
if [[ -n "$plugins" ]] && echo "$plugins" | jq empty 2>/dev/null; then
    assert_success "plugin_discover returns valid JSON"
else
    assert_failure "plugin_discover returns valid JSON"
fi
echo ""

# Test 3: plugin_discover finds example plugin
echo "Test 3: plugin_discover finds example plugin"
plugins=$(plugin_discover 2>/dev/null)
example_found=$(echo "$plugins" | jq -r '.[] | select(.name == "example") | .name' 2>/dev/null)
if [[ "$example_found" == "example" ]]; then
    assert_success "plugin_discover finds example plugin"
else
    assert_failure "plugin_discover finds example plugin"
fi
echo ""

# Test 4: plugin_validate validates example plugin
echo "Test 4: plugin_validate validates example plugin"
if plugin_validate "$PLUGIN_DIR/example.phub" 2>/dev/null; then
    assert_success "plugin_validate validates example plugin"
else
    assert_failure "plugin_validate validates example plugin"
fi
echo ""

# Test 5: plugin_load loads plugin
echo "Test 5: plugin_load loads plugin"
if plugin_load "example" 2>/dev/null; then
    assert_success "plugin_load loads plugin"
else
    assert_failure "plugin_load loads plugin"
fi
echo ""

# Test 6: plugin_is_loaded checks if loaded
echo "Test 6: plugin_is_loaded checks if loaded"
if plugin_is_loaded "example"; then
    assert_success "plugin_is_loaded checks if loaded"
else
    assert_failure "plugin_is_loaded checks if loaded"
fi
echo ""

# Test 7: plugin_enable enables plugin
echo "Test 7: plugin_enable enables plugin"
if plugin_enable "example" 2>/dev/null; then
    assert_success "plugin_enable enables plugin"
else
    assert_failure "plugin_enable enables plugin"
fi
echo ""

# Test 8: plugin_is_enabled checks if enabled
echo "Test 8: plugin_is_enabled checks if enabled"
if plugin_is_enabled "example"; then
    assert_success "plugin_is_enabled checks if enabled"
else
    assert_failure "plugin_is_enabled checks if enabled"
fi
echo ""

# Test 9: plugin_disable disables plugin
echo "Test 9: plugin_disable disables plugin"
plugin_disable "example" 2>/dev/null
if ! plugin_is_enabled "example"; then
    assert_success "plugin_disable disables plugin"
else
    assert_failure "plugin_disable disables plugin"
fi
echo ""

# Test 10: plugin_list all returns plugins
echo "Test 10: plugin_list all returns plugins"
all_plugins=$(plugin_list "all" 2>/dev/null)
if [[ -n "$all_plugins" ]] && echo "$all_plugins" | jq empty 2>/dev/null; then
    assert_success "plugin_list all returns valid JSON"
else
    assert_failure "plugin_list all returns valid JSON"
fi
echo ""

# Test 11: plugin_list loaded returns loaded plugins
echo "Test 11: plugin_list loaded returns loaded plugins"
loaded_plugins=$(plugin_list "loaded" 2>/dev/null)
if [[ -n "$loaded_plugins" ]] && echo "$loaded_plugins" | jq empty 2>/dev/null; then
    assert_success "plugin_list loaded returns valid JSON"
else
    assert_failure "plugin_list loaded returns valid JSON"
fi
echo ""

# Test 12: plugin_get_metadata returns metadata
echo "Test 12: plugin_get_metadata returns metadata"
metadata=$(plugin_get_metadata "example" 2>/dev/null)
if [[ -n "$metadata" ]] && echo "$metadata" | jq empty 2>/dev/null; then
    assert_success "plugin_get_metadata returns valid JSON"
else
    assert_failure "plugin_get_metadata returns valid JSON"
fi
echo ""

# Test 13: plugin_get_metadata returns specific field
echo "Test 13: plugin_get_metadata returns specific field"
version=$(plugin_get_metadata "example" "version" 2>/dev/null)
if [[ "$version" == "1.0.0" ]]; then
    assert_success "plugin_get_metadata returns specific field"
else
    assert_failure "plugin_get_metadata returns specific field (got: $version)"
fi
echo ""

# Test 14: plugin_count returns count
echo "Test 14: plugin_count returns count"
count=$(plugin_count "all" 2>/dev/null)
if [[ -n "$count" ]] && [[ "$count" =~ ^[0-9]+$ ]]; then
    assert_success "plugin_count returns count ($count)"
else
    assert_failure "plugin_count returns count"
fi
echo ""

# Test 15: plugin_unload unloads plugin
echo "Test 15: plugin_unload unloads plugin"
plugin_unload "example" 2>/dev/null
if ! plugin_is_loaded "example"; then
    assert_success "plugin_unload unloads plugin"
else
    assert_failure "plugin_unload unloads plugin"
fi
echo ""

# Test 16: plugin_check_dependencies checks dependencies
echo "Test 16: plugin_check_dependencies checks dependencies"
plugin_load "example" 2>/dev/null
if plugin_check_dependencies "example" 2>/dev/null; then
    assert_success "plugin_check_dependencies checks dependencies"
else
    assert_failure "plugin_check_dependencies checks dependencies"
fi
echo ""

# Test 17: Plugin constants are defined
echo "Test 17: Plugin constants are defined"
if [[ -n "$PLUGIN_DIR" ]] && [[ -n "$PLUGIN_EXTENSION" ]]; then
    assert_success "Plugin constants are defined"
else
    assert_failure "Plugin constants are defined"
fi
echo ""

# Test 18: plugin_validate rejects invalid JSON
echo "Test 18: plugin_validate rejects invalid JSON"
# Create invalid plugin file
echo "invalid json" > /tmp/test_invalid.phub
if ! plugin_validate "/tmp/test_invalid.phub" 2>/dev/null; then
    assert_success "plugin_validate rejects invalid JSON"
else
    assert_failure "plugin_validate rejects invalid JSON"
fi
rm -f /tmp/test_invalid.phub
echo ""

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
