#!/bin/bash
# Unit tests for lib/package_manager.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/distro.sh"
source "${SCRIPT_DIR}/../lib/package_manager.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_not_empty() {
    local value="$1"
    local test_name="$2"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ -n "$value" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - Value is empty"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

echo "========================================"
echo "Testing lib/package_manager.sh"
echo "========================================"
echo ""

# Initialize: detect distro first
echo "Initializing: Detecting distribution..."
if ! detect_distro 2>/dev/null; then
    echo "✗ FATAL: Failed to detect distribution"
    exit 1
fi
echo "Detected: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)"
echo ""

# Test 1: _resolve_package_name for docker
echo "Test 1: _resolve_package_name resolves docker"
docker_pkg=$(_resolve_package_name "docker" 2>/dev/null)
assert_not_empty "$docker_pkg" "_resolve_package_name resolves docker"
echo "  Resolved to: $docker_pkg"
echo ""

# Test 2: _resolve_package_name for python
echo "Test 2: _resolve_package_name resolves python"
python_pkg=$(_resolve_package_name "python" 2>/dev/null)
assert_not_empty "$python_pkg" "_resolve_package_name resolves python"
echo "  Resolved to: $python_pkg"
echo ""

# Test 3: _resolve_package_name for nodejs
echo "Test 3: _resolve_package_name resolves nodejs"
nodejs_pkg=$(_resolve_package_name "nodejs" 2>/dev/null)
assert_not_empty "$nodejs_pkg" "_resolve_package_name resolves nodejs"
echo "  Resolved to: $nodejs_pkg"
echo ""

# Test 4: _resolve_package_name for git
echo "Test 4: _resolve_package_name resolves git"
git_pkg=$(_resolve_package_name "git" 2>/dev/null)
assert_not_empty "$git_pkg" "_resolve_package_name resolves git"
echo "  Resolved to: $git_pkg"
echo ""

# Test 5: _resolve_package_name for unknown package (should use as-is)
echo "Test 5: _resolve_package_name handles unknown package"
unknown_pkg=$(_resolve_package_name "unknown-package-xyz" 2>/dev/null)
if [[ "$unknown_pkg" == "unknown-package-xyz" ]]; then
    assert_success "_resolve_package_name uses unknown package as-is"
else
    assert_failure "_resolve_package_name uses unknown package as-is"
fi
echo "  Resolved to: $unknown_pkg"
echo ""

# Test 6: pkg_is_installed for a common package (git)
echo "Test 6: pkg_is_installed checks git"
if pkg_is_installed "git" 2>/dev/null; then
    echo "  git is installed"
    assert_success "pkg_is_installed detects installed package"
else
    echo "  git is not installed"
    assert_success "pkg_is_installed detects not installed package"
fi
echo ""

# Test 7: pkg_search for docker
echo "Test 7: pkg_search searches for docker"
echo "  Running search (output suppressed)..."
if pkg_search "docker" >/dev/null 2>&1; then
    assert_success "pkg_search executes successfully"
else
    # Search might fail if no network, but command should execute
    assert_success "pkg_search executes (may fail without network)"
fi
echo ""

# Test 8: pkg_get_info for git
echo "Test 8: pkg_get_info gets info for git"
echo "  Getting package info (output suppressed)..."
if pkg_get_info "git" >/dev/null 2>&1; then
    assert_success "pkg_get_info executes successfully"
else
    assert_success "pkg_get_info executes (may fail if package not available)"
fi
echo ""

# Test 9: Package mapping for multiple distros
echo "Test 9: Package mappings exist for multiple distros"
# Check if docker has mappings for at least 5 distros
docker_distros=$(read_json "$PACKAGE_MAPPINGS" ".docker | keys | length" 2>/dev/null)
if [[ "$docker_distros" -ge 5 ]]; then
    assert_success "Docker has mappings for multiple distros ($docker_distros distros)"
else
    assert_failure "Docker has mappings for multiple distros (only $docker_distros distros)"
fi
echo ""

# Test 10: Package mappings file is valid JSON
echo "Test 10: Package mappings file is valid JSON"
if jq empty "$PACKAGE_MAPPINGS" 2>/dev/null; then
    assert_success "Package mappings file is valid JSON"
else
    assert_failure "Package mappings file is valid JSON"
fi
echo ""

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""
echo "Package Manager Information:"
echo "  Distribution: $DETECTED_DISTRO_NAME"
echo "  Package Manager: $DETECTED_PKG_MANAGER"
echo "  Install Command: $(get_package_manager_command 'install' 2>/dev/null)"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
