#!/bin/bash
# Unit tests for lib/distro.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/distro.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_not_empty() {
    local value="$1"
    local test_name="$2"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ -n "$value" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - Value is empty"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

echo "========================================"
echo "Testing lib/distro.sh"
echo "========================================"
echo ""

# Test 1: detect_distro runs successfully
echo "Test 1: detect_distro runs successfully"
if detect_distro 2>/dev/null; then
    assert_success "detect_distro runs successfully"
else
    assert_failure "detect_distro runs successfully"
fi
echo ""

# Test 2: DETECTED_DISTRO is set
echo "Test 2: DETECTED_DISTRO is set"
assert_not_empty "$DETECTED_DISTRO" "DETECTED_DISTRO is set"
echo "  Value: $DETECTED_DISTRO"
echo ""

# Test 3: DETECTED_DISTRO_NAME is set
echo "Test 3: DETECTED_DISTRO_NAME is set"
assert_not_empty "$DETECTED_DISTRO_NAME" "DETECTED_DISTRO_NAME is set"
echo "  Value: $DETECTED_DISTRO_NAME"
echo ""

# Test 4: DETECTED_PKG_MANAGER is set
echo "Test 4: DETECTED_PKG_MANAGER is set"
assert_not_empty "$DETECTED_PKG_MANAGER" "DETECTED_PKG_MANAGER is set"
echo "  Value: $DETECTED_PKG_MANAGER"
echo ""

# Test 5: get_package_manager returns value
echo "Test 5: get_package_manager returns value"
pkg_mgr=$(get_package_manager 2>/dev/null)
assert_not_empty "$pkg_mgr" "get_package_manager returns value"
echo "  Value: $pkg_mgr"
echo ""

# Test 6: get_package_manager_command for install
echo "Test 6: get_package_manager_command for install"
install_cmd=$(get_package_manager_command "install" 2>/dev/null)
assert_not_empty "$install_cmd" "get_package_manager_command returns install command"
echo "  Value: $install_cmd"
echo ""

# Test 7: get_package_manager_command for remove
echo "Test 7: get_package_manager_command for remove"
remove_cmd=$(get_package_manager_command "remove" 2>/dev/null)
assert_not_empty "$remove_cmd" "get_package_manager_command returns remove command"
echo "  Value: $remove_cmd"
echo ""

# Test 8: get_package_manager_command for update
echo "Test 8: get_package_manager_command for update"
update_cmd=$(get_package_manager_command "update" 2>/dev/null)
assert_not_empty "$update_cmd" "get_package_manager_command returns update command"
echo "  Value: $update_cmd"
echo ""

# Test 9: validate_distro_support succeeds
echo "Test 9: validate_distro_support succeeds"
if validate_distro_support 2>/dev/null; then
    assert_success "validate_distro_support succeeds"
else
    assert_failure "validate_distro_support succeeds"
fi
echo ""

# Test 10: get_distro_info returns JSON
echo "Test 10: get_distro_info returns JSON"
distro_info=$(get_distro_info 2>/dev/null)
if [[ -n "$distro_info" ]] && echo "$distro_info" | jq empty 2>/dev/null; then
    assert_success "get_distro_info returns valid JSON"
    echo "  Sample: $(echo "$distro_info" | jq -c '{name, package_manager}' 2>/dev/null)"
else
    assert_failure "get_distro_info returns valid JSON"
fi
echo ""

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""
echo "Detected Distribution Information:"
echo "  ID: $DETECTED_DISTRO"
echo "  Name: $DETECTED_DISTRO_NAME"
echo "  Package Manager: $DETECTED_PKG_MANAGER"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
