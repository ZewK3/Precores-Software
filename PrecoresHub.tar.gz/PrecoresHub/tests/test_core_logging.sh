#!/bin/bash
# Unit tests for lib/core.sh logging functions

# Source the core library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_file_exists() {
    local file="$1"
    local test_name="$2"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ -f "$file" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo "✗ FAIL: $test_name - File does not exist: $file"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

assert_file_contains() {
    local file="$1"
    local pattern="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if grep -q "$pattern" "$file" 2>/dev/null; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo "✗ FAIL: $test_name - Pattern not found: $pattern"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Clean up any existing log file for testing
cleanup() {
    if [[ -f "$LOG_FILE" ]]; then
        rm -f "$LOG_FILE"
    fi
}

# Test suite
echo "========================================"
echo "Testing lib/core.sh Logging Functions"
echo "========================================"
echo ""

# Clean up before tests
cleanup

# Test 1: log_info creates log file
echo "Test 1: log_info creates log file"
log_info "Test info message" 2>/dev/null
assert_file_exists "$LOG_FILE" "log_info creates log file"
echo ""

# Test 2: log_info writes correct format
echo "Test 2: log_info writes correct format"
log_info "Test info message" 2>/dev/null
assert_file_contains "$LOG_FILE" "\[INFO\] Test info message" "log_info writes correct format"
echo ""

# Test 3: log_error writes to log file
echo "Test 3: log_error writes to log file"
log_error "Test error message" 2>/dev/null
assert_file_contains "$LOG_FILE" "\[ERROR\] Test error message" "log_error writes to log file"
echo ""

# Test 4: log_debug writes to log file
echo "Test 4: log_debug writes to log file"
log_debug "Test debug message" 2>/dev/null
assert_file_contains "$LOG_FILE" "\[DEBUG\] Test debug message" "log_debug writes to log file"
echo ""

# Test 5: Timestamp format is correct
echo "Test 5: Timestamp format is correct"
log_info "Timestamp test" 2>/dev/null
assert_file_contains "$LOG_FILE" "\[20[0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\]" "Timestamp format is correct"
echo ""

# Test 6: Multiple log entries are appended
echo "Test 6: Multiple log entries are appended"
initial_lines=$(wc -l < "$LOG_FILE")
log_info "Additional message" 2>/dev/null
final_lines=$(wc -l < "$LOG_FILE")
TESTS_RUN=$((TESTS_RUN + 1))
if [[ $final_lines -gt $initial_lines ]]; then
    echo "✓ PASS: Multiple log entries are appended"
    TESTS_PASSED=$((TESTS_PASSED + 1))
else
    echo "✗ FAIL: Multiple log entries are appended - Lines not increasing"
    TESTS_FAILED=$((TESTS_FAILED + 1))
fi
echo ""

# Test 7: Log directory is created if it doesn't exist
echo "Test 7: Log directory is created if it doesn't exist"
cleanup
rm -rf "$LOG_DIR" 2>/dev/null
log_info "Directory creation test" 2>/dev/null
assert_file_exists "$LOG_DIR" "Log directory is created"
echo ""

# Display test results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
