#!/bin/bash
# Test suite for Plugin API functions

# Setup test environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/../lib"

# Source required libraries
source "${LIB_DIR}/core.sh"
source "${LIB_DIR}/config.sh"
source "${LIB_DIR}/distro.sh"
source "${LIB_DIR}/package_manager.sh"
source "${LIB_DIR}/plugin.sh"

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
test_start() {
    echo "TEST: $1"
    ((TESTS_RUN++))
}

test_pass() {
    echo "  ✓ PASS"
    ((TESTS_PASSED++))
}

test_fail() {
    echo "  ✗ FAIL: $1"
    ((TESTS_FAILED++))
}

# Setup test environment
setup_test_env() {
    export TEST_MODE=1
    export LOG_LEVEL="ERROR"
    
    # Create test directories
    export TEST_CONFIG_DIR="/tmp/test_plugin_api_$$"
    export HOME="$TEST_CONFIG_DIR"
    mkdir -p "$TEST_CONFIG_DIR/.config/precoreshub"
    mkdir -p "$TEST_CONFIG_DIR/.cache/precoreshub"
    
    # Initialize config
    config_init &>/dev/null || true
}

# Cleanup test environment
cleanup_test_env() {
    rm -rf "$TEST_CONFIG_DIR" 2>/dev/null || true
}

# ============================================================================
# Test Cases
# ============================================================================

# Test 1: phub_notify with info type
test_phub_notify_info() {
    test_start "phub_notify with info type"
    
    if phub_notify "Test info message" "info" &>/dev/null; then
        test_pass
    else
        test_fail "Failed to send info notification"
    fi
}

# Test 2: phub_notify with error type
test_phub_notify_error() {
    test_start "phub_notify with error type"
    
    if phub_notify "Test error message" "error" &>/dev/null; then
        test_pass
    else
        test_fail "Failed to send error notification"
    fi
}

# Test 3: phub_notify with success type
test_phub_notify_success() {
    test_start "phub_notify with success type"
    
    if phub_notify "Test success message" "success" &>/dev/null; then
        test_pass
    else
        test_fail "Failed to send success notification"
    fi
}

# Test 4: phub_notify without message (should fail)
test_phub_notify_no_message() {
    test_start "phub_notify without message (should fail)"
    
    if phub_notify "" &>/dev/null; then
        test_fail "Should have failed with empty message"
    else
        test_pass
    fi
}

# Test 5: phub_config_get with valid key
test_phub_config_get_valid() {
    test_start "phub_config_get with valid key"
    
    # Set a test value first
    config_set "test_key" "test_value" &>/dev/null
    
    local value
    value=$(phub_config_get "test_key" 2>/dev/null)
    
    if [[ "$value" == "test_value" ]]; then
        test_pass
    else
        test_fail "Expected 'test_value', got '$value'"
    fi
}

# Test 6: phub_config_get with invalid key
test_phub_config_get_invalid() {
    test_start "phub_config_get with invalid key"
    
    if phub_config_get "nonexistent_key_12345" &>/dev/null; then
        test_fail "Should have failed with nonexistent key"
    else
        test_pass
    fi
}

# Test 7: phub_config_get without key (should fail)
test_phub_config_get_no_key() {
    test_start "phub_config_get without key (should fail)"
    
    if phub_config_get "" &>/dev/null; then
        test_fail "Should have failed with empty key"
    else
        test_pass
    fi
}

# Test 8: phub_config_set with valid key and value
test_phub_config_set_valid() {
    test_start "phub_config_set with valid key and value"
    
    if phub_config_set "api_test_key" "api_test_value" &>/dev/null; then
        # Verify it was set
        local value
        value=$(config_get "api_test_key" 2>/dev/null)
        if [[ "$value" == "api_test_value" ]]; then
            test_pass
        else
            test_fail "Value not set correctly"
        fi
    else
        test_fail "Failed to set config value"
    fi
}

# Test 9: phub_config_set without key (should fail)
test_phub_config_set_no_key() {
    test_start "phub_config_set without key (should fail)"
    
    if phub_config_set "" "value" &>/dev/null; then
        test_fail "Should have failed with empty key"
    else
        test_pass
    fi
}

# Test 10: phub_config_set without value (should fail)
test_phub_config_set_no_value() {
    test_start "phub_config_set without value (should fail)"
    
    if phub_config_set "key" "" &>/dev/null; then
        test_fail "Should have failed with empty value"
    else
        test_pass
    fi
}

# Test 11: phub_get_distro returns valid JSON
test_phub_get_distro_json() {
    test_start "phub_get_distro returns valid JSON"
    
    local distro_info
    distro_info=$(phub_get_distro 2>/dev/null)
    
    if echo "$distro_info" | jq empty 2>/dev/null; then
        test_pass
    else
        test_fail "Invalid JSON returned"
    fi
}

# Test 12: phub_get_distro has required fields
test_phub_get_distro_fields() {
    test_start "phub_get_distro has required fields"
    
    local distro_info
    distro_info=$(phub_get_distro 2>/dev/null)
    
    local id=$(echo "$distro_info" | jq -r '.id // null' 2>/dev/null)
    local name=$(echo "$distro_info" | jq -r '.name // null' 2>/dev/null)
    local pkg_manager=$(echo "$distro_info" | jq -r '.package_manager // null' 2>/dev/null)
    
    if [[ "$id" != "null" && "$name" != "null" && "$pkg_manager" != "null" ]]; then
        test_pass
    else
        test_fail "Missing required fields (id: $id, name: $name, package_manager: $pkg_manager)"
    fi
}

# Test 13: phub_execute_command with valid command
test_phub_execute_command_valid() {
    test_start "phub_execute_command with valid command"
    
    if phub_execute_command "echo test" &>/dev/null; then
        test_pass
    else
        test_fail "Failed to execute valid command"
    fi
}

# Test 14: phub_execute_command with invalid command
test_phub_execute_command_invalid() {
    test_start "phub_execute_command with invalid command"
    
    if phub_execute_command "nonexistent_command_12345" &>/dev/null; then
        test_fail "Should have failed with invalid command"
    else
        test_pass
    fi
}

# Test 15: phub_execute_command without command (should fail)
test_phub_execute_command_no_command() {
    test_start "phub_execute_command without command (should fail)"
    
    if phub_execute_command "" &>/dev/null; then
        test_fail "Should have failed with empty command"
    else
        test_pass
    fi
}

# Test 16: phub_is_installed with bash (should be installed)
test_phub_is_installed_bash() {
    test_start "phub_is_installed with bash (should be installed)"
    
    if phub_is_installed "bash" &>/dev/null; then
        test_pass
    else
        test_fail "bash should be installed"
    fi
}

# Test 17: phub_is_installed with nonexistent package
test_phub_is_installed_nonexistent() {
    test_start "phub_is_installed with nonexistent package"
    
    if phub_is_installed "nonexistent_package_xyz_12345" &>/dev/null; then
        test_fail "Nonexistent package should not be installed"
    else
        test_pass
    fi
}

# Test 18: phub_is_installed without package name (should fail)
test_phub_is_installed_no_package() {
    test_start "phub_is_installed without package name (should fail)"
    
    if phub_is_installed "" &>/dev/null; then
        test_fail "Should have failed with empty package name"
    else
        test_pass
    fi
}

# Test 19: phub_install_package without package name (should fail)
test_phub_install_package_no_package() {
    test_start "phub_install_package without package name (should fail)"
    
    if phub_install_package "" &>/dev/null; then
        test_fail "Should have failed with empty package name"
    else
        test_pass
    fi
}

# Test 20: API functions are exported and callable
test_api_functions_exported() {
    test_start "API functions are exported and callable"
    
    local functions=("phub_install_package" "phub_execute_command" "phub_notify" "phub_config_get" "phub_config_set" "phub_get_distro" "phub_is_installed")
    local all_exported=true
    
    for func in "${functions[@]}"; do
        if ! declare -f "$func" &>/dev/null; then
            all_exported=false
            break
        fi
    done
    
    if $all_exported; then
        test_pass
    else
        test_fail "Not all API functions are exported"
    fi
}

# Test 21: Plugin can use API functions (integration test)
test_plugin_api_integration() {
    test_start "Plugin can use API functions (integration test)"
    
    # Initialize plugin system
    plugin_init &>/dev/null
    
    # Load example plugin
    if plugin_load "example" &>/dev/null; then
        # Enable plugin
        if plugin_enable "example" &>/dev/null; then
            # Execute a simple function that uses API
            if plugin_execute "example" "demo_distro" &>/dev/null; then
                test_pass
            else
                test_fail "Failed to execute plugin function using API"
            fi
        else
            test_fail "Failed to enable plugin"
        fi
    else
        test_fail "Failed to load example plugin"
    fi
}

# Test 22: API validation - all functions validate inputs
test_api_input_validation() {
    test_start "API validation - all functions validate inputs"
    
    local validation_passed=true
    
    # Test each API function with empty/invalid inputs
    if phub_notify "" &>/dev/null; then validation_passed=false; fi
    if phub_config_get "" &>/dev/null; then validation_passed=false; fi
    if phub_config_set "" "value" &>/dev/null; then validation_passed=false; fi
    if phub_config_set "key" "" &>/dev/null; then validation_passed=false; fi
    if phub_execute_command "" &>/dev/null; then validation_passed=false; fi
    if phub_is_installed "" &>/dev/null; then validation_passed=false; fi
    if phub_install_package "" &>/dev/null; then validation_passed=false; fi
    
    if $validation_passed; then
        test_pass
    else
        test_fail "Some API functions don't validate inputs properly"
    fi
}

# ============================================================================
# Run All Tests
# ============================================================================

echo "========================================"
echo "Plugin API Test Suite"
echo "========================================"
echo ""

# Setup
setup_test_env

# Run tests
test_phub_notify_info
test_phub_notify_error
test_phub_notify_success
test_phub_notify_no_message
test_phub_config_get_valid
test_phub_config_get_invalid
test_phub_config_get_no_key
test_phub_config_set_valid
test_phub_config_set_no_key
test_phub_config_set_no_value
test_phub_get_distro_json
test_phub_get_distro_fields
test_phub_execute_command_valid
test_phub_execute_command_invalid
test_phub_execute_command_no_command
test_phub_is_installed_bash
test_phub_is_installed_nonexistent
test_phub_is_installed_no_package
test_phub_install_package_no_package
test_api_functions_exported
test_plugin_api_integration
test_api_input_validation

# Cleanup
cleanup_test_env

# Summary
echo ""
echo "========================================"
echo "Test Summary"
echo "========================================"
echo "Total tests run: $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
