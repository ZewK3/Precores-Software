#!/bin/bash
# Unit tests for lib/favorites.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/favorites.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected" == "$actual" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name - Expected: '$expected', Got: '$actual'"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# Backup and cleanup
backup_favorites() {
    if [[ -f "$FAVORITES_FILE" ]]; then
        cp "$FAVORITES_FILE" "${FAVORITES_FILE}.backup"
    fi
}

restore_favorites() {
    if [[ -f "${FAVORITES_FILE}.backup" ]]; then
        mv "${FAVORITES_FILE}.backup" "$FAVORITES_FILE"
    else
        rm -f "$FAVORITES_FILE"
    fi
}

echo "========================================"
echo "Testing lib/favorites.sh"
echo "========================================"
echo ""

# Backup existing favorites
backup_favorites

# Test 1: favorites_add creates entry
echo "Test 1: favorites_add creates entry"
rm -f "$FAVORITES_FILE"
if favorites_add "docker" 2>/dev/null; then
    assert_success "favorites_add creates entry"
else
    assert_failure "favorites_add creates entry"
fi
echo ""

# Test 2: favorites_is_favorite detects favorited app
echo "Test 2: favorites_is_favorite detects favorited app"
if favorites_is_favorite "docker" 2>/dev/null; then
    assert_success "favorites_is_favorite detects favorited app"
else
    assert_failure "favorites_is_favorite detects favorited app"
fi
echo ""

# Test 3: favorites_is_favorite returns false for non-favorited app
echo "Test 3: favorites_is_favorite returns false for non-favorited app"
if ! favorites_is_favorite "nginx" 2>/dev/null; then
    assert_success "favorites_is_favorite returns false for non-favorited app"
else
    assert_failure "favorites_is_favorite returns false for non-favorited app"
fi
echo ""

# Test 4: favorites_list returns favorited apps
echo "Test 4: favorites_list returns favorited apps"
favorites_add "nginx" 2>/dev/null
favorites_add "git" 2>/dev/null
list=$(favorites_list 2>/dev/null)
count=$(echo "$list" | wc -l)
if [[ "$count" -ge 3 ]]; then
    assert_success "favorites_list returns favorited apps ($count apps)"
else
    assert_failure "favorites_list returns favorited apps (only $count apps)"
fi
echo ""

# Test 5: favorites_remove removes app
echo "Test 5: favorites_remove removes app"
favorites_remove "nginx" 2>/dev/null
if ! favorites_is_favorite "nginx" 2>/dev/null; then
    assert_success "favorites_remove removes app"
else
    assert_failure "favorites_remove removes app"
fi
echo ""

# Test 6: favorites_count returns correct count
echo "Test 6: favorites_count returns correct count"
count=$(favorites_count 2>/dev/null)
# Should have docker and git (nginx was removed)
if [[ "$count" -eq 2 ]]; then
    assert_success "favorites_count returns correct count ($count)"
else
    assert_failure "favorites_count returns correct count (expected 2, got $count)"
fi
echo ""

# Test 7: favorites_toggle adds when not favorited
echo "Test 7: favorites_toggle adds when not favorited"
favorites_toggle "python" 2>/dev/null
if favorites_is_favorite "python" 2>/dev/null; then
    assert_success "favorites_toggle adds when not favorited"
else
    assert_failure "favorites_toggle adds when not favorited"
fi
echo ""

# Test 8: favorites_toggle removes when favorited
echo "Test 8: favorites_toggle removes when favorited"
favorites_toggle "python" 2>/dev/null
if ! favorites_is_favorite "python" 2>/dev/null; then
    assert_success "favorites_toggle removes when favorited"
else
    assert_failure "favorites_toggle removes when favorited"
fi
echo ""

# Test 9: favorites_get_indicator returns star for favorited
echo "Test 9: favorites_get_indicator returns star for favorited"
indicator=$(favorites_get_indicator "docker" 2>/dev/null)
if [[ "$indicator" == "★" ]]; then
    assert_success "favorites_get_indicator returns star for favorited"
else
    assert_failure "favorites_get_indicator returns star for favorited (got: '$indicator')"
fi
echo ""

# Test 10: favorites_get_indicator returns empty for non-favorited
echo "Test 10: favorites_get_indicator returns empty for non-favorited"
indicator=$(favorites_get_indicator "nginx" 2>/dev/null)
if [[ -z "$indicator" ]]; then
    assert_success "favorites_get_indicator returns empty for non-favorited"
else
    assert_failure "favorites_get_indicator returns empty for non-favorited (got: '$indicator')"
fi
echo ""

# Test 11: favorites_export returns valid JSON
echo "Test 11: favorites_export returns valid JSON"
export_json=$(favorites_export 2>/dev/null)
if [[ -n "$export_json" ]] && echo "$export_json" | jq empty 2>/dev/null; then
    assert_success "favorites_export returns valid JSON"
else
    assert_failure "favorites_export returns valid JSON"
fi
echo ""

# Test 12: favorites_import imports JSON
echo "Test 12: favorites_import imports JSON"
import_data='{"applications":["vim","emacs","nano"]}'
if favorites_import "$import_data" 2>/dev/null; then
    count=$(favorites_count 2>/dev/null)
    if [[ "$count" -eq 3 ]]; then
        assert_success "favorites_import imports JSON ($count apps)"
    else
        assert_failure "favorites_import imports JSON (expected 3, got $count)"
    fi
else
    assert_failure "favorites_import imports JSON"
fi
echo ""

# Test 13: favorites_add prevents duplicates
echo "Test 13: favorites_add prevents duplicates"
favorites_add "vim" 2>/dev/null
favorites_add "vim" 2>/dev/null
count=$(favorites_list 2>/dev/null | grep -c "^vim$")
if [[ "$count" -eq 1 ]]; then
    assert_success "favorites_add prevents duplicates"
else
    assert_failure "favorites_add prevents duplicates (found $count instances)"
fi
echo ""

# Test 14: Favorites file is valid JSON
echo "Test 14: Favorites file is valid JSON"
if jq empty "$FAVORITES_FILE" 2>/dev/null; then
    assert_success "Favorites file is valid JSON"
else
    assert_failure "Favorites file is valid JSON"
fi
echo ""

# Test 15: favorites_menu displays correctly
echo "Test 15: favorites_menu displays correctly"
output=$(favorites_menu 2>/dev/null)
if [[ -n "$output" ]] && echo "$output" | grep -q "Favorite Applications"; then
    assert_success "favorites_menu displays correctly"
else
    assert_failure "favorites_menu displays correctly"
fi
echo ""

# Test 16: favorites_menu shows empty message when no favorites
echo "Test 16: favorites_menu shows empty message when no favorites"
rm -f "$FAVORITES_FILE"
_favorites_init 2>/dev/null
output=$(favorites_menu 2>/dev/null)
if echo "$output" | grep -q "No favorite applications yet"; then
    assert_success "favorites_menu shows empty message when no favorites"
else
    assert_failure "favorites_menu shows empty message when no favorites"
fi
echo ""

# Restore favorites
restore_favorites

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
