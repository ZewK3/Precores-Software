#!/bin/bash
# Unit tests for lib/config.sh

# Source the libraries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"
source "${SCRIPT_DIR}/../lib/config.sh"

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
assert_success() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✓ PASS: $test_name"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

assert_failure() {
    local test_name="$1"
    TESTS_RUN=$((TESTS_RUN + 1))
    echo "✗ FAIL: $test_name"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected" == "$actual" ]]; then
        echo "✓ PASS: $test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
    else
        echo "✗ FAIL: $test_name"
        echo "  Expected: $expected"
        echo "  Actual:   $actual"
        TESTS_FAILED=$((TESTS_FAILED + 1))
    fi
}

# Backup and cleanup
backup_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        cp "$CONFIG_FILE" "${CONFIG_FILE}.backup"
    fi
}

restore_config() {
    if [[ -f "${CONFIG_FILE}.backup" ]]; then
        mv "${CONFIG_FILE}.backup" "$CONFIG_FILE"
    else
        rm -f "$CONFIG_FILE"
    fi
}

cleanup() {
    restore_config
}

echo "========================================"
echo "Testing lib/config.sh"
echo "========================================"
echo ""

# Backup existing config
backup_config

# Test 1: config_init creates config file
echo "Test 1: config_init creates config file"
rm -f "$CONFIG_FILE"
if config_init 2>/dev/null; then
    if [[ -f "$CONFIG_FILE" ]]; then
        assert_success "config_init creates config file"
    else
        assert_failure "config_init creates config file - File not created"
    fi
else
    assert_failure "config_init creates config file - Function failed"
fi
echo ""

# Test 2: config_load reads configuration
echo "Test 2: config_load reads configuration"
if config_load 2>/dev/null; then
    assert_success "config_load reads configuration"
else
    assert_failure "config_load reads configuration"
fi
echo ""

# Test 3: config_get retrieves values
echo "Test 3: config_get retrieves values"
value=$(config_get "language" 2>/dev/null)
assert_equals "en" "$value" "config_get retrieves language"
echo ""

# Test 4: config_get retrieves parallel_installs
echo "Test 4: config_get retrieves parallel_installs"
value=$(config_get "parallel_installs" 2>/dev/null)
assert_equals "3" "$value" "config_get retrieves parallel_installs"
echo ""

# Test 5: config_set updates value
echo "Test 5: config_set updates value"
if config_set "language" "vi" 2>/dev/null; then
    value=$(config_get "language" 2>/dev/null)
    assert_equals "vi" "$value" "config_set updates language"
else
    assert_failure "config_set updates language"
fi
echo ""

# Test 6: config_validate accepts valid values
echo "Test 6: config_validate accepts valid values"
if config_validate "parallel_installs" "5" 2>/dev/null; then
    assert_success "config_validate accepts valid parallel_installs"
else
    assert_failure "config_validate accepts valid parallel_installs"
fi
echo ""

# Test 7: config_validate rejects invalid values
echo "Test 7: config_validate rejects invalid values"
if config_validate "parallel_installs" "20" 2>/dev/null; then
    assert_failure "config_validate rejects invalid parallel_installs - Should have failed"
else
    assert_success "config_validate rejects invalid parallel_installs"
fi
echo ""

# Test 8: config_validate rejects invalid language
echo "Test 8: config_validate rejects invalid language"
if config_validate "language" "english" 2>/dev/null; then
    assert_failure "config_validate rejects invalid language - Should have failed"
else
    assert_success "config_validate rejects invalid language"
fi
echo ""

# Test 9: config_reset restores defaults
echo "Test 9: config_reset restores defaults"
config_set "language" "vi" --no-save 2>/dev/null
if config_reset 2>/dev/null; then
    value=$(config_get "language" 2>/dev/null)
    assert_equals "en" "$value" "config_reset restores default language"
else
    assert_failure "config_reset restores defaults"
fi
echo ""

# Test 10: config_save persists changes
echo "Test 10: config_save persists changes"
config_set "parallel_installs" "5" --no-save 2>/dev/null
if config_save 2>/dev/null; then
    # Reload and check
    config_load 2>/dev/null
    value=$(config_get "parallel_installs" 2>/dev/null)
    assert_equals "5" "$value" "config_save persists changes"
else
    assert_failure "config_save persists changes"
fi
echo ""

# Cleanup
cleanup

# Display results
echo "========================================"
echo "Test Results"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [[ $TESTS_FAILED -eq 0 ]]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
