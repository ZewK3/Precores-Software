#!/bin/bash
# tests/test_core_string_validation.sh
# Unit tests for string manipulation utilities and validation functions

# Source the core library
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/core.sh"

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test result tracking
declare -a FAILED_TESTS

# Color codes for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Assert function
assert_equals() {
    local expected="$1"
    local actual="$2"
    local test_name="$3"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected" == "$actual" ]]; then
        TESTS_PASSED=$((TESTS_PASSED + 1))
        echo -e "${GREEN}✓${NC} $test_name"
        return 0
    else
        TESTS_FAILED=$((TESTS_FAILED + 1))
        FAILED_TESTS+=("$test_name: expected '$expected', got '$actual'")
        echo -e "${RED}✗${NC} $test_name"
        echo "  Expected: '$expected'"
        echo "  Got:      '$actual'"
        return 1
    fi
}

# Assert exit code
assert_exit_code() {
    local expected_code="$1"
    local actual_code="$2"
    local test_name="$3"
    
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if [[ "$expected_code" -eq "$actual_code" ]]; then
        TESTS_PASSED=$((TESTS_PASSED + 1))
        echo -e "${GREEN}✓${NC} $test_name"
        return 0
    else
        TESTS_FAILED=$((TESTS_FAILED + 1))
        FAILED_TESTS+=("$test_name: expected exit code $expected_code, got $actual_code")
        echo -e "${RED}✗${NC} $test_name"
        echo "  Expected exit code: $expected_code"
        echo "  Got exit code:      $actual_code"
        return 1
    fi
}

echo "=========================================="
echo "Testing String Manipulation Utilities"
echo "=========================================="

# Test trim()
echo -e "\n${YELLOW}Testing trim()${NC}"
result=$(trim "  hello  ")
assert_equals "hello" "$result" "trim: removes leading and trailing spaces"

result=$(trim "	hello	")
assert_equals "hello" "$result" "trim: removes leading and trailing tabs"

result=$(trim "hello")
assert_equals "hello" "$result" "trim: no change when no whitespace"

result=$(trim "  hello world  ")
assert_equals "hello world" "$result" "trim: preserves internal spaces"

result=$(trim "")
assert_equals "" "$result" "trim: handles empty string"

# Test to_lower()
echo -e "\n${YELLOW}Testing to_lower()${NC}"
result=$(to_lower "HELLO")
assert_equals "hello" "$result" "to_lower: converts uppercase to lowercase"

result=$(to_lower "Hello World")
assert_equals "hello world" "$result" "to_lower: converts mixed case to lowercase"

result=$(to_lower "hello")
assert_equals "hello" "$result" "to_lower: no change when already lowercase"

result=$(to_lower "123ABC")
assert_equals "123abc" "$result" "to_lower: handles alphanumeric strings"

result=$(to_lower "")
assert_equals "" "$result" "to_lower: handles empty string"

# Test to_upper()
echo -e "\n${YELLOW}Testing to_upper()${NC}"
result=$(to_upper "hello")
assert_equals "HELLO" "$result" "to_upper: converts lowercase to uppercase"

result=$(to_upper "Hello World")
assert_equals "HELLO WORLD" "$result" "to_upper: converts mixed case to uppercase"

result=$(to_upper "HELLO")
assert_equals "HELLO" "$result" "to_upper: no change when already uppercase"

result=$(to_upper "123abc")
assert_equals "123ABC" "$result" "to_upper: handles alphanumeric strings"

result=$(to_upper "")
assert_equals "" "$result" "to_upper: handles empty string"

# Test str_contains()
echo -e "\n${YELLOW}Testing str_contains()${NC}"
str_contains "hello world" "world"
assert_exit_code 0 $? "str_contains: finds substring at end"

str_contains "hello world" "hello"
assert_exit_code 0 $? "str_contains: finds substring at beginning"

str_contains "hello world" "lo wo"
assert_exit_code 0 $? "str_contains: finds substring in middle"

str_contains "hello world" "xyz"
assert_exit_code 1 $? "str_contains: returns 1 when substring not found"

str_contains "hello world" ""
assert_exit_code 0 $? "str_contains: empty needle always matches"

str_contains "" "hello"
assert_exit_code 1 $? "str_contains: non-empty needle doesn't match empty haystack"

# Test str_replace()
echo -e "\n${YELLOW}Testing str_replace()${NC}"
result=$(str_replace "hello world" "world" "universe")
assert_equals "hello universe" "$result" "str_replace: replaces single occurrence"

result=$(str_replace "hello hello" "hello" "hi")
assert_equals "hi hi" "$result" "str_replace: replaces all occurrences"

result=$(str_replace "hello world" "xyz" "abc")
assert_equals "hello world" "$result" "str_replace: no change when search not found"

result=$(str_replace "hello world" "" "x")
assert_equals "hello world" "$result" "str_replace: no change when search is empty"

result=$(str_replace "a,b,c" "," ";")
assert_equals "a;b;c" "$result" "str_replace: replaces delimiter characters"

# Test str_split()
echo -e "\n${YELLOW}Testing str_split()${NC}"
result=$(str_split "a,b,c" ",")
expected=$'a\nb\nc'
assert_equals "$expected" "$result" "str_split: splits by comma"

result=$(str_split "one:two:three" ":")
expected=$'one\ntwo\nthree'
assert_equals "$expected" "$result" "str_split: splits by colon"

result=$(str_split "hello world" " ")
expected=$'hello\nworld'
assert_equals "$expected" "$result" "str_split: splits by space"

result=$(str_split "single" ",")
assert_equals "single" "$result" "str_split: single element when delimiter not found"

str_split "a,b,c" "" >/dev/null 2>&1
assert_exit_code 1 $? "str_split: returns error when delimiter is empty"

echo ""
echo "=========================================="
echo "Testing Validation Functions"
echo "=========================================="

# Test is_empty()
echo -e "\n${YELLOW}Testing is_empty()${NC}"
is_empty ""
assert_exit_code 0 $? "is_empty: returns 0 for empty string"

is_empty "hello"
assert_exit_code 1 $? "is_empty: returns 1 for non-empty string"

is_empty "   "
assert_exit_code 1 $? "is_empty: returns 1 for whitespace-only string"

# Test is_number()
echo -e "\n${YELLOW}Testing is_number()${NC}"
is_number "123"
assert_exit_code 0 $? "is_number: recognizes positive integer"

is_number "-456"
assert_exit_code 0 $? "is_number: recognizes negative integer"

is_number "123.45"
assert_exit_code 0 $? "is_number: recognizes positive decimal"

is_number "-123.45"
assert_exit_code 0 $? "is_number: recognizes negative decimal"

is_number ".5"
assert_exit_code 0 $? "is_number: recognizes decimal starting with dot"

is_number "123."
assert_exit_code 0 $? "is_number: recognizes decimal ending with dot"

is_number "+123"
assert_exit_code 0 $? "is_number: recognizes number with plus sign"

is_number "abc"
assert_exit_code 1 $? "is_number: rejects alphabetic string"

is_number "12.34.56"
assert_exit_code 1 $? "is_number: rejects multiple decimal points"

is_number ""
assert_exit_code 1 $? "is_number: rejects empty string"

is_number "12a34"
assert_exit_code 1 $? "is_number: rejects alphanumeric string"

# Test is_valid_path()
echo -e "\n${YELLOW}Testing is_valid_path()${NC}"

# Create temporary test file
TEST_FILE=$(mktemp)
is_valid_path "$TEST_FILE"
assert_exit_code 0 $? "is_valid_path: recognizes existing file"
rm -f "$TEST_FILE"

# Create temporary test directory
TEST_DIR=$(mktemp -d)
is_valid_path "$TEST_DIR"
assert_exit_code 0 $? "is_valid_path: recognizes existing directory"
rmdir "$TEST_DIR"

is_valid_path "/nonexistent/path/to/file"
assert_exit_code 1 $? "is_valid_path: rejects non-existent path"

is_valid_path ""
assert_exit_code 1 $? "is_valid_path: rejects empty path"

is_valid_path "/tmp"
assert_exit_code 0 $? "is_valid_path: recognizes /tmp directory"

# Test is_valid_json()
echo -e "\n${YELLOW}Testing is_valid_json()${NC}"

# Check if jq is available
if command -v jq &> /dev/null; then
    is_valid_json '{"key": "value"}'
    assert_exit_code 0 $? "is_valid_json: recognizes valid JSON object"
    
    is_valid_json '["a", "b", "c"]'
    assert_exit_code 0 $? "is_valid_json: recognizes valid JSON array"
    
    is_valid_json '"string"'
    assert_exit_code 0 $? "is_valid_json: recognizes valid JSON string"
    
    is_valid_json '123'
    assert_exit_code 0 $? "is_valid_json: recognizes valid JSON number"
    
    is_valid_json 'true'
    assert_exit_code 0 $? "is_valid_json: recognizes valid JSON boolean"
    
    is_valid_json 'null'
    assert_exit_code 0 $? "is_valid_json: recognizes valid JSON null"
    
    is_valid_json '{"key": "value"'
    assert_exit_code 1 $? "is_valid_json: rejects malformed JSON (missing brace)"
    
    is_valid_json 'not json'
    assert_exit_code 1 $? "is_valid_json: rejects invalid JSON string"
    
    is_valid_json ''
    assert_exit_code 1 $? "is_valid_json: rejects empty string"
else
    echo -e "${YELLOW}⚠${NC} Skipping is_valid_json tests (jq not installed)"
    TESTS_RUN=$((TESTS_RUN + 9))
fi

# Test is_command_available()
echo -e "\n${YELLOW}Testing is_command_available()${NC}"
is_command_available "bash"
assert_exit_code 0 $? "is_command_available: recognizes bash command"

is_command_available "ls"
assert_exit_code 0 $? "is_command_available: recognizes ls command"

is_command_available "nonexistent_command_xyz123"
assert_exit_code 1 $? "is_command_available: rejects non-existent command"

is_command_available ""
assert_exit_code 1 $? "is_command_available: rejects empty command name"

# Print summary
echo ""
echo "=========================================="
echo "Test Summary"
echo "=========================================="
echo "Tests run:    $TESTS_RUN"
echo -e "Tests passed: ${GREEN}$TESTS_PASSED${NC}"
echo -e "Tests failed: ${RED}$TESTS_FAILED${NC}"

if [[ $TESTS_FAILED -gt 0 ]]; then
    echo ""
    echo "Failed tests:"
    for failed_test in "${FAILED_TESTS[@]}"; do
        echo -e "  ${RED}✗${NC} $failed_test"
    done
    echo ""
    exit 1
else
    echo ""
    echo -e "${GREEN}All tests passed!${NC}"
    echo ""
    exit 0
fi
