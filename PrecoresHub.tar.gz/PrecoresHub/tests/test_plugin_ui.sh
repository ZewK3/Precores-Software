#!/bin/bash
# Test suite for Plugin UI functions

# Setup test environment
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/../lib"

# Source required libraries
source "${LIB_DIR}/core.sh"
source "${LIB_DIR}/plugin.sh"
source "${LIB_DIR}/plugin_ui.sh"

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Test helper functions
test_start() {
    echo "TEST: $1"
    ((TESTS_RUN++))
}

test_pass() {
    echo "  ✓ PASS"
    ((TESTS_PASSED++))
}

test_fail() {
    echo "  ✗ FAIL: $1"
    ((TESTS_FAILED++))
}

# Setup test environment
setup_test_env() {
    export TEST_MODE=1
    export LOG_LEVEL="ERROR"
    export FZF_AVAILABLE=false  # Disable fzf for tests
    
    # Create test directories
    export TEST_PLUGIN_DIR="/tmp/test_plugin_ui_$$"
    export HOME="$TEST_PLUGIN_DIR"
    mkdir -p "$TEST_PLUGIN_DIR/.config/precoreshub/plugins"
    mkdir -p "$TEST_PLUGIN_DIR/.cache/precoreshub"
    
    # Override plugin directories for testing
    export PLUGIN_DIR="${SCRIPT_DIR}/../plugins"
    export USER_PLUGIN_DIR="$TEST_PLUGIN_DIR/.config/precoreshub/plugins"
    
    # Initialize plugin system
    plugin_init &>/dev/null
}

# Cleanup test environment
cleanup_test_env() {
    rm -rf "$TEST_PLUGIN_DIR" 2>/dev/null || true
}

# ============================================================================
# Test Cases
# ============================================================================

# Test 1: plugin_ui.sh is sourceable
test_plugin_ui_sourceable() {
    test_start "plugin_ui.sh is sourceable"
    
    if [[ -f "${LIB_DIR}/plugin_ui.sh" ]]; then
        test_pass
    else
        test_fail "plugin_ui.sh not found"
    fi
}

# Test 2: plugin_menu function exists
test_plugin_menu_exists() {
    test_start "plugin_menu function exists"
    
    if declare -f plugin_menu &>/dev/null; then
        test_pass
    else
        test_fail "plugin_menu function not found"
    fi
}

# Test 3: plugin_ui_list_all function exists
test_plugin_ui_list_all_exists() {
    test_start "plugin_ui_list_all function exists"
    
    if declare -f plugin_ui_list_all &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_list_all function not found"
    fi
}

# Test 4: plugin_ui_enable function exists
test_plugin_ui_enable_exists() {
    test_start "plugin_ui_enable function exists"
    
    if declare -f plugin_ui_enable &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_enable function not found"
    fi
}

# Test 5: plugin_ui_disable function exists
test_plugin_ui_disable_exists() {
    test_start "plugin_ui_disable function exists"
    
    if declare -f plugin_ui_disable &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_disable function not found"
    fi
}

# Test 6: plugin_ui_details function exists
test_plugin_ui_details_exists() {
    test_start "plugin_ui_details function exists"
    
    if declare -f plugin_ui_details &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_details function not found"
    fi
}

# Test 7: plugin_ui_execute function exists
test_plugin_ui_execute_exists() {
    test_start "plugin_ui_execute function exists"
    
    if declare -f plugin_ui_execute &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_execute function not found"
    fi
}

# Test 8: plugin_ui_check_deps function exists
test_plugin_ui_check_deps_exists() {
    test_start "plugin_ui_check_deps function exists"
    
    if declare -f plugin_ui_check_deps &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_check_deps function not found"
    fi
}

# Test 9: plugin_ui_refresh function exists
test_plugin_ui_refresh_exists() {
    test_start "plugin_ui_refresh function exists"
    
    if declare -f plugin_ui_refresh &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_refresh function not found"
    fi
}

# Test 10: plugin_ui_show_menu_items function exists
test_plugin_ui_show_menu_items_exists() {
    test_start "plugin_ui_show_menu_items function exists"
    
    if declare -f plugin_ui_show_menu_items &>/dev/null; then
        test_pass
    else
        test_fail "plugin_ui_show_menu_items function not found"
    fi
}

# Test 11: FZF_AVAILABLE variable is set
test_fzf_available_set() {
    test_start "FZF_AVAILABLE variable is set"
    
    if [[ -n "$FZF_AVAILABLE" ]]; then
        test_pass
    else
        test_fail "FZF_AVAILABLE not set"
    fi
}

# Test 12: plugin_ui_show_menu_items with no enabled plugins
test_show_menu_items_no_plugins() {
    test_start "plugin_ui_show_menu_items with no enabled plugins"
    
    # Should return 0 even with no plugins
    if plugin_ui_show_menu_items &>/dev/null; then
        test_pass
    else
        test_fail "Should succeed with no plugins"
    fi
}

# Test 13: plugin_ui_show_menu_items with enabled plugin
test_show_menu_items_with_plugin() {
    test_start "plugin_ui_show_menu_items with enabled plugin"
    
    # Enable example plugin
    plugin_enable "example" &>/dev/null
    
    # Should show menu items
    local output=$(plugin_ui_show_menu_items 2>/dev/null)
    
    if [[ -n "$output" ]]; then
        test_pass
    else
        test_fail "Should show menu items for enabled plugin"
    fi
    
    # Cleanup
    plugin_disable "example" &>/dev/null
}

# Test 14: All UI functions handle missing plugins gracefully
test_ui_functions_handle_no_plugins() {
    test_start "UI functions handle missing plugins gracefully"
    
    # Temporarily override plugin directory to empty location
    local old_plugin_dir="$PLUGIN_DIR"
    local old_user_plugin_dir="$USER_PLUGIN_DIR"
    
    export PLUGIN_DIR="/tmp/empty_plugins_$$"
    export USER_PLUGIN_DIR="/tmp/empty_user_plugins_$$"
    mkdir -p "$PLUGIN_DIR"
    mkdir -p "$USER_PLUGIN_DIR"
    
    # These should not crash
    local all_ok=true
    
    # Note: We can't test interactive functions without input simulation
    # But we can verify they exist and are callable
    if ! declare -f plugin_ui_list_all &>/dev/null; then all_ok=false; fi
    if ! declare -f plugin_ui_enable &>/dev/null; then all_ok=false; fi
    if ! declare -f plugin_ui_disable &>/dev/null; then all_ok=false; fi
    if ! declare -f plugin_ui_details &>/dev/null; then all_ok=false; fi
    if ! declare -f plugin_ui_execute &>/dev/null; then all_ok=false; fi
    if ! declare -f plugin_ui_check_deps &>/dev/null; then all_ok=false; fi
    
    # Cleanup
    rm -rf "$PLUGIN_DIR" "$USER_PLUGIN_DIR"
    export PLUGIN_DIR="$old_plugin_dir"
    export USER_PLUGIN_DIR="$old_user_plugin_dir"
    
    if $all_ok; then
        test_pass
    else
        test_fail "Some UI functions are missing"
    fi
}

# Test 15: plugin_ui_refresh reinitializes plugin system
test_ui_refresh() {
    test_start "plugin_ui_refresh reinitializes plugin system"
    
    # Should succeed
    if plugin_ui_refresh &>/dev/null; then
        test_pass
    else
        test_fail "Refresh failed"
    fi
}

# ============================================================================
# Run All Tests
# ============================================================================

echo "========================================"
echo "Plugin UI Test Suite"
echo "========================================"
echo ""

# Setup
setup_test_env

# Run tests
test_plugin_ui_sourceable
test_plugin_menu_exists
test_plugin_ui_list_all_exists
test_plugin_ui_enable_exists
test_plugin_ui_disable_exists
test_plugin_ui_details_exists
test_plugin_ui_execute_exists
test_plugin_ui_check_deps_exists
test_plugin_ui_refresh_exists
test_plugin_ui_show_menu_items_exists
test_fzf_available_set
test_show_menu_items_no_plugins
test_show_menu_items_with_plugin
test_ui_functions_handle_no_plugins
test_ui_refresh

# Cleanup
cleanup_test_env

# Summary
echo ""
echo "========================================"
echo "Test Summary"
echo "========================================"
echo "Total tests run: $TESTS_RUN"
echo "Tests passed: $TESTS_PASSED"
echo "Tests failed: $TESTS_FAILED"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo "✓ All tests passed!"
    exit 0
else
    echo "✗ Some tests failed"
    exit 1
fi
