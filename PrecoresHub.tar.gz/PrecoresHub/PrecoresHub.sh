#!/bin/bash
################################################################################
# PrecoresHub v5.0.0 - Unified Control Center
# 
# Enhanced version with modular architecture:
# - QuickInstall (App installer with favorites & history)
# - QuickFix (System repair)
# - SystemManager (Monitoring & updates)
# - Plugin System (Extensible functionality)
# - Multi-language support (English & Vietnamese)
# 
# New Features in v5.0.0:
# - Modular library system
# - Plugin architecture
# - Installation history & rollback
# - Favorites/bookmarks
# - Progress tracking
# - Caching system
# - Enhanced error handling
# - Localization (EN/VI)
# - 13 Linux distributions support
################################################################################

VERSION="5.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m'

################################################################################
# LIBRARY LOADING
################################################################################

# Source all library files
source "${SCRIPT_DIR}/lib/core.sh" || {
    echo "ERROR: Failed to load core library"
    exit 1
}

source "${SCRIPT_DIR}/lib/config.sh" || {
    log_error "Failed to load config library"
    exit 1
}

source "${SCRIPT_DIR}/lib/distro.sh" || {
    log_error "Failed to load distro library"
    exit 1
}

source "${SCRIPT_DIR}/lib/package_manager.sh" || {
    log_error "Failed to load package manager library"
    exit 1
}

source "${SCRIPT_DIR}/lib/progress.sh" || {
    log_error "Failed to load progress library"
    exit 1
}

source "${SCRIPT_DIR}/lib/cache.sh" || {
    log_error "Failed to load cache library"
    exit 1
}

source "${SCRIPT_DIR}/lib/history.sh" || {
    log_error "Failed to load history library"
    exit 1
}

source "${SCRIPT_DIR}/lib/favorites.sh" || {
    log_error "Failed to load favorites library"
    exit 1
}

source "${SCRIPT_DIR}/lib/localization.sh" || {
    log_error "Failed to load localization library"
    exit 1
}

source "${SCRIPT_DIR}/lib/error.sh" || {
    log_error "Failed to load error library"
    exit 1
}

source "${SCRIPT_DIR}/lib/plugin.sh" || {
    log_error "Failed to load plugin library"
    exit 1
}

source "${SCRIPT_DIR}/lib/plugin_ui.sh" || {
    log_error "Failed to load plugin UI library"
    exit 1
}

################################################################################
# INITIALIZATION
################################################################################

# Initialize all systems
initialize_systems() {
    log_info "Initializing PrecoresHub v${VERSION}..."
    
    # Initialize configuration
    if [[ ! -f "${HOME}/.config/precoreshub/config.json" ]]; then
        log_info "First run detected, initializing configuration..."
        config_init
    else
        config_load
    fi
    
    # Initialize localization
    lang_init
    local user_lang=$(config_get "language" 2>/dev/null || echo "en")
    lang_set "$user_lang"
    
    # Detect distribution
    detect_distro
    log_info "Detected: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)"
    
    # Initialize cache
    cache_init
    
    # Initialize history
    _history_init
    
    # Initialize favorites
    _favorites_init
    
    # Initialize plugin system
    plugin_init
    
    # Auto-enable example plugin if available
    if plugin_load "example" 2>/dev/null; then
        plugin_enable "example" 2>/dev/null || true
    fi
    
    log_info "Initialization complete"
}

# Check dependencies
check_dependencies() {
    log_info "Checking dependencies..."
    
    local missing_deps=()
    
    # Check for required commands
    if ! command -v jq &>/dev/null; then
        missing_deps+=("jq")
    fi
    
    if ! command -v fzf &>/dev/null; then
        missing_deps+=("fzf")
    fi
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        log_error "Missing dependencies: ${missing_deps[*]}"
        echo ""
        echo "Please install missing dependencies:"
        for dep in "${missing_deps[@]}"; do
            echo "  - $dep"
        done
        echo ""
        
        if confirm_dialog "$(lang_get 'messages.confirm_install_deps' 2>/dev/null || echo 'Install dependencies now?')"; then
            for dep in "${missing_deps[@]}"; do
                log_info "Installing $dep..."
                pkg_install "$dep"
            done
        else
            log_error "Cannot continue without dependencies"
            exit 1
        fi
    fi
    
    log_info "All dependencies satisfied"
}

################################################################################
# FZF HELPER FUNCTIONS
################################################################################

# Confirmation dialog with professional UI
# Usage: confirm_dialog "Question text" "Warning text (optional)"
# Returns: 0 if Yes selected, 1 if No selected or cancelled
confirm_dialog() {
    local question="$1"
    local warning="${2:-}"
    
    local header="╔══════════════════════════════════════════════════════════╗
║                    CONFIRMATION                      ║
╚══════════════════════════════════════════════════════════╝"
    
    if [[ -n "$warning" ]]; then
        header="${header}

  ${warning}"
    fi
    
    local choice=$(printf '%s\n' "[01] Yes" "[02] No" | fzf \
        --ansi \
        --reverse \
        --height=40% \
        --border=rounded \
        --prompt="$question > " \
        --header="$header" \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af" \
        --bind='ctrl-c:abort,esc:abort' || echo "")
    
    if [[ "$choice" == "[01]"* ]]; then
        return 0  # Yes
    else
        return 1  # No or cancelled
    fi
}

# Basic fzf menu
# Usage: fzf_menu "prompt" "option1" "option2" "option3"
# Returns: selected option or empty string if cancelled
fzf_menu() {
    local prompt="$1"
    shift
    local options=("$@")
    
    if [[ ${#options[@]} -eq 0 ]]; then
        log_error "fzf_menu: no options provided"
        return 1
    fi
    
    printf '%s\n' "${options[@]}" | fzf \
        --ansi \
        --reverse \
        --height=40% \
        --border=rounded \
        --cycle \
        --prompt="$prompt > " \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#89b4fa,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#94e2d5" \
        --bind='ctrl-c:abort,esc:abort' || echo ""
}

# fzf menu with preview pane
# Usage: fzf_menu_with_preview "prompt" "preview_command" "option1" "option2"
# Returns: selected option or empty string if cancelled
fzf_menu_with_preview() {
    local prompt="$1"
    local preview_cmd="$2"
    shift 2
    local options=("$@")
    
    if [[ ${#options[@]} -eq 0 ]]; then
        log_error "fzf_menu_with_preview: no options provided"
        return 1
    fi
    
    printf '%s\n' "${options[@]}" | fzf \
        --ansi \
        --reverse \
        --height=80% \
        --border=rounded \
        --cycle \
        --prompt="$prompt > " \
        --preview="$preview_cmd {}" \
        --preview-window=right:50%:wrap \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#89b4fa,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#94e2d5" \
        --bind='ctrl-c:abort,esc:abort' || echo ""
}

# fzf menu with custom header (like old style)
# Usage: fzf_menu_with_header "header_text" "option1" "option2"
# Returns: selected option or empty string if cancelled
fzf_menu_with_header() {
    local header="$1"
    shift
    local options=("$@")
    
    if [[ ${#options[@]} -eq 0 ]]; then
        log_error "fzf_menu_with_header: no options provided"
        return 1
    fi
    
    printf '%s\n' "${options[@]}" | fzf \
        --ansi \
        --reverse \
        --height=80% \
        --border=rounded \
        --cycle \
        --header="$header" \
        --prompt="> " \
        --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#89b4fa,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#94e2d5" \
        --bind='ctrl-c:abort,esc:abort' || echo ""
}

################################################################################
# MAIN MENU
################################################################################

# Print header
print_header() {
    clear
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}${BOLD}═       PrecoresHub v${VERSION} - Control Center              ═${NC}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}System: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)${NC}"
    echo -e "${BLUE}Language: $(config_get 'language' 2>/dev/null || echo 'en')${NC}"
    echo ""
}

# Main menu
main_menu() {
    while true; do
        print_header
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║       PRECORES HUB v${VERSION} - MAIN MENU           ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#89b4fa,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#94e2d5"
[01] $(lang_get 'menu.main.quickinstall')
[02] $(lang_get 'menu.main.quickfix')
[03] $(lang_get 'menu.main.systemmanager')
[04] $(lang_get 'menu.main.favorites')
[05] $(lang_get 'menu.main.history')
[06] $(lang_get 'menu.main.plugins')
[07] $(lang_get 'menu.main.settings')
[00] $(lang_get 'menu.main.exit')
EOF
)
        
        case "$choice" in
            "[01]"*) quickinstall_menu ;;
            "[02]"*) quickfix_menu ;;
            "[03]"*) systemmanager_menu ;;
            "[04]"*) favorites_menu_ui ;;
            "[05]"*) history_menu_ui ;;
            "[06]"*) plugin_menu ;;
            "[07]"*) settings_menu ;;
            "[00]"*) 
                log_info "Exiting PrecoresHub"
                echo "$(lang_get 'messages.goodbye' 2>/dev/null || echo 'Goodbye!')"
                exit 0
                ;;
            "") 
                log_info "Exiting PrecoresHub"
                exit 0
                ;;
        esac
    done
}

################################################################################
# QUICKINSTALL MENU
################################################################################

quickinstall_menu() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.quickinstall.title')${NC}"
        echo ""
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=90% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║        QUICKINSTALL - APPLICATION INSTALLER          ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af"
[01]  $(lang_get 'apps.docker')
[02]  $(lang_get 'apps.vscode')
[03]  $(lang_get 'apps.git')
[04]  $(lang_get 'apps.nodejs')
[05]  $(lang_get 'apps.python')
[06]  $(lang_get 'apps.rust')
[07]  $(lang_get 'apps.go')
[10]  $(lang_get 'apps.chrome')
[11]  $(lang_get 'apps.chromium')
[12]  $(lang_get 'apps.firefox')
[15]  $(lang_get 'apps.discord')
[16]  $(lang_get 'apps.telegram')
[20]  $(lang_get 'apps.vlc')
[21]  $(lang_get 'apps.gimp')
[22]  $(lang_get 'apps.obs')
[25]  $(lang_get 'apps.libreoffice')
[40]  $(lang_get 'apps.postman')
[41]  $(lang_get 'apps.insomnia')
[42]  $(lang_get 'apps.dbeaver')
[43]  $(lang_get 'apps.mongodb_compass')
[44]  $(lang_get 'apps.android_studio')
[45]  $(lang_get 'apps.jetbrains_toolbox')
[50]  $(lang_get 'apps.slack')
[51]  $(lang_get 'apps.zoom')
[52]  $(lang_get 'apps.teams')
[53]  $(lang_get 'apps.skype')
[54]  $(lang_get 'apps.thunderbird')
[60]  $(lang_get 'apps.spotify')
[61]  $(lang_get 'apps.audacity')
[62]  $(lang_get 'apps.kdenlive')
[63]  $(lang_get 'apps.blender')
[64]  $(lang_get 'apps.inkscape')
[70]  $(lang_get 'apps.timeshift')
[71]  $(lang_get 'apps.bleachbit')
[72]  $(lang_get 'apps.stacer')
[73]  $(lang_get 'apps.gparted')
[74]  $(lang_get 'apps.flameshot')
[75]  $(lang_get 'apps.etcher')
[30]  $(lang_get 'menu.quickinstall.update_system')
[31]  $(lang_get 'menu.quickinstall.install_all_dev')
[32]  $(lang_get 'menu.quickinstall.search')
[00]  $(lang_get 'menu.quickinstall.back')
EOF
)
        
        case "$choice" in
            "[01]"*) install_package "docker" ;;
            "[02]"*) install_package "code" ;;
            "[03]"*) install_package "git" ;;
            "[04]"*) install_package "nodejs" ;;
            "[05]"*) install_package "python" ;;
            "[06]"*) install_package "rust" ;;
            "[07]"*) install_package "go" ;;
            "[10]"*) install_package "google-chrome" ;;
            "[11]"*) install_package "chromium" ;;
            "[12]"*) install_package "firefox" ;;
            "[15]"*) install_package "discord" ;;
            "[16]"*) install_package "telegram-desktop" ;;
            "[20]"*) install_package "vlc" ;;
            "[21]"*) install_package "gimp" ;;
            "[22]"*) install_package "obs-studio" ;;
            "[25]"*) install_package "libreoffice" ;;
            "[30]"*) update_system ;;
            "[31]"*) install_all_dev_tools ;;
            "[32]"*) package_search ;;
            "[40]"*) install_package "postman" ;;
            "[41]"*) install_package "insomnia" ;;
            "[42]"*) install_package "dbeaver" ;;
            "[43]"*) install_package "mongodb-compass" ;;
            "[44]"*) install_package "android-studio" ;;
            "[45]"*) install_package "jetbrains-toolbox" ;;
            "[50]"*) install_package "slack" ;;
            "[51]"*) install_package "zoom" ;;
            "[52]"*) install_package "teams" ;;
            "[53]"*) install_package "skype" ;;
            "[54]"*) install_package "thunderbird" ;;
            "[60]"*) install_package "spotify" ;;
            "[61]"*) install_package "audacity" ;;
            "[62]"*) install_package "kdenlive" ;;
            "[63]"*) install_package "blender" ;;
            "[64]"*) install_package "inkscape" ;;
            "[70]"*) install_package "timeshift" ;;
            "[71]"*) install_package "bleachbit" ;;
            "[72]"*) install_package "stacer" ;;
            "[73]"*) install_package "gparted" ;;
            "[74]"*) install_package "flameshot" ;;
            "[75]"*) install_package "etcher" ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

# Install a single package
install_package() {
    local pkg_name="$1"
    clear
    echo -e "${BLUE}[INFO]${NC} $(lang_get 'messages.installing' "$pkg_name")..."
    
    if pkg_install "$pkg_name"; then
        history_record "install" "$pkg_name" "success" "Installed via QuickInstall"
        echo ""
        echo -e "${GREEN}[SUCCESS]${NC} $(lang_get 'messages.installed' "$pkg_name")"
    else
        history_record "install" "$pkg_name" "failure" "Installation failed"
        echo ""
        echo -e "${RED}[ERROR]${NC} $(lang_get 'errors.install_failed' "$pkg_name")"
    fi
    echo ""
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..." 
}

# Update system
update_system() {
    clear
    echo -e "${BLUE}[INFO]${NC} $(lang_get 'messages.updating')..."
    pkg_update
    echo ""
    echo -e "${GREEN}[SUCCESS]${NC} $(lang_get 'messages.updated')"
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..."
}

# Install all dev tools
install_all_dev_tools() {
    clear
    echo -e "${BLUE}[INFO]${NC} Installing all development tools..."
    local dev_tools=("docker" "code" "git" "nodejs" "python")
    for tool in "${dev_tools[@]}"; do
        install_package "$tool"
    done
    echo -e "${GREEN}[SUCCESS]${NC} All dev tools installed!"
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..."
}

# Package search
package_search() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.quickinstall.search')${NC}"
    echo ""
    read -p "$(lang_get 'messages.searching' 2>/dev/null || echo 'Enter package name'): " search_term
    
    if [[ -z "$search_term" ]]; then
        return
    fi
    
    echo ""
    echo -e "${BLUE}[INFO]${NC} $(lang_get 'messages.searching' "$search_term")..."
    pkg_search "$search_term"
    echo ""
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..."
}
################################################################################
# QUICKFIX MENU
################################################################################

quickfix_menu() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.quickfix.title')${NC}"
        echo ""
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║         QUICKFIX - SYSTEM REPAIR & FIXES             ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#f38ba8,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#f38ba8"
[01]  $(lang_get 'menu.quickfix.fix_autologin')
[02]  $(lang_get 'menu.quickfix.fix_zram')
[03]  $(lang_get 'menu.quickfix.fix_firewall')
[04]  $(lang_get 'menu.quickfix.fix_network')
[10]  $(lang_get 'menu.quickfix.update_system')
[11]  $(lang_get 'menu.quickfix.clean_system')
[12]  $(lang_get 'menu.quickfix.system_health')
[20]  $(lang_get 'menu.quickfix.fix_all')
[21]  $(lang_get 'menu.quickfix.full_maintenance')
[00]  $(lang_get 'menu.quickfix.back')
EOF
)
        
        case "$choice" in
            "[01]"*) fix_autologin ;;
            "[02]"*) fix_zram ;;
            "[03]"*) fix_firewall ;;
            "[04]"*) fix_network ;;
            "[10]"*) update_system ;;
            "[11]"*) clean_system ;;
            "[12]"*) check_system_health ;;
            "[20]"*) fix_all_common ;;
            "[21]"*) full_maintenance ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

# Fix functions (placeholders - implement as needed)
fix_autologin() {
    clear
    echo -e "${BLUE}[INFO]${NC} Fixing auto-login..."
    # Implementation here
    read -p "Press Enter to continue..."
}

fix_zram() {
    clear
    echo -e "${BLUE}[INFO]${NC} Setting up zram..."
    # Implementation here
    read -p "Press Enter to continue..."
}

fix_firewall() {
    clear
    echo -e "${BLUE}[INFO]${NC} Configuring firewall..."
    # Implementation here
    read -p "Press Enter to continue..."
}

fix_network() {
    clear
    echo -e "${BLUE}[INFO]${NC} Resetting network..."
    # Implementation here
    read -p "Press Enter to continue..."
}

clean_system() {
    clear
    echo -e "${BLUE}[INFO]${NC} Cleaning system..."
    pkg_clean
    echo -e "${GREEN}[SUCCESS]${NC} System cleaned!"
    read -p "Press Enter to continue..."
}

check_system_health() {
    clear
    echo -e "${BLUE}[INFO]${NC} Checking system health..."
    # Implementation here
    read -p "Press Enter to continue..."
}

fix_all_common() {
    clear
    echo -e "${BLUE}[INFO]${NC} Running all common fixes..."
    # Implementation here
    read -p "Press Enter to continue..."
}

full_maintenance() {
    clear
    echo -e "${BLUE}[INFO]${NC} Running full maintenance..."
    update_system
    clean_system
    echo -e "${GREEN}[SUCCESS]${NC} Full maintenance complete!"
    read -p "Press Enter to continue..."
}

# Fix broken packages
fix_broken_packages() {
    print_header
    echo "Fixing Broken Packages..."
    echo ""
    
    case "$DETECTED_PKG_MANAGER" in
        "apt")
            sudo apt --fix-broken install -y
            ;;
        "dnf"|"yum")
            sudo $DETECTED_PKG_MANAGER check
            ;;
        "pacman")
            sudo pacman -Syy
            ;;
        *)
            echo "Not supported for $DETECTED_PKG_MANAGER"
            ;;
    esac
    
    echo ""
    read -p "Press Enter to continue..."
}

# Check disk space
check_disk_space() {
    print_header
    echo "Disk Space Usage:"
    echo ""
    
    df -h | grep -E '^/dev/'
    
    echo ""
    read -p "Press Enter to continue..."
}

# View system logs
view_system_logs() {
    print_header
    echo "Recent System Logs:"
    echo ""
    
    if command -v journalctl &>/dev/null; then
        sudo journalctl -n 50 --no-pager
    else
        tail -n 50 /var/log/syslog 2>/dev/null || tail -n 50 /var/log/messages 2>/dev/null || echo "No logs available"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# SYSTEMMANAGER MENU
################################################################################

################################################################################
# SYSTEMMANAGER MENU
################################################################################

systemmanager_menu() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.systemmanager.title')${NC}"
        echo ""
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║       SYSTEMMANAGER - SYSTEM MONITORING              ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1"
[01]  $(lang_get 'menu.systemmanager.system_info')
[02]  $(lang_get 'menu.systemmanager.disk_usage')
[03]  $(lang_get 'menu.systemmanager.memory_usage')
[04]  $(lang_get 'menu.systemmanager.cpu_info')
[05]  $(lang_get 'menu.systemmanager.network_info')
[06]  $(lang_get 'menu.systemmanager.services')
[07]  $(lang_get 'menu.systemmanager.processes')
[00]  $(lang_get 'menu.systemmanager.back')
EOF
)
        
        case "$choice" in
            "[01]"*) show_system_info ;;
            "[02]"*) show_disk_usage ;;
            "[03]"*) show_memory_usage ;;
            "[04]"*) show_cpu_info ;;
            "[05]"*) show_network_info ;;
            "[06]"*) show_services ;;
            "[07]"*) show_processes ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

# System information
show_system_info() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.system_info')${NC}"
    echo ""
    echo "Hostname: $(hostname)"
    echo "Kernel: $(uname -r)"
    echo "Architecture: $(uname -m)"
    echo "Distribution: $DETECTED_DISTRO_NAME"
    echo "Package Manager: $DETECTED_PKG_MANAGER"
    echo "Uptime: $(uptime -p 2>/dev/null || uptime)"
    echo ""
    read -p "Press Enter to continue..."
}

show_disk_usage() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.disk_usage')${NC}"
    echo ""
    df -h
    echo ""
    read -p "Press Enter to continue..."
}

show_memory_usage() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.memory_usage')${NC}"
    echo ""
    free -h
    echo ""
    read -p "Press Enter to continue..."
}

show_cpu_info() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.cpu_info')${NC}"
    echo ""
    lscpu | head -20
    echo ""
    read -p "Press Enter to continue..."
}

show_network_info() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.network_info')${NC}"
    echo ""
    ip addr show
    echo ""
    read -p "Press Enter to continue..."
}

show_services() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.services')${NC}"
    echo ""
    systemctl list-units --type=service --state=running | head -20
    echo ""
    read -p "Press Enter to continue..."
}

show_processes() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.systemmanager.processes')${NC}"
    echo ""
    ps aux | head -20
    echo ""
    read -p "Press Enter to continue..."
}

# Network status
show_network_status() {
    print_header
    echo "Network Status:"
    echo ""
    
    ip addr show 2>/dev/null || ifconfig
    
    echo ""
    echo "Active Connections:"
    ss -tuln 2>/dev/null || netstat -tuln
    
    echo ""
    read -p "Press Enter to continue..."
}

# Service status
show_service_status() {
    print_header
    echo "Service Status:"
    echo ""
    
    if command -v systemctl &>/dev/null; then
        systemctl list-units --type=service --state=running
    else
        service --status-all 2>/dev/null || echo "Service management not available"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# FAVORITES MENU
################################################################################

favorites_menu_ui() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.favorites.title')${NC}"
        echo ""
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║              FAVORITES - BOOKMARKED APPS             ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#f9e2af,fg+:#cdd6f4,bg+:#313244,hl+:#f9e2af,info:#cba6f7,prompt:#f9e2af,pointer:#f9e2af,marker:#a6e3a1,spinner:#f5e0dc,header:#f9e2af"
[01]  $(lang_get 'menu.favorites.view_all')
[02]  $(lang_get 'menu.favorites.add')
[03]  $(lang_get 'menu.favorites.remove')
[04]  $(lang_get 'menu.favorites.install_all')
[00]  $(lang_get 'menu.favorites.back')
EOF
)
        
        case "$choice" in
            "[01]"*) view_favorites ;;
            "[02]"*) add_favorite ;;
            "[03]"*) remove_favorite ;;
            "[04]"*) install_all_favorites ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

# View all favorites
view_favorites() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.favorites.view_all')${NC}"
    echo ""
    
    local favs=$(favorites_list)
    if [[ -z "$favs" ]]; then
        echo "No favorites yet."
    else
        echo "$favs"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Add favorite
add_favorite() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.favorites.add')${NC}"
    echo ""
    read -p "Enter package name: " pkg_name
    
    if [[ -z "$pkg_name" ]]; then
        return
    fi
    
    if favorites_add "$pkg_name"; then
        echo -e "${GREEN}[SUCCESS]${NC} Added to favorites!"
    else
        echo -e "${RED}[ERROR]${NC} Failed to add favorite"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Remove favorite
remove_favorite() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.favorites.remove')${NC}"
    echo ""
    
    local favs=$(favorites_list)
    if [[ -z "$favs" ]]; then
        echo "No favorites to remove."
        read -p "Press Enter to continue..."
        return
    fi
    
    echo "Current favorites:"
    echo "$favs"
    echo ""
    read -p "Enter package name to remove: " pkg_name
    
    if [[ -z "$pkg_name" ]]; then
        return
    fi
    
    if favorites_remove "$pkg_name"; then
        echo -e "${GREEN}[SUCCESS]${NC} Removed from favorites!"
    else
        echo -e "${RED}[ERROR]${NC} Failed to remove favorite"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Install all favorites
install_all_favorites() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.favorites.install_all')${NC}"
    echo ""
    
    local favs=$(favorites_list)
    if [[ -z "$favs" ]]; then
        echo "No favorites to install."
        read -p "Press Enter to continue..."
        return
    fi
    
    echo "Installing all favorites..."
    echo ""
    
    while IFS= read -r pkg; do
        install_package "$pkg"
    done <<< "$favs"
    
    echo ""
    echo -e "${GREEN}[SUCCESS]${NC} All favorites processed!"
    read -p "Press Enter to continue..."
}

################################################################################
# HISTORY MENU
################################################################################

history_menu_ui() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.history.title')${NC}"
        echo ""
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║          HISTORY - INSTALLATION RECORDS              ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#a6e3a1,fg+:#cdd6f4,bg+:#313244,hl+:#a6e3a1,info:#cba6f7,prompt:#a6e3a1,pointer:#a6e3a1,marker:#a6e3a1,spinner:#f5e0dc,header:#a6e3a1"
[01]  $(lang_get 'menu.history.view_all')
[02]  $(lang_get 'menu.history.view_recent')
[03]  $(lang_get 'menu.history.view_successful')
[04]  $(lang_get 'menu.history.view_failed')
[05]  $(lang_get 'menu.history.export_json')
[06]  $(lang_get 'menu.history.export_csv')
[07]  $(lang_get 'menu.history.clear')
[00]  $(lang_get 'menu.history.back')
EOF
)
        
        case "$choice" in
            "[01]"*) view_all_history ;;
            "[02]"*) view_recent_history ;;
            "[03]"*) view_successful_history ;;
            "[04]"*) view_failed_history ;;
            "[05]"*) export_history_json ;;
            "[06]"*) export_history_csv ;;
            "[07]"*) clear_history ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

# View all history
view_all_history() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.history.view_all')${NC}"
    echo ""
    history_list
    echo ""
    read -p "Press Enter to continue..."
}

# View recent history
view_recent_history() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.history.view_recent')${NC}"
    echo ""
    history_list | tail -10
    echo ""
    read -p "Press Enter to continue..."
}

# View successful history
view_successful_history() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.history.view_successful')${NC}"
    echo ""
    history_list | grep "success"
    echo ""
    read -p "Press Enter to continue..."
}

# View failed history
view_failed_history() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.history.view_failed')${NC}"
    echo ""
    history_list | grep "failure"
    echo ""
    read -p "Press Enter to continue..."
}

# Export history JSON
export_history_json() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.history.export_json')${NC}"
    echo ""
    local output="history_export_$(date +%Y%m%d_%H%M%S).json"
    history_export "$output"
    echo -e "${GREEN}[SUCCESS]${NC} Exported to $output"
    echo ""
    read -p "Press Enter to continue..."
}

# Export history CSV
export_history_csv() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.history.export_csv')${NC}"
    echo ""
    local output="history_export_$(date +%Y%m%d_%H%M%S).csv"
    history_export_csv "$output"
    echo -e "${GREEN}[SUCCESS]${NC} Exported to $output"
    echo ""
    read -p "Press Enter to continue..."
}

# Clear history
clear_history() {
    clear
    echo -e "${YELLOW}$(lang_get 'menu.history.clear')${NC}"
    echo ""
    
    if confirm_dialog "$(lang_get 'messages.confirm_clear_history' 2>/dev/null || echo 'Clear all history?')" "$(lang_get 'messages.warning_irreversible' 2>/dev/null || echo 'This action cannot be undone!')"; then
        history_clear
        echo -e "${GREEN}[SUCCESS]${NC} $(lang_get 'messages.history_cleared' 2>/dev/null || echo 'History cleared!')"
    else
        echo -e "${BLUE}[INFO]${NC} $(lang_get 'messages.cancelled' 2>/dev/null || echo 'Operation cancelled')"
    fi
    
    echo ""
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..."
}

################################################################################
# PLUGIN MENU
################################################################################

plugin_menu() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.plugins.title')${NC}"
        echo ""
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║         PLUGIN MANAGER - EXTENSIONS                  ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#cba6f7,fg+:#cdd6f4,bg+:#313244,hl+:#cba6f7,info:#cba6f7,prompt:#cba6f7,pointer:#cba6f7,marker:#a6e3a1,spinner:#f5e0dc,header:#cba6f7"
[01]  $(lang_get 'menu.plugins.list_all')
[02]  $(lang_get 'menu.plugins.enable')
[03]  $(lang_get 'menu.plugins.disable')
[04]  $(lang_get 'menu.plugins.details')
[05]  $(lang_get 'menu.plugins.execute')
[06]  $(lang_get 'menu.plugins.check_deps')
[07]  $(lang_get 'menu.plugins.refresh')
[00]  $(lang_get 'menu.plugins.back')
EOF
)
        
        case "$choice" in
            "[01]"*) plugin_ui_list_all ;;
            "[02]"*) plugin_ui_enable ;;
            "[03]"*) plugin_ui_disable ;;
            "[04]"*) plugin_ui_details ;;
            "[05]"*) plugin_ui_execute ;;
            "[06]"*) plugin_ui_check_deps ;;
            "[07]"*) plugin_ui_refresh ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

view_all_history() {
    print_header
    echo "All Installation History:"
    echo ""
    
    history_list | jq -r '.[] | "\(.timestamp) | \(.operation) | \(.package) | \(.status)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

view_recent_history() {
    print_header
    echo "Recent History (Last 10):"
    echo ""
    
    history_list | jq -r '.[-10:] | .[] | "\(.timestamp) | \(.operation) | \(.package) | \(.status)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

view_successful_history() {
    print_header
    echo "Successful Installations:"
    echo ""
    
    history_list | jq -r '.[] | select(.status == "success") | "\(.timestamp) | \(.operation) | \(.package)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

view_failed_history() {
    print_header
    echo "Failed Installations:"
    echo ""
    
    history_list | jq -r '.[] | select(.status == "failed") | "\(.timestamp) | \(.operation) | \(.package) | \(.message)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

export_history_json() {
    local output_file="${HOME}/precoreshub_history_$(date +%Y%m%d_%H%M%S).json"
    
    if history_export "json" "$output_file"; then
        echo "? History exported to: $output_file"
    else
        echo "? Failed to export history"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

export_history_csv() {
    local output_file="${HOME}/precoreshub_history_$(date +%Y%m%d_%H%M%S).csv"
    
    if history_export "csv" "$output_file"; then
        echo "? History exported to: $output_file"
    else
        echo "? Failed to export history"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# SETTINGS MENU
################################################################################

################################################################################
# SETTINGS MENU
################################################################################

settings_menu() {
    while true; do
        print_header
        echo -e "${YELLOW}$(lang_get 'menu.settings.title')${NC}"
        echo ""
        
        local current_lang=$(config_get 'language' 2>/dev/null || echo 'en')
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt="> " --header="╔══════════════════════════════════════════════════════════╗
║                    SETTINGS                          ║
╚══════════════════════════════════════════════════════════╝" --color="fg:#ffffff,bg:#1e1e2e,hl:#cba6f7,fg+:#cdd6f4,bg+:#313244,hl+:#cba6f7,info:#cba6f7,prompt:#cba6f7,pointer:#cba6f7,marker:#a6e3a1,spinner:#f5e0dc,header:#cba6f7"
[01]  $(lang_get 'menu.settings.language') (Current: $current_lang)
[02]  $(lang_get 'menu.settings.cache_management')
[03]  $(lang_get 'menu.settings.reset')
[00]  $(lang_get 'menu.settings.back')
EOF
)
        
        case "$choice" in
            "[01]"*) change_language ;;
            "[02]"*) manage_cache ;;
            "[03]"*) reset_configuration ;;
            "[00]"*) return 0 ;;
            "") return 0 ;;
        esac
    done
}

# Change language
change_language() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.settings.language')${NC}"
    echo ""
    
    local choice=$(cat <<EOF | fzf --ansi --reverse --height=40% --border=rounded --prompt="> " --header="Select Language / Chn Ngn Ng" --color="fg:#ffffff,bg:#1e1e2e,hl:#cba6f7,fg+:#cdd6f4,bg+:#313244,hl+:#cba6f7,info:#cba6f7,prompt:#cba6f7,pointer:#cba6f7,marker:#a6e3a1,spinner:#f5e0dc,header:#cba6f7"
[01]  English
[02]  Ting Vit (Vietnamese)
EOF
)
    
    case "$choice" in
        "[01]"*)
            config_set "language" "en"
            lang_set "en"
            CURRENT_LANG="en"
            echo -e "${GREEN}[SUCCESS]${NC} Language changed to English"
            ;;
        "[02]"*)
            config_set "language" "vi"
            lang_set "vi"
            CURRENT_LANG="vi"
            echo -e "${GREEN}[SUCCESS]${NC}  chuyn sang Ting Vit"
            ;;
        "")
            return
            ;;
    esac
    
    echo ""
    read -p "Press Enter to continue..."
}

# Manage cache
manage_cache() {
    clear
    echo -e "${CYAN}$(lang_get 'menu.settings.cache_management')${NC}"
    echo ""
    
    local cache_size=$(du -sh ~/.cache/precoreshub 2>/dev/null | cut -f1 || echo "0")
    echo "$(lang_get 'messages.cache_size' 2>/dev/null || echo 'Cache size'): $cache_size"
    echo ""
    
    if confirm_dialog "$(lang_get 'messages.confirm_clear_cache' 2>/dev/null || echo 'Clear cache?')"; then
        cache_clear
        echo -e "${GREEN}[SUCCESS]${NC} $(lang_get 'messages.cache_cleared' 2>/dev/null || echo 'Cache cleared!')"
    else
        echo -e "${BLUE}[INFO]${NC} $(lang_get 'messages.cancelled' 2>/dev/null || echo 'Operation cancelled')"
    fi
    
    echo ""
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..."
}

# Reset configuration
reset_configuration() {
    clear
    echo -e "${YELLOW}$(lang_get 'menu.settings.reset')${NC}"
    echo ""
    
    if confirm_dialog "$(lang_get 'messages.confirm_reset_config' 2>/dev/null || echo 'Reset all settings to defaults?')" "$(lang_get 'messages.warning_reset_config' 2>/dev/null || echo 'This will reset all settings to defaults!')"; then
        config_reset
        echo -e "${GREEN}[SUCCESS]${NC} $(lang_get 'messages.config_reset' 2>/dev/null || echo 'Configuration reset to defaults!')"
    else
        echo -e "${BLUE}[INFO]${NC} $(lang_get 'messages.cancelled' 2>/dev/null || echo 'Operation cancelled')"
    fi
    
    echo ""
    read -p "$(lang_get 'messages.continue' 2>/dev/null || echo 'Press Enter to continue')..."
}

# View configuration
view_configuration() {
    print_header
    echo "Current Configuration:"
    echo ""
    
    cat "${HOME}/.config/precoreshub/config.json" | jq '.'
    
    echo ""
    read -p "Press Enter to continue..."
}

# Reset configuration (duplicate - old style)
reset_configuration_old() {
    print_header
    echo "Reset Configuration"
    echo ""
    
    if confirm_dialog "$(lang_get 'messages.confirm_reset_config' 2>/dev/null || echo 'Reset all settings to defaults?')" "$(lang_get 'messages.warning_reset_config' 2>/dev/null || echo 'This will reset all settings to defaults!')"; then
        config_reset
        echo " $(lang_get 'messages.config_reset' 2>/dev/null || echo 'Configuration reset to defaults')"
    else
        echo "$(lang_get 'messages.cancelled' 2>/dev/null || echo 'Cancelled')"
    fi
    
    sleep 2
}

# Clear cache
clear_cache_menu() {
    print_header
    echo "Clear Cache"
    echo ""
    
    if confirm_dialog "$(lang_get 'messages.confirm_clear_cache' 2>/dev/null || echo 'Clear all cached data?')"; then
        rm -rf "${HOME}/.cache/precoreshub/"*
        cache_init
        echo " $(lang_get 'messages.cache_cleared' 2>/dev/null || echo 'Cache cleared')"
    else
        echo "$(lang_get 'messages.cancelled' 2>/dev/null || echo 'Cancelled')"
    fi
    
    sleep 2
}

# View logs
view_logs_menu() {
    print_header
    echo "Application Logs:"
    echo ""
    
    if [[ -f "${HOME}/.cache/precoreshub/logs/precoreshub.log" ]]; then
        tail -n 50 "${HOME}/.cache/precoreshub/logs/precoreshub.log"
    else
        echo "No logs available"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# MAIN EXECUTION
################################################################################

# Main entry point
main() {
    # Check dependencies first
    check_dependencies
    
    # Initialize all systems
    initialize_systems
    
    # Show main menu
    main_menu
}

# Run main function
main "$@"
