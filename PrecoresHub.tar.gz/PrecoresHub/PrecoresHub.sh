#!/bin/bash
################################################################################
# PrecoresHub v5.1.0
# 
# Unified Control Center for Linux - Modular architecture with plugin system
# 
# Features:
# - QuickInstall (categorized app installer with multi-select & preview)
# - QuickFix (system repair with real implementations)
# - SystemManager (live monitoring & dashboard)
# - Plugin System, Favorites, History, Settings
# - Multi-language (EN/VI), Catppuccin Mocha theme
################################################################################

VERSION="5.1.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Catppuccin Mocha Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

# Extended 256-color palette
C_ROSEWATER='\033[38;5;224m'
C_FLAMINGO='\033[38;5;210m'
C_PINK='\033[38;5;212m'
C_MAUVE='\033[38;5;183m'
C_MAROON='\033[38;5;131m'
C_PEACH='\033[38;5;209m'
C_TEAL='\033[38;5;115m'
C_SKY='\033[38;5;117m'
C_SAPPHIRE='\033[38;5;75m'
C_LAVENDER='\033[38;5;183m'
C_SURFACE0='\033[38;5;236m'
C_OVERLAY0='\033[38;5;243m'
C_TEXT='\033[38;5;255m'

################################################################################
# LIBRARY LOADING
################################################################################

source "${SCRIPT_DIR}/lib/core.sh" || { echo "ERROR: Failed to load core library"; exit 1; }
source "${SCRIPT_DIR}/lib/config.sh" || { log_error "Failed to load config library"; exit 1; }
source "${SCRIPT_DIR}/lib/distro.sh" || { log_error "Failed to load distro library"; exit 1; }
source "${SCRIPT_DIR}/lib/package_manager.sh" || { log_error "Failed to load package manager library"; exit 1; }
source "${SCRIPT_DIR}/lib/progress.sh" || { log_error "Failed to load progress library"; exit 1; }
source "${SCRIPT_DIR}/lib/cache.sh" || { log_error "Failed to load cache library"; exit 1; }
source "${SCRIPT_DIR}/lib/history.sh" || { log_error "Failed to load history library"; exit 1; }
source "${SCRIPT_DIR}/lib/favorites.sh" || { log_error "Failed to load favorites library"; exit 1; }
source "${SCRIPT_DIR}/lib/localization.sh" || { log_error "Failed to load localization library"; exit 1; }
source "${SCRIPT_DIR}/lib/error.sh" || { log_error "Failed to load error library"; exit 1; }
source "${SCRIPT_DIR}/lib/plugin.sh" || { log_error "Failed to load plugin library"; exit 1; }
source "${SCRIPT_DIR}/lib/plugin_ui.sh" || { log_error "Failed to load plugin UI library"; exit 1; }

################################################################################
# INITIALIZATION
################################################################################

initialize_systems() {
    log_info "Initializing PrecoresHub v${VERSION}..."
    
    if [[ ! -f "${HOME}/.config/precoreshub/config.json" ]]; then
        log_info "First run detected, initializing configuration..."
        config_init
    else
        config_load
    fi
    
    lang_init
    local user_lang=$(config_get "language" 2>/dev/null || echo "en")
    lang_set "$user_lang"
    
    detect_distro
    log_info "Detected: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)"
    
    cache_init
    _history_init
    _favorites_init
    plugin_init
    plugin_load "example" 2>/dev/null && plugin_enable "example" 2>/dev/null || true
    
    log_info "Initialization complete"
}

check_dependencies() {
    log_info "Checking dependencies..."
    local missing_deps=()
    command -v jq &>/dev/null || missing_deps+=("jq")
    command -v fzf &>/dev/null || missing_deps+=("fzf")
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        log_error "Missing dependencies: ${missing_deps[*]}"
        echo ""
        echo "Please install: ${missing_deps[*]}"
        if confirm_dialog "Install dependencies now?"; then
            for dep in "${missing_deps[@]}"; do
                pkg_install "$dep"
            done
        else
            exit 1
        fi
    fi
    log_info "All dependencies satisfied"
}

################################################################################
# FZF THEME & HELPERS
################################################################################

# Catppuccin Mocha fzf color scheme
FZF_COLORS="fg:#cdd6f4,bg:#1e1e2e,hl:#f38ba8,fg+:#cdd6f4,bg+:#313244,hl+:#f38ba8,info:#cba6f7,prompt:#89b4fa,pointer:#f38ba8,marker:#a6e3a1,spinner:#f5e0dc,header:#94e2d5,border:#6c7086"

# Confirmation dialog
confirm_dialog() {
    local question="$1"
    local warning="${2:-}"
    local header="  CONFIRMATION"
    [[ -n "$warning" ]] && header="$header | $warning"
    
    local choice=$(printf '%s\n' "  Yes" "  No" | fzf \
        --ansi --reverse --height=12 --border=rounded \
        --prompt="$question > " --header="$header" \
        --color="$FZF_COLORS" --bind='ctrl-c:abort,esc:abort' || echo "")
    
    [[ "$choice" == *"Yes"* ]]
}

# Standard fzf menu
fzf_select() {
    local prompt="$1"
    local header="$2"
    shift 2
    printf '%s\n' "$@" | fzf \
        --ansi --reverse --height=80% --border=rounded --cycle \
        --prompt="$prompt > " --header="$header" \
        --color="$FZF_COLORS" --bind='ctrl-c:abort,esc:abort' || echo ""
}

################################################################################
# ASCII BANNER
################################################################################

show_banner() {
    clear
    echo -e "${C_SKY}"
    cat << 'BANNER'
    ____                                     __  __      __  
   / __ \________  _________  ________  ____/ / / /_  __/ /_ 
  / /_/ / ___/ _ \/ ___/ __ \/ ___/ _ \/ ___/ /_/ / / / __ \
 / ____/ /  /  __/ /__/ /_/ / /  /  __(__  ) __  / /_/ / /_/ /
/_/   /_/   \___/\___/\____/_/   \___/____/_/ /_/\__,_/_.___/ 
BANNER
    echo -e "${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..65})${NC}"
    echo ""
}

################################################################################
# MAIN MENU
################################################################################

main_menu() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=85% --border=rounded --prompt=" Menu > " --header="$(echo -e "${C_SKY} PRECORES HUB${NC} ${DIM}|${NC} Unified Control Center")" --color="$FZF_COLORS" --bind='ctrl-c:abort,esc:abort'
  QuickInstall      $(lang_get 'menu.main.quickinstall_desc' 2>/dev/null || echo '— Install apps & tools')
  QuickFix          $(lang_get 'menu.main.quickfix_desc' 2>/dev/null || echo '— Fix system issues')
  SystemManager     $(lang_get 'menu.main.systemmanager_desc' 2>/dev/null || echo '— Monitor & manage system')
  Favorites         $(lang_get 'menu.main.favorites_desc' 2>/dev/null || echo '— Bookmarked applications')
  History           $(lang_get 'menu.main.history_desc' 2>/dev/null || echo '— Installation records')
  Plugins           $(lang_get 'menu.main.plugins_desc' 2>/dev/null || echo '— Manage extensions')
  Settings          $(lang_get 'menu.main.settings_desc' 2>/dev/null || echo '— Configure PrecoresHub')
  Exit              $(lang_get 'menu.main.exit_desc' 2>/dev/null || echo '— Quit application')
EOF
)
        case "$choice" in
            *QuickInstall*) quickinstall_menu ;;
            *QuickFix*) quickfix_menu ;;
            *SystemManager*) systemmanager_menu ;;
            *Favorites*) favorites_menu_ui ;;
            *History*) history_menu_ui ;;
            *Plugins*) plugin_menu ;;
            *Settings*) settings_menu ;;
            *Exit*|"")
                echo -e "${C_TEAL}$(lang_get 'messages.goodbye' 2>/dev/null || echo 'Goodbye!')${NC}"
                exit 0 ;;
        esac
    done
}

################################################################################
# QUICKINSTALL - CATEGORIZED
################################################################################

quickinstall_menu() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=85% --border=rounded --prompt=" Install > " --header="$(echo -e "${C_PEACH} QUICKINSTALL${NC} — Select a category or action")" --color="$FZF_COLORS"
  Development       — Docker, Git, VS Code, Node.js, Python, Rust, Go
  Web Browsers      — Chrome, Firefox, Chromium
  Communication     — Discord, Telegram, Slack, Zoom, Teams, Skype
  Multimedia        — VLC, OBS, Spotify, Audacity, Kdenlive, Blender
  Productivity      — LibreOffice, Thunderbird, Postman, DBeaver
  System Utilities  — Timeshift, GParted, Flameshot, BleachBit, Stacer
  Multi-Select      — Pick multiple apps to install at once
  Search Package    — Search repos for any package
  Update System     — Full system update & upgrade
  Back
EOF
)
        case "$choice" in
            *Development*) install_category_dev ;;
            *"Web Browsers"*) install_category_browsers ;;
            *Communication*) install_category_comm ;;
            *Multimedia*) install_category_media ;;
            *Productivity*) install_category_prod ;;
            *"System Utilities"*) install_category_sysutil ;;
            *Multi-Select*) install_multiselect ;;
            *"Search Package"*) package_search ;;
            *"Update System"*) update_system ;;
            *Back*|"") return 0 ;;
        esac
    done
}

# Category installer helper
_install_from_list() {
    local header="$1"
    shift
    local apps=("$@")
    
    local choice=$(printf '%s\n' "${apps[@]}" "Back" | fzf \
        --ansi --reverse --height=80% --border=rounded --cycle \
        --prompt=" Install > " --header="$header" \
        --color="$FZF_COLORS" \
        --preview='pkg={1}; pkg=$(echo "$pkg" | sed "s/^[[:space:]]*//" | cut -d" " -f1 | tr -d ""); echo "Package: $pkg"; echo ""; if command -v pacman &>/dev/null; then pacman -Si "$pkg" 2>/dev/null | head -20 || echo "Use QuickInstall to get this package"; fi' \
        --preview-window=right:45%:wrap \
        || echo "")
    
    [[ -z "$choice" || "$choice" == "Back" ]] && return 0
    
    # Extract package name (first word after icon)
    local pkg_name=$(echo "$choice" | sed 's/^[[:space:]]*//' | awk '{print $1}')
    # Map display name to actual package
    case "$pkg_name" in
        docker|git|nodejs|python|rust|go|firefox|chromium|discord|telegram-desktop) ;;
        vlc|gimp|obs-studio|spotify|audacity|kdenlive|blender|inkscape) ;;
        libreoffice|thunderbird|postman|dbeaver|slack|zoom|teams|skype) ;;
        timeshift|gparted|flameshot|bleachbit|stacer|etcher) ;;
        code|vscode) pkg_name="code" ;;
        chrome|google-chrome) pkg_name="google-chrome" ;;
        *) ;;
    esac
    
    install_package "$pkg_name"
}

install_category_dev() {
    _install_from_list " DEVELOPMENT TOOLS" \
        " docker        — Container platform" \
        " git           — Version control" \
        " code          — Visual Studio Code" \
        " nodejs        — JavaScript runtime + npm" \
        " python        — Python 3 + pip" \
        " rust          — Systems programming (rustup)" \
        " go            — Google's Go language"
}

install_category_browsers() {
    _install_from_list " WEB BROWSERS" \
        " google-chrome — Google Chrome" \
        " chromium      — Open-source Chromium" \
        " firefox       — Mozilla Firefox"
}

install_category_comm() {
    _install_from_list " COMMUNICATION" \
        " discord            — Voice & text chat" \
        " telegram-desktop   — Telegram messenger" \
        " slack              — Team collaboration" \
        " zoom               — Video conferencing" \
        " teams              — Microsoft Teams" \
        " skype              — Video calls"
}

install_category_media() {
    _install_from_list " MULTIMEDIA" \
        " vlc         — Media player" \
        " obs-studio  — Screen recorder & streaming" \
        " spotify     — Music streaming" \
        " audacity    — Audio editor" \
        " kdenlive    — Video editor" \
        " blender     — 3D modeling & animation" \
        " gimp        — Image editor" \
        " inkscape    — Vector graphics"
}

install_category_prod() {
    _install_from_list " PRODUCTIVITY" \
        " libreoffice  — Office suite" \
        " thunderbird  — Email client" \
        " postman      — API testing tool" \
        " dbeaver      — Database management" \
        " insomnia     — REST/GraphQL client"
}

install_category_sysutil() {
    _install_from_list " SYSTEM UTILITIES" \
        " timeshift   — System snapshot & restore" \
        " gparted     — Disk partition manager" \
        " flameshot   — Screenshot tool" \
        " bleachbit   — System cleaner" \
        " stacer      — System optimizer" \
        " etcher      — USB/SD card writer"
}

# Multi-select install: pick many, install all
install_multiselect() {
    show_banner
    echo -e "  ${C_PEACH}Multi-Select Mode${NC} — Use TAB to select multiple apps, then ENTER"
    echo ""
    
    local all_apps=(
        "docker" "git" "code" "nodejs" "python" "rust" "go"
        "google-chrome" "chromium" "firefox"
        "discord" "telegram-desktop" "slack" "zoom"
        "vlc" "obs-studio" "spotify" "audacity" "kdenlive" "blender" "gimp" "inkscape"
        "libreoffice" "thunderbird" "postman" "dbeaver"
        "timeshift" "gparted" "flameshot" "bleachbit" "stacer"
    )
    
    local selected=$(printf '%s\n' "${all_apps[@]}" | fzf \
        --ansi --reverse --height=85% --border=rounded \
        --multi --cycle \
        --prompt=" Select (TAB to pick) > " \
        --header="$(echo -e "${C_PEACH} MULTI-SELECT${NC} — TAB=select, ENTER=confirm, ESC=cancel")" \
        --color="$FZF_COLORS" \
        --bind='ctrl-a:select-all,ctrl-d:deselect-all' \
        || echo "")
    
    [[ -z "$selected" ]] && return 0
    
    local count=$(echo "$selected" | wc -l)
    echo ""
    echo -e "  ${C_SKY}Installing ${count} package(s)...${NC}"
    echo ""
    
    while IFS= read -r pkg; do
        [[ -z "$pkg" ]] && continue
        echo -e "  ${CYAN}▸${NC} Installing: ${BOLD}$pkg${NC}"
        if pkg_install "$pkg" 2>/dev/null; then
            history_record "install" "$pkg" "success" "Batch install"
            echo -e "    ${GREEN}✓${NC} $pkg installed"
        else
            history_record "install" "$pkg" "failure" "Batch install failed"
            echo -e "    ${RED}✗${NC} $pkg failed"
        fi
    done <<< "$selected"
    
    echo ""
    echo -e "  ${GREEN}Batch install complete!${NC}"
    read -p "  Press Enter to continue..."
}

# Install single package with UI feedback
install_package() {
    local pkg_name="$1"
    echo ""
    echo -e "  ${CYAN}▸${NC} Installing ${BOLD}$pkg_name${NC}..."
    echo ""
    
    if pkg_install "$pkg_name"; then
        history_record "install" "$pkg_name" "success" "Installed via QuickInstall"
        echo ""
        echo -e "  ${GREEN}✓ Success:${NC} $pkg_name installed"
    else
        history_record "install" "$pkg_name" "failure" "Installation failed"
        echo ""
        echo -e "  ${RED}✗ Failed:${NC} Could not install $pkg_name"
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

update_system() {
    show_banner
    echo -e "  ${CYAN}▸${NC} Updating system (${DETECTED_PKG_MANAGER})..."
    echo ""
    pkg_update
    echo ""
    echo -e "  ${GREEN}✓${NC} System updated!"
    read -p "  Press Enter to continue..."
}

package_search() {
    show_banner
    echo -e "  ${C_SKY}Package Search${NC}"
    echo ""
    read -p "  Enter package name: " search_term
    [[ -z "$search_term" ]] && return
    
    echo ""
    echo -e "  ${CYAN}▸${NC} Searching for '$search_term'..."
    echo ""
    pkg_search "$search_term" 2>&1 | head -30
    echo ""
    read -p "  Press Enter to continue..."
}

################################################################################
# QUICKFIX - REAL IMPLEMENTATIONS
################################################################################

quickfix_menu() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=85% --border=rounded --prompt=" Fix > " --header="$(echo -e "${C_FLAMINGO} QUICKFIX${NC} — System Repair & Maintenance")" --color="$FZF_COLORS"
  Fix Auto-Login       — Configure LightDM auto-login
  Fix ZRAM             — Setup compressed swap in RAM
  Fix Firewall         — Configure UFW firewall rules
  Fix Network          — Reset NetworkManager & DNS
  Fix Broken Packages  — Repair package database
  Fix Permissions      — Reset home directory permissions
  System Health Check  — Comprehensive diagnostics
  Full Maintenance     — Update + clean + optimize
  Back
EOF
)
        case "$choice" in
            *"Fix Auto-Login"*) fix_autologin ;;
            *"Fix ZRAM"*) fix_zram ;;
            *"Fix Firewall"*) fix_firewall ;;
            *"Fix Network"*) fix_network ;;
            *"Fix Broken"*) fix_broken_packages ;;
            *"Fix Permissions"*) fix_permissions ;;
            *"System Health"*) check_system_health ;;
            *"Full Maintenance"*) full_maintenance ;;
            *Back*|"") return 0 ;;
        esac
    done
}

fix_autologin() {
    show_banner
    echo -e "  ${C_FLAMINGO}Fix Auto-Login${NC}"
    echo ""
    
    local current_user=$(whoami)
    
    if [[ ! -f /etc/lightdm/lightdm.conf ]] && [[ ! -d /etc/lightdm/lightdm.conf.d ]]; then
        echo -e "  ${YELLOW}!${NC} LightDM not found. Skipping."
        read -p "  Press Enter to continue..."
        return
    fi
    
    echo -e "  ${CYAN}▸${NC} Configuring auto-login for user: ${BOLD}$current_user${NC}"
    sudo mkdir -p /etc/lightdm/lightdm.conf.d
    sudo tee /etc/lightdm/lightdm.conf.d/50-autologin.conf > /dev/null <<EOF
[Seat:*]
autologin-user=$current_user
autologin-user-timeout=0
EOF
    
    # Ensure autologin group
    sudo groupadd -r autologin 2>/dev/null || true
    sudo gpasswd -a "$current_user" autologin 2>/dev/null
    
    echo -e "  ${GREEN}✓${NC} Auto-login configured for $current_user"
    echo ""
    read -p "  Press Enter to continue..."
}

fix_zram() {
    show_banner
    echo -e "  ${C_FLAMINGO}Fix ZRAM (Compressed Swap)${NC}"
    echo ""
    
    # Check if zram-generator is installed
    if ! command -v zramctl &>/dev/null && [[ ! -f /usr/lib/systemd/system-generators/zram-generator ]]; then
        echo -e "  ${CYAN}▸${NC} Installing zram-generator..."
        pkg_install "zram-generator" 2>/dev/null || pkg_install "zram-tools" 2>/dev/null
    fi
    
    echo -e "  ${CYAN}▸${NC} Configuring ZRAM..."
    sudo mkdir -p /etc/systemd
    sudo tee /etc/systemd/zram-generator.conf > /dev/null <<EOF
[zram0]
zram-size = ram / 2
compression-algorithm = zstd
swap-priority = 100
EOF
    
    echo -e "  ${CYAN}▸${NC} Enabling ZRAM..."
    sudo systemctl daemon-reload 2>/dev/null
    sudo systemctl restart systemd-zram-setup@zram0.service 2>/dev/null || true
    
    echo ""
    echo -e "  ${GREEN}✓${NC} ZRAM configured (50% of RAM, zstd compression)"
    zramctl 2>/dev/null && echo ""
    read -p "  Press Enter to continue..."
}

fix_firewall() {
    show_banner
    echo -e "  ${C_FLAMINGO}Fix Firewall (UFW)${NC}"
    echo ""
    
    if ! command -v ufw &>/dev/null; then
        echo -e "  ${CYAN}▸${NC} Installing UFW..."
        pkg_install "ufw"
    fi
    
    echo -e "  ${CYAN}▸${NC} Configuring firewall rules..."
    sudo ufw default deny incoming 2>/dev/null
    sudo ufw default allow outgoing 2>/dev/null
    sudo ufw allow ssh 2>/dev/null
    sudo ufw --force enable 2>/dev/null
    sudo systemctl enable ufw 2>/dev/null
    
    echo ""
    echo -e "  ${GREEN}✓${NC} Firewall configured:"
    echo -e "    • Incoming: ${RED}DENY${NC} (default)"
    echo -e "    • Outgoing: ${GREEN}ALLOW${NC} (default)"
    echo -e "    • SSH:      ${GREEN}ALLOW${NC}"
    echo ""
    sudo ufw status 2>/dev/null | head -10
    echo ""
    read -p "  Press Enter to continue..."
}

fix_network() {
    show_banner
    echo -e "  ${C_FLAMINGO}Fix Network${NC}"
    echo ""
    
    echo -e "  ${CYAN}▸${NC} Restarting NetworkManager..."
    sudo systemctl restart NetworkManager 2>/dev/null || \
        sudo systemctl restart networking 2>/dev/null || \
        sudo rc-service networking restart 2>/dev/null
    
    echo -e "  ${CYAN}▸${NC} Flushing DNS cache..."
    sudo systemd-resolve --flush-caches 2>/dev/null || \
        sudo resolvectl flush-caches 2>/dev/null || true
    
    echo -e "  ${CYAN}▸${NC} Resetting resolv.conf..."
    if [[ -L /etc/resolv.conf ]]; then
        echo -e "    ${DIM}(managed by systemd-resolved)${NC}"
    else
        sudo tee /etc/resolv.conf > /dev/null <<EOF
nameserver 1.1.1.1
nameserver 8.8.8.8
EOF
    fi
    
    echo ""
    sleep 2
    if ping -c 1 -W 3 1.1.1.1 &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Network connectivity: OK"
    else
        echo -e "  ${RED}✗${NC} Network connectivity: FAILED"
        echo -e "    Check: ip link / nmcli device status"
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

fix_broken_packages() {
    show_banner
    echo -e "  ${C_FLAMINGO}Fix Broken Packages${NC}"
    echo ""
    
    case "$DETECTED_PKG_MANAGER" in
        pacman)
            echo -e "  ${CYAN}▸${NC} Syncing databases..."
            sudo pacman -Syy
            echo -e "  ${CYAN}▸${NC} Checking for conflicts..."
            sudo pacman -Dk 2>/dev/null
            echo -e "  ${CYAN}▸${NC} Removing orphans..."
            local orphans=$(pacman -Qtdq 2>/dev/null)
            if [[ -n "$orphans" ]]; then
                echo "$orphans" | sudo pacman -Rns --noconfirm - 2>/dev/null || true
            fi
            ;;
        apt|apt-get)
            echo -e "  ${CYAN}▸${NC} Fixing broken installs..."
            sudo apt --fix-broken install -y
            sudo dpkg --configure -a
            sudo apt autoremove -y
            ;;
        dnf)
            echo -e "  ${CYAN}▸${NC} Checking for problems..."
            sudo dnf check
            sudo dnf autoremove -y
            ;;
        *)
            echo -e "  ${YELLOW}!${NC} Repair not implemented for $DETECTED_PKG_MANAGER"
            ;;
    esac
    
    echo ""
    echo -e "  ${GREEN}✓${NC} Package database repaired"
    read -p "  Press Enter to continue..."
}

fix_permissions() {
    show_banner
    echo -e "  ${C_FLAMINGO}Fix Home Directory Permissions${NC}"
    echo ""
    
    local home_dir="$HOME"
    echo -e "  ${CYAN}▸${NC} Resetting ownership of $home_dir..."
    sudo chown -R "$(whoami):$(whoami)" "$home_dir"
    
    echo -e "  ${CYAN}▸${NC} Setting directory permissions to 755..."
    find "$home_dir" -type d -exec chmod 755 {} \; 2>/dev/null
    
    echo -e "  ${CYAN}▸${NC} Setting file permissions to 644..."
    find "$home_dir" -type f -exec chmod 644 {} \; 2>/dev/null
    
    echo -e "  ${CYAN}▸${NC} Restoring SSH key permissions..."
    if [[ -d "$home_dir/.ssh" ]]; then
        chmod 700 "$home_dir/.ssh"
        chmod 600 "$home_dir/.ssh/"* 2>/dev/null || true
        chmod 644 "$home_dir/.ssh/"*.pub 2>/dev/null || true
    fi
    
    echo ""
    echo -e "  ${GREEN}✓${NC} Permissions reset"
    read -p "  Press Enter to continue..."
}

check_system_health() {
    show_banner
    echo -e "  ${C_FLAMINGO}System Health Check${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..50})${NC}"
    echo ""
    
    # Disk usage
    local root_usage=$(df / --output=pcent 2>/dev/null | tail -1 | tr -d ' %')
    if [[ "$root_usage" -gt 90 ]]; then
        echo -e "  ${RED}✗${NC} Disk (/)    : ${root_usage}% used — CRITICAL"
    elif [[ "$root_usage" -gt 75 ]]; then
        echo -e "  ${YELLOW}!${NC} Disk (/)    : ${root_usage}% used — WARNING"
    else
        echo -e "  ${GREEN}✓${NC} Disk (/)    : ${root_usage}% used"
    fi
    
    # RAM usage
    local mem_total=$(free -m | awk '/Mem:/{print $2}')
    local mem_used=$(free -m | awk '/Mem:/{print $3}')
    local mem_pct=$((mem_used * 100 / mem_total))
    if [[ "$mem_pct" -gt 90 ]]; then
        echo -e "  ${RED}✗${NC} Memory      : ${mem_used}M / ${mem_total}M (${mem_pct}%) — HIGH"
    else
        echo -e "  ${GREEN}✓${NC} Memory      : ${mem_used}M / ${mem_total}M (${mem_pct}%)"
    fi
    
    # ZRAM / Swap
    local swap_total=$(free -m | awk '/Swap:/{print $2}')
    if [[ "$swap_total" -gt 0 ]]; then
        echo -e "  ${GREEN}✓${NC} Swap/ZRAM   : ${swap_total}M available"
    else
        echo -e "  ${YELLOW}!${NC} Swap/ZRAM   : None configured"
    fi
    
    # Load average
    local load=$(cat /proc/loadavg | awk '{print $1}')
    local cores=$(nproc 2>/dev/null || echo 1)
    echo -e "  ${GREEN}✓${NC} Load avg    : $load (${cores} cores)"
    
    # Uptime
    echo -e "  ${GREEN}✓${NC} Uptime      : $(uptime -p 2>/dev/null || uptime | awk -F'up ' '{print $2}' | cut -d, -f1-2)"
    
    # Network
    if ping -c 1 -W 2 1.1.1.1 &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Network     : Connected"
    else
        echo -e "  ${RED}✗${NC} Network     : Disconnected"
    fi
    
    # Failed services
    local failed_count=$(systemctl --failed --no-legend 2>/dev/null | wc -l)
    if [[ "$failed_count" -gt 0 ]]; then
        echo -e "  ${RED}✗${NC} Services    : $failed_count failed"
        systemctl --failed --no-legend 2>/dev/null | head -5 | sed 's/^/      /'
    else
        echo -e "  ${GREEN}✓${NC} Services    : All OK"
    fi
    
    # Package updates
    local updates=""
    case "$DETECTED_PKG_MANAGER" in
        pacman) updates=$(pacman -Qu 2>/dev/null | wc -l) ;;
        apt|apt-get) updates=$(apt list --upgradable 2>/dev/null | grep -c upgradable) ;;
        dnf) updates=$(dnf check-update --quiet 2>/dev/null | wc -l) ;;
    esac
    if [[ -n "$updates" && "$updates" -gt 0 ]]; then
        echo -e "  ${YELLOW}!${NC} Updates     : $updates package(s) available"
    else
        echo -e "  ${GREEN}✓${NC} Updates     : System up-to-date"
    fi
    
    echo ""
    read -p "  Press Enter to continue..."
}

full_maintenance() {
    show_banner
    echo -e "  ${C_FLAMINGO}Full System Maintenance${NC}"
    echo ""
    
    echo -e "  ${CYAN}[1/4]${NC} Updating system..."
    pkg_update 2>/dev/null
    echo -e "  ${GREEN}  ✓${NC} Updated"
    
    echo -e "  ${CYAN}[2/4]${NC} Cleaning package cache..."
    pkg_clean 2>/dev/null
    echo -e "  ${GREEN}  ✓${NC} Cleaned"
    
    echo -e "  ${CYAN}[3/4]${NC} Removing orphan packages..."
    case "$DETECTED_PKG_MANAGER" in
        pacman)
            local orphans=$(pacman -Qtdq 2>/dev/null)
            [[ -n "$orphans" ]] && echo "$orphans" | sudo pacman -Rns --noconfirm - 2>/dev/null || true
            ;;
        apt|apt-get) sudo apt autoremove -y 2>/dev/null ;;
        dnf) sudo dnf autoremove -y 2>/dev/null ;;
    esac
    echo -e "  ${GREEN}  ✓${NC} Orphans removed"
    
    echo -e "  ${CYAN}[4/4]${NC} Cleaning user cache..."
    local cache_before=$(du -sm ~/.cache 2>/dev/null | cut -f1)
    find ~/.cache -type f -atime +30 -delete 2>/dev/null || true
    local cache_after=$(du -sm ~/.cache 2>/dev/null | cut -f1)
    echo -e "  ${GREEN}  ✓${NC} Freed $((cache_before - cache_after))MB from cache"
    
    echo ""
    echo -e "  ${GREEN}Full maintenance complete!${NC}"
    read -p "  Press Enter to continue..."
}

################################################################################
# SYSTEMMANAGER - RICH DASHBOARD
################################################################################

systemmanager_menu() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=85% --border=rounded --prompt=" System > " --header="$(echo -e "${C_TEAL} SYSTEMMANAGER${NC} — Monitoring & Control")" --color="$FZF_COLORS"
  System Dashboard    — Quick overview (fastfetch)
  Disk Usage          — Partition usage & mount points
  Memory & Swap       — RAM usage with breakdown
  CPU Information     — Processor details & load
  Network Interfaces  — IP addresses & connections
  Active Services     — Running systemd services
  Top Processes       — Sorted by CPU/RAM usage
  Manage Service      — Start/stop/restart a service
  Back
EOF
)
        case "$choice" in
            *Dashboard*) show_dashboard ;;
            *"Disk Usage"*) show_disk_usage ;;
            *"Memory"*) show_memory_usage ;;
            *"CPU"*) show_cpu_info ;;
            *"Network"*) show_network_info ;;
            *"Active Services"*) show_services ;;
            *"Top Processes"*) show_processes ;;
            *"Manage Service"*) manage_service ;;
            *Back*|"") return 0 ;;
        esac
    done
}

show_dashboard() {
    clear
    if command -v fastfetch &>/dev/null; then
        fastfetch
    elif command -v neofetch &>/dev/null; then
        neofetch
    else
        echo -e "  ${C_SKY}System Dashboard${NC}"
        echo ""
        echo "  Hostname    : $(hostname)"
        echo "  Kernel      : $(uname -r)"
        echo "  Arch        : $(uname -m)"
        echo "  Distro      : $DETECTED_DISTRO_NAME"
        echo "  Uptime      : $(uptime -p 2>/dev/null || uptime)"
        echo "  Shell       : $SHELL"
        echo "  CPU         : $(lscpu 2>/dev/null | grep 'Model name' | sed 's/.*:\s*//')"
        echo "  Memory      : $(free -h | awk '/Mem:/{printf "%s / %s", $3, $2}')"
        echo "  Disk (/)    : $(df -h / | awk 'NR==2{printf "%s / %s (%s)", $3, $2, $5}')"
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

show_disk_usage() {
    clear
    echo -e "  ${C_TEAL}Disk Usage${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..60})${NC}"
    echo ""
    df -h --output=source,size,used,avail,pcent,target 2>/dev/null | grep -E '^/dev|Filesystem' | \
        awk '{printf "  %-16s %6s %6s %6s %5s  %s\n", $1, $2, $3, $4, $5, $6}'
    echo ""
    echo -e "  ${DIM}Largest directories in /home:${NC}"
    du -sh ~/*/  2>/dev/null | sort -rh | head -5 | sed 's/^/  /'
    echo ""
    read -p "  Press Enter to continue..."
}

show_memory_usage() {
    clear
    echo -e "  ${C_TEAL}Memory Usage${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..60})${NC}"
    echo ""
    free -h
    echo ""
    echo -e "  ${DIM}Top 5 memory consumers:${NC}"
    ps aux --sort=-%mem 2>/dev/null | head -6 | awk '{printf "  %-8s %5s%%  %s\n", $1, $4, $11}' | tail -5
    echo ""
    if command -v zramctl &>/dev/null; then
        echo -e "  ${DIM}ZRAM devices:${NC}"
        zramctl 2>/dev/null | sed 's/^/  /'
        echo ""
    fi
    read -p "  Press Enter to continue..."
}

show_cpu_info() {
    clear
    echo -e "  ${C_TEAL}CPU Information${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..60})${NC}"
    echo ""
    echo "  Model    : $(lscpu 2>/dev/null | grep 'Model name' | sed 's/.*:\s*//')"
    echo "  Cores    : $(nproc) ($(lscpu 2>/dev/null | grep '^CPU(s):' | awk '{print $2}') threads)"
    echo "  Arch     : $(lscpu 2>/dev/null | grep 'Architecture' | awk '{print $2}')"
    echo "  Load     : $(cat /proc/loadavg | awk '{print $1, $2, $3}')"
    echo ""
    echo -e "  ${DIM}Top 5 CPU consumers:${NC}"
    ps aux --sort=-%cpu 2>/dev/null | head -6 | awk '{printf "  %-8s %5s%%  %s\n", $1, $3, $11}' | tail -5
    echo ""
    read -p "  Press Enter to continue..."
}

show_network_info() {
    clear
    echo -e "  ${C_TEAL}Network Interfaces${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..60})${NC}"
    echo ""
    ip -br addr 2>/dev/null | sed 's/^/  /' || ip addr | grep -E 'inet |link/' | sed 's/^/  /'
    echo ""
    echo -e "  ${DIM}Default gateway:${NC}"
    ip route | grep default | sed 's/^/  /'
    echo ""
    echo -e "  ${DIM}DNS servers:${NC}"
    grep nameserver /etc/resolv.conf 2>/dev/null | sed 's/^/  /'
    echo ""
    echo -e "  ${DIM}Listening ports:${NC}"
    ss -tuln 2>/dev/null | grep LISTEN | head -10 | awk '{printf "  %-6s %s\n", $1, $5}'
    echo ""
    read -p "  Press Enter to continue..."
}

show_services() {
    clear
    echo -e "  ${C_TEAL}Active Services${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..60})${NC}"
    echo ""
    systemctl list-units --type=service --state=running --no-pager --no-legend 2>/dev/null | \
        awk '{printf "  %-40s %s\n", $1, $4}' | head -25
    echo ""
    local failed=$(systemctl --failed --no-legend 2>/dev/null | wc -l)
    [[ "$failed" -gt 0 ]] && echo -e "  ${RED}Failed: $failed service(s)${NC}" && \
        systemctl --failed --no-legend 2>/dev/null | sed 's/^/    /'
    echo ""
    read -p "  Press Enter to continue..."
}

show_processes() {
    clear
    echo -e "  ${C_TEAL}Top Processes${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..60})${NC}"
    echo ""
    echo -e "  ${DIM}By CPU:${NC}"
    ps aux --sort=-%cpu 2>/dev/null | head -11 | awk 'NR==1{printf "  %-10s %5s %5s  %s\n","USER","CPU%","MEM%","COMMAND"} NR>1{printf "  %-10s %5s %5s  %s\n",$1,$3,$4,$11}' | head -11
    echo ""
    echo -e "  ${DIM}By Memory:${NC}"
    ps aux --sort=-%mem 2>/dev/null | head -6 | awk 'NR>1{printf "  %-10s %5s %5s  %s\n",$1,$3,$4,$11}'
    echo ""
    read -p "  Press Enter to continue..."
}

manage_service() {
    show_banner
    echo -e "  ${C_TEAL}Manage Service${NC}"
    echo ""
    read -p "  Enter service name (e.g. sshd, NetworkManager): " svc_name
    [[ -z "$svc_name" ]] && return
    
    echo ""
    echo -e "  Status of ${BOLD}$svc_name${NC}:"
    systemctl status "$svc_name" --no-pager 2>/dev/null | head -10 | sed 's/^/  /'
    echo ""
    
    local action=$(printf '%s\n' "restart" "start" "stop" "enable" "disable" "cancel" | fzf \
        --ansi --reverse --height=12 --border=rounded \
        --prompt=" Action for $svc_name > " --color="$FZF_COLORS" || echo "cancel")
    
    if [[ "$action" != "cancel" && -n "$action" ]]; then
        sudo systemctl "$action" "$svc_name" 2>/dev/null
        echo -e "  ${GREEN}✓${NC} $svc_name → $action"
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

################################################################################
# FAVORITES MENU
################################################################################

favorites_menu_ui() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt=" Favs > " --header="$(echo -e "${C_PEACH} FAVORITES${NC} — Quick Access Apps")" --color="$FZF_COLORS"
  View All Favorites
  Add to Favorites
  Remove from Favorites
  Install All Favorites
  Back
EOF
)
        case "$choice" in
            *"View All"*) view_favorites ;;
            *"Add"*) add_favorite ;;
            *"Remove"*) remove_favorite ;;
            *"Install All"*) install_all_favorites ;;
            *Back*|"") return 0 ;;
        esac
    done
}

view_favorites() {
    clear
    echo -e "  ${C_PEACH}Favorites${NC}"
    echo ""
    local favs=$(favorites_list 2>/dev/null)
    if [[ -z "$favs" ]]; then
        echo -e "  ${DIM}No favorites yet. Add apps from QuickInstall!${NC}"
    else
        echo "$favs" | sed 's/^/    ★ /'
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

add_favorite() {
    show_banner
    read -p "  Enter package name to add: " pkg_name
    [[ -z "$pkg_name" ]] && return
    if favorites_add "$pkg_name" 2>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Added '$pkg_name' to favorites"
    else
        echo -e "  ${RED}✗${NC} Failed to add"
    fi
    read -p "  Press Enter to continue..."
}

remove_favorite() {
    show_banner
    local favs=$(favorites_list 2>/dev/null)
    if [[ -z "$favs" ]]; then
        echo -e "  ${DIM}No favorites to remove.${NC}"
        read -p "  Press Enter to continue..."
        return
    fi
    
    local choice=$(echo "$favs" | fzf --ansi --reverse --height=50% --border=rounded \
        --prompt=" Remove > " --header="Select favorite to remove" --color="$FZF_COLORS" || echo "")
    [[ -z "$choice" ]] && return
    
    if favorites_remove "$choice" 2>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Removed '$choice'"
    fi
    read -p "  Press Enter to continue..."
}

install_all_favorites() {
    show_banner
    local favs=$(favorites_list 2>/dev/null)
    if [[ -z "$favs" ]]; then
        echo -e "  ${DIM}No favorites to install.${NC}"
        read -p "  Press Enter to continue..."
        return
    fi
    
    echo -e "  ${CYAN}▸${NC} Installing all favorites..."
    echo ""
    while IFS= read -r pkg; do
        [[ -z "$pkg" ]] && continue
        echo -e "  ${CYAN}▸${NC} $pkg"
        pkg_install "$pkg" 2>/dev/null && echo -e "    ${GREEN}✓${NC}" || echo -e "    ${RED}✗${NC}"
    done <<< "$favs"
    echo ""
    echo -e "  ${GREEN}Done!${NC}"
    read -p "  Press Enter to continue..."
}

################################################################################
# HISTORY MENU
################################################################################

history_menu_ui() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt=" History > " --header="$(echo -e "${C_TEAL} HISTORY${NC} — Installation Records")" --color="$FZF_COLORS"
  View All History
  View Recent (Last 10)
  View Successful Only
  View Failed Only
  Export History (JSON)
  Export History (CSV)
  Clear History
  Back
EOF
)
        case "$choice" in
            *"View All"*) _show_history "all" ;;
            *"Recent"*) _show_history "recent" ;;
            *"Successful"*) _show_history "success" ;;
            *"Failed"*) _show_history "failed" ;;
            *"JSON"*) _export_history "json" ;;
            *"CSV"*) _export_history "csv" ;;
            *"Clear"*) _clear_history ;;
            *Back*|"") return 0 ;;
        esac
    done
}

_show_history() {
    local filter="$1"
    clear
    echo -e "  ${C_TEAL}Installation History${NC} ($filter)"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..50})${NC}"
    echo ""
    
    local data=$(history_list 2>/dev/null)
    if [[ -z "$data" || "$data" == "null" ]]; then
        echo -e "  ${DIM}No history records.${NC}"
    else
        case "$filter" in
            all) echo "$data" | jq -r '.[] | "  \(.timestamp) | \(.operation) | \(.package) | \(.status)"' 2>/dev/null | tail -30 ;;
            recent) echo "$data" | jq -r '.[-10:] | .[] | "  \(.timestamp) | \(.package) | \(.status)"' 2>/dev/null ;;
            success) echo "$data" | jq -r '[.[] | select(.status=="success")] | .[] | "  \(.timestamp) | \(.package)"' 2>/dev/null | tail -20 ;;
            failed) echo "$data" | jq -r '[.[] | select(.status=="failure" or .status=="failed")] | .[] | "  \(.timestamp) | \(.package) | \(.message // "")"' 2>/dev/null | tail -20 ;;
        esac
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

_export_history() {
    local fmt="$1"
    local output="${HOME}/precoreshub_history_$(date +%Y%m%d_%H%M%S).${fmt}"
    if history_export "$fmt" "$output" 2>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Exported to: $output"
    else
        echo -e "  ${RED}✗${NC} Export failed"
    fi
    read -p "  Press Enter to continue..."
}

_clear_history() {
    if confirm_dialog "Clear ALL installation history?" "This cannot be undone!"; then
        history_clear 2>/dev/null
        echo -e "  ${GREEN}✓${NC} History cleared"
    else
        echo -e "  ${DIM}Cancelled${NC}"
    fi
    read -p "  Press Enter to continue..."
}

################################################################################
# PLUGIN MENU
################################################################################

plugin_menu() {
    while true; do
        show_banner
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt=" Plugins > " --header="$(echo -e "${C_MAUVE} PLUGINS${NC} — Extensions & Add-ons")" --color="$FZF_COLORS"
  List All Plugins
  Enable Plugin
  Disable Plugin
  View Plugin Details
  Execute Plugin Function
  Check Dependencies
  Refresh Plugin List
  Back
EOF
)
        case "$choice" in
            *"List All"*) plugin_ui_list_all ;;
            *"Enable"*) plugin_ui_enable ;;
            *"Disable"*) plugin_ui_disable ;;
            *"View Plugin"*) plugin_ui_details ;;
            *"Execute"*) plugin_ui_execute ;;
            *"Check"*) plugin_ui_check_deps ;;
            *"Refresh"*) plugin_ui_refresh ;;
            *Back*|"") return 0 ;;
        esac
    done
}

################################################################################
# SETTINGS MENU
################################################################################

settings_menu() {
    while true; do
        show_banner
        local current_lang=$(config_get 'language' 2>/dev/null || echo 'en')
        
        local choice=$(cat <<EOF | fzf --ansi --reverse --height=80% --border=rounded --prompt=" Settings > " --header="$(echo -e "${C_LAVENDER} SETTINGS${NC} — Configuration")" --color="$FZF_COLORS"
  Language             — Current: $current_lang
  Check for Updates    — Auto-update from GitHub
  Cache Management     — Clear cached data
  View Configuration   — Show current config
  View Logs            — Application logs
  About PrecoresHub    — Version & info
  Reset to Defaults    — Reset all settings
  Back
EOF
)
        case "$choice" in
            *Language*) change_language ;;
            *"Check for Updates"*) check_for_update ;;
            *"Cache"*) manage_cache ;;
            *"View Configuration"*) view_configuration ;;
            *"View Logs"*) view_logs ;;
            *"About"*) show_about ;;
            *"Reset"*) reset_configuration ;;
            *Back*|"") return 0 ;;
        esac
    done
}

change_language() {
    local choice=$(printf '%s\n' "  English" "  Tiếng Việt" | fzf \
        --ansi --reverse --height=12 --border=rounded \
        --prompt=" Language > " --header="Select Language / Chọn Ngôn Ngữ" \
        --color="$FZF_COLORS" || echo "")
    
    case "$choice" in
        *English*)
            config_set "language" "en"; lang_set "en"
            echo -e "  ${GREEN}✓${NC} Language → English" ;;
        *Việt*)
            config_set "language" "vi"; lang_set "vi"
            echo -e "  ${GREEN}✓${NC} Ngôn ngữ → Tiếng Việt" ;;
    esac
    sleep 1
}

manage_cache() {
    show_banner
    local cache_size=$(du -sh ~/.cache/precoreshub 2>/dev/null | cut -f1 || echo "0B")
    echo -e "  Cache size: ${BOLD}$cache_size${NC}"
    echo ""
    if confirm_dialog "Clear all cached data?"; then
        cache_clear 2>/dev/null
        rm -rf ~/.cache/precoreshub/* 2>/dev/null
        cache_init 2>/dev/null
        echo -e "  ${GREEN}✓${NC} Cache cleared"
    fi
    read -p "  Press Enter to continue..."
}

view_configuration() {
    clear
    echo -e "  ${C_LAVENDER}Current Configuration${NC}"
    echo ""
    if [[ -f "${HOME}/.config/precoreshub/config.json" ]]; then
        jq '.' "${HOME}/.config/precoreshub/config.json" 2>/dev/null | sed 's/^/  /'
    else
        echo "  No config file found."
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

view_logs() {
    clear
    echo -e "  ${C_LAVENDER}Application Logs (last 40 lines)${NC}"
    echo ""
    local logfile="${HOME}/.cache/precoreshub/logs/precoreshub.log"
    if [[ -f "$logfile" ]]; then
        tail -40 "$logfile" | sed 's/^/  /'
    else
        echo "  No logs available."
    fi
    echo ""
    read -p "  Press Enter to continue..."
}

show_about() {
    clear
    echo -e "${C_SKY}"
    cat << 'ABOUT'
    ____                                     __  __      __  
   / __ \________  _________  ________  ____/ / / /_  __/ /_ 
  / /_/ / ___/ _ \/ ___/ __ \/ ___/ _ \/ ___/ /_/ / / / __ \
 / ____/ /  /  __/ /__/ /_/ / /  /  __(__  / __  / /_/ / /_/ /
/_/   /_/   \___/\___/\____/_/   \___/____/_/ /_/\__,_/_.___/ 
ABOUT
    echo -e "${NC}"
    echo -e "  ${BOLD}Version:${NC}      $VERSION"
    echo -e "  ${BOLD}License:${NC}      MIT"
    echo -e "  ${BOLD}Author:${NC}       PrecoresHub Team"
    echo -e "  ${BOLD}Repository:${NC}   github.com/ZewK3/Precores-Software"
    echo ""
    echo -e "  ${BOLD}Features:${NC}"
    echo "    • 13 Linux distributions supported"
    echo "    • 11 package managers"
    echo "    • Plugin system for extensibility"
    echo "    • Multi-language (EN/VI)"
    echo "    • Installation history & rollback"
    echo "    • Favorites & bookmarks"
    echo "    • Multi-select batch install"
    echo "    • System health diagnostics"
    echo ""
    echo -e "  ${DIM}Made with care for the Linux community${NC}"
    echo ""
    read -p "  Press Enter to continue..."
}

reset_configuration() {
    if confirm_dialog "Reset ALL settings to defaults?" "This cannot be undone!"; then
        config_reset 2>/dev/null
        echo -e "  ${GREEN}✓${NC} Configuration reset to defaults"
    else
        echo -e "  ${DIM}Cancelled${NC}"
    fi
    sleep 1
}

################################################################################
# AUTO-UPDATE FROM GITHUB
################################################################################

GITHUB_USER="ZewK3"
GITHUB_REPO="Precores-Software"
GITHUB_BRANCH="main"
GITHUB_RAW="https://raw.githubusercontent.com/${GITHUB_USER}/${GITHUB_REPO}/${GITHUB_BRANCH}"

check_for_update() {
    show_banner
    echo -e "  ${C_SKY}Check for Updates${NC}"
    echo -e "  ${C_SURFACE0}$(printf '%.0s─' {1..50})${NC}"
    echo ""
    echo -e "  ${CYAN}▸${NC} Current version: ${BOLD}v${VERSION}${NC}"
    echo -e "  ${CYAN}▸${NC} Checking GitHub for latest version..."
    echo ""
    
    # Fetch remote version from PrecoresHub.sh on GitHub
    local remote_version
    remote_version=$(curl -sL --connect-timeout 10 --max-time 15 \
        "${GITHUB_RAW}/PrecoresHub/PrecoresHub.sh" 2>/dev/null | \
        grep -m1 '^VERSION=' | sed 's/VERSION="//;s/"//') || true
    
    if [[ -z "$remote_version" ]]; then
        echo -e "  ${RED}✗${NC} Could not reach GitHub. Check your network."
        echo ""
        read -p "  Press Enter to continue..."
        return
    fi
    
    echo -e "  ${CYAN}▸${NC} Latest version:  ${BOLD}v${remote_version}${NC}"
    echo ""
    
    if [[ "$VERSION" == "$remote_version" ]]; then
        echo -e "  ${GREEN}✓${NC} You are already on the latest version!"
        echo ""
        read -p "  Press Enter to continue..."
        return
    fi
    
    echo -e "  ${YELLOW}!${NC} Update available: ${DIM}v${VERSION}${NC} → ${GREEN}v${remote_version}${NC}"
    echo ""
    
    if ! confirm_dialog "Update PrecoresHub to v${remote_version}?"; then
        echo -e "  ${DIM}Update cancelled${NC}"
        read -p "  Press Enter to continue..."
        return
    fi
    
    echo ""
    echo -e "  ${CYAN}▸${NC} Downloading update..."
    
    local install_dir="/opt/precoreshub"
    local tmp_tar="/tmp/PrecoresHub_update.tar.gz"
    rm -f "$tmp_tar"
    
    if ! curl -sL --connect-timeout 30 --max-time 120 \
            -o "$tmp_tar" "${GITHUB_RAW}/PrecoresHub.tar.gz" 2>/dev/null; then
        echo -e "  ${RED}✗${NC} Download failed"
        rm -f "$tmp_tar"
        read -p "  Press Enter to continue..."
        return
    fi
    
    local dl_size
    dl_size=$(stat -c%s "$tmp_tar" 2>/dev/null || echo "0")
    if [[ "$dl_size" -lt 10000 ]]; then
        echo -e "  ${RED}✗${NC} Downloaded file too small (${dl_size} bytes)"
        rm -f "$tmp_tar"
        read -p "  Press Enter to continue..."
        return
    fi
    
    echo -e "  ${CYAN}▸${NC} Removing immutable flags..."
    sudo find "$install_dir" -type f -exec chattr -i {} \; 2>/dev/null || true
    
    echo -e "  ${CYAN}▸${NC} Extracting update..."
    local tmp_extract="/tmp/_precoreshub_update"
    rm -rf "$tmp_extract"
    mkdir -p "$tmp_extract"
    
    if tar -xzf "$tmp_tar" --strip-components=1 -C "$tmp_extract" 2>/dev/null; then
        # Backup config
        local config_backup="/tmp/_precoreshub_config_backup"
        cp -a "${HOME}/.config/precoreshub" "$config_backup" 2>/dev/null || true
        
        # Replace files
        sudo rm -rf "${install_dir:?}"/*
        sudo cp -a "$tmp_extract"/* "$install_dir/"
        
        # Fix permissions
        sudo chown -R root:root "$install_dir"
        sudo find "$install_dir" -type d -exec chmod 755 {} \;
        sudo find "$install_dir" -type f -exec chmod 644 {} \;
        sudo find "$install_dir" -type f -name '*.sh' -exec chmod 755 {} \;
        sudo find "$install_dir" -type f -exec chattr +i {} \; 2>/dev/null || true
        
        # Restore config
        cp -a "$config_backup"/* "${HOME}/.config/precoreshub/" 2>/dev/null || true
        rm -rf "$config_backup"
        
        echo ""
        echo -e "  ${GREEN}✓ Update successful!${NC} v${VERSION} → v${remote_version}"
        echo -e "  ${DIM}Restarting PrecoresHub...${NC}"
        sleep 2
        
        # Cleanup and restart
        rm -f "$tmp_tar"
        rm -rf "$tmp_extract"
        exec bash "$install_dir/PrecoresHub.sh" "$@"
    else
        # Try without --strip-components
        rm -rf "$tmp_extract"
        mkdir -p "$tmp_extract"
        tar -xzf "$tmp_tar" -C "$tmp_extract" 2>/dev/null
        local inner
        inner=$(ls "$tmp_extract" 2>/dev/null | head -1)
        if [[ -n "$inner" && -f "$tmp_extract/$inner/PrecoresHub.sh" ]]; then
            sudo rm -rf "${install_dir:?}"/*
            sudo cp -a "$tmp_extract/$inner"/* "$install_dir/"
            sudo chown -R root:root "$install_dir"
            sudo find "$install_dir" -type f -name '*.sh' -exec chmod 755 {} \;
            sudo find "$install_dir" -type f -exec chattr +i {} \; 2>/dev/null || true
            echo -e "  ${GREEN}✓ Update successful!${NC}"
            sleep 2
            rm -f "$tmp_tar"
            rm -rf "$tmp_extract"
            exec bash "$install_dir/PrecoresHub.sh" "$@"
        else
            echo -e "  ${RED}✗${NC} Extraction failed"
        fi
    fi
    
    rm -f "$tmp_tar"
    rm -rf "$tmp_extract"
    read -p "  Press Enter to continue..."
}

################################################################################
# MAIN EXECUTION
################################################################################

main() {
    check_dependencies
    initialize_systems
    main_menu
}

main "$@"
