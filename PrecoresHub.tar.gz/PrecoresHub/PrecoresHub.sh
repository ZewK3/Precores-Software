﻿#!/bin/bash
################################################################################
# PrecoresHub v5.0.0 - Unified Control Center
# 
# Enhanced version with modular architecture:
# - QuickInstall (App installer with favorites & history)
# - QuickFix (System repair)
# - SystemManager (Monitoring & updates)
# - Plugin System (Extensible functionality)
# - Multi-language support (English & Vietnamese)
# 
# New Features in v5.0.0:
# - Modular library system
# - Plugin architecture
# - Installation history & rollback
# - Favorites/bookmarks
# - Progress tracking
# - Caching system
# - Enhanced error handling
# - Localization (EN/VI)
# - 13 Linux distributions support
################################################################################

VERSION="5.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

################################################################################
# LIBRARY LOADING
################################################################################

# Source all library files
source "${SCRIPT_DIR}/lib/core.sh" || {
    echo "ERROR: Failed to load core library"
    exit 1
}

source "${SCRIPT_DIR}/lib/config.sh" || {
    log_error "Failed to load config library"
    exit 1
}

source "${SCRIPT_DIR}/lib/distro.sh" || {
    log_error "Failed to load distro library"
    exit 1
}

source "${SCRIPT_DIR}/lib/package_manager.sh" || {
    log_error "Failed to load package manager library"
    exit 1
}

source "${SCRIPT_DIR}/lib/progress.sh" || {
    log_error "Failed to load progress library"
    exit 1
}

source "${SCRIPT_DIR}/lib/cache.sh" || {
    log_error "Failed to load cache library"
    exit 1
}

source "${SCRIPT_DIR}/lib/history.sh" || {
    log_error "Failed to load history library"
    exit 1
}

source "${SCRIPT_DIR}/lib/favorites.sh" || {
    log_error "Failed to load favorites library"
    exit 1
}

source "${SCRIPT_DIR}/lib/localization.sh" || {
    log_error "Failed to load localization library"
    exit 1
}

source "${SCRIPT_DIR}/lib/error.sh" || {
    log_error "Failed to load error library"
    exit 1
}

source "${SCRIPT_DIR}/lib/plugin.sh" || {
    log_error "Failed to load plugin library"
    exit 1
}

source "${SCRIPT_DIR}/lib/plugin_ui.sh" || {
    log_error "Failed to load plugin UI library"
    exit 1
}

################################################################################
# INITIALIZATION
################################################################################

# Initialize all systems
initialize_systems() {
    log_info "Initializing PrecoresHub v${VERSION}..."
    
    # Initialize configuration
    if [[ ! -f "${HOME}/.config/precoreshub/config.json" ]]; then
        log_info "First run detected, initializing configuration..."
        config_init
    else
        config_load
    fi
    
    # Initialize localization
    lang_init
    local user_lang=$(config_get "language" 2>/dev/null || echo "en")
    lang_set "$user_lang"
    
    # Detect distribution
    detect_distro
    log_info "Detected: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)"
    
    # Initialize cache
    cache_init
    
    # Initialize history
    history_init
    
    # Initialize favorites
    favorites_init
    
    # Initialize plugin system
    plugin_init
    
    # Auto-enable example plugin if available
    if plugin_load "example" 2>/dev/null; then
        plugin_enable "example" 2>/dev/null || true
    fi
    
    log_info "Initialization complete"
}

# Check dependencies
check_dependencies() {
    log_info "Checking dependencies..."
    
    local missing_deps=()
    
    # Check for required commands
    if ! command -v jq &>/dev/null; then
        missing_deps+=("jq")
    fi
    
    if ! command -v fzf &>/dev/null; then
        missing_deps+=("fzf")
    fi
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        log_error "Missing dependencies: ${missing_deps[*]}"
        echo ""
        echo "Please install missing dependencies:"
        for dep in "${missing_deps[@]}"; do
            echo "  - $dep"
        done
        echo ""
        read -p "Install dependencies now? (y/n): " install_deps
        if [[ "$install_deps" == "y" ]]; then
            for dep in "${missing_deps[@]}"; do
                log_info "Installing $dep..."
                pkg_install "$dep"
            done
        else
            log_error "Cannot continue without dependencies"
            exit 1
        fi
    fi
    
    log_info "All dependencies satisfied"
}

################################################################################
# MAIN MENU
################################################################################

# Print header
print_header() {
    clear
    echo "================================================================"
    echo "           PrecoresHub v${VERSION} - Control Center"
    echo "================================================================"
    echo "System: $DETECTED_DISTRO_NAME ($DETECTED_PKG_MANAGER)"
    echo "Language: $(config_get 'language' 2>/dev/null || echo 'en')"
    echo ""
}

# Main menu
main_menu() {
    while true; do
        print_header
        
        echo "Main Menu:"
        echo ""
        echo "1. QuickInstall - Application Installer"
        echo "2. QuickFix - System Repair Tools"
        echo "3. SystemManager - System Monitoring"
        echo "4. Favorites - Manage Favorite Apps"
        echo "5. History - Installation History"
        echo "6. Plugin Manager - Manage Plugins"
        echo "7. Settings - Configuration"
        echo "0. Exit"
        echo ""
        
        # Show plugin menu items if any
        plugin_ui_show_menu_items
        
        read -p "Select option: " choice
        
        case "$choice" in
            1) quickinstall_menu ;;
            2) quickfix_menu ;;
            3) systemmanager_menu ;;
            4) favorites_menu_ui ;;
            5) history_menu_ui ;;
            6) plugin_menu ;;
            7) settings_menu ;;
            0) 
                log_info "Exiting PrecoresHub"
                echo "Goodbye!"
                exit 0
                ;;
            *)
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

################################################################################
# QUICKINSTALL MENU
################################################################################

quickinstall_menu() {
    while true; do
        print_header
        echo "QuickInstall - Application Installer"
        echo ""
        echo "1. Development Tools"
        echo "2. Web Browsers"
        echo "3. Media Players"
        echo "4. Office Suite"
        echo "5. System Utilities"
        echo "6. Search All Applications"
        echo "0. Back to Main Menu"
        echo ""
        
        read -p "Select category: " choice
        
        case "$choice" in
            1) install_dev_tools ;;
            2) install_browsers ;;
            3) install_media ;;
            4) install_office ;;
            5) install_utilities ;;
            6) search_applications ;;
            0) return 0 ;;
            *)
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

# Development Tools
install_dev_tools() {
    print_header
    echo "Development Tools"
    echo ""
    
    local apps=(
        "git:Version Control System"
        "vim:Text Editor"
        "code:Visual Studio Code"
        "docker:Container Platform"
        "nodejs:JavaScript Runtime"
        "python:Python Programming Language"
        "gcc:GNU Compiler Collection"
        "make:Build Automation Tool"
    )
    
    install_from_list "${apps[@]}"
}

# Web Browsers
install_browsers() {
    print_header
    echo "Web Browsers"
    echo ""
    
    local apps=(
        "firefox:Mozilla Firefox"
        "chromium:Chromium Browser"
        "brave:Brave Browser"
    )
    
    install_from_list "${apps[@]}"
}

# Media Players
install_media() {
    print_header
    echo "Media Players"
    echo ""
    
    local apps=(
        "vlc:VLC Media Player"
        "mpv:MPV Media Player"
        "spotify:Spotify Music"
    )
    
    install_from_list "${apps[@]}"
}

# Office Suite
install_office() {
    print_header
    echo "Office Suite"
    echo ""
    
    local apps=(
        "libreoffice:LibreOffice Suite"
        "gimp:GIMP Image Editor"
        "inkscape:Inkscape Vector Graphics"
    )
    
    install_from_list "${apps[@]}"
}

# System Utilities
install_utilities() {
    print_header
    echo "System Utilities"
    echo ""
    
    local apps=(
        "htop:System Monitor"
        "tmux:Terminal Multiplexer"
        "curl:Data Transfer Tool"
        "wget:File Downloader"
        "zip:Compression Tool"
        "unzip:Decompression Tool"
    )
    
    install_from_list "${apps[@]}"
}

# Install from list using fzf
install_from_list() {
    local apps=("$@")
    
    while true; do
        # Format for fzf
        local formatted=()
        for app in "${apps[@]}"; do
            local name="${app%%:*}"
            local desc="${app#*:}"
            
            # Check if installed
            local status="[ ]"
            if pkg_is_installed "$name" 2>/dev/null; then
                status="[✓]"
            fi
            
            # Check if favorite
            local fav=""
            if favorites_is_favorite "$name" 2>/dev/null; then
                fav="★ "
            fi
            
            formatted+=("${fav}${status} ${name} - ${desc}")
        done
        
        # Use fzf for selection
        local selected=$(printf '%s\n' "${formatted[@]}" | fzf --prompt="Select app (Tab=multi, Ctrl-F=favorites, Enter=install, Esc=back): " --multi --height=60% --bind='ctrl-f:execute-silent(echo {})' --expect=ctrl-f)
        
        if [[ -z "$selected" ]]; then
            return 0
        fi
        
        # Check if Ctrl-F was pressed (favorites toggle)
        local key=$(echo "$selected" | head -n1)
        local items=$(echo "$selected" | tail -n +2)
        
        if [[ "$key" == "ctrl-f" ]]; then
            # Toggle favorites for selected items
            while IFS= read -r line; do
                if [[ -z "$line" ]]; then
                    continue
                fi
                
                # Extract package name
                local pkg_name=$(echo "$line" | sed 's/^[★ ]*\[[✓ ]*\] //' | awk '{print $1}')
                
                # Toggle favorite
                if favorites_is_favorite "$pkg_name" 2>/dev/null; then
                    favorites_remove "$pkg_name"
                    echo "Removed $pkg_name from favorites"
                else
                    favorites_add "$pkg_name"
                    echo "Added $pkg_name to favorites"
                fi
            done <<< "$items"
            
            sleep 1
            continue  # Refresh menu
        fi
        
        # Install selected apps
        while IFS= read -r line; do
            if [[ -z "$line" ]]; then
                continue
            fi
            
            # Extract package name
            local pkg_name=$(echo "$line" | sed 's/^[★ ]*\[[✓ ]*\] //' | awk '{print $1}')
            
            echo ""
            echo "Installing $pkg_name..."
            
            # Install package (progress tracking is handled internally)
            if pkg_install "$pkg_name"; then
                # Record in history
                history_record "install" "$pkg_name" "success" "Installed via QuickInstall"
                
                echo "✓ $pkg_name installed successfully!"
                
                # Ask if user wants to add to favorites
                if ! favorites_is_favorite "$pkg_name" 2>/dev/null; then
                    read -p "Add $pkg_name to favorites? (y/n): " add_fav
                    if [[ "$add_fav" == "y" ]]; then
                        favorites_add "$pkg_name"
                        echo "★ Added to favorites"
                    fi
                fi
            else
                # Record failure in history
                history_record "install" "$pkg_name" "failed" "Installation failed"
                
                echo "✗ Failed to install $pkg_name"
            fi
            
            echo ""
        done <<< "$items"
        
        read -p "Press Enter to continue..."
        return 0
    done
}

# Search applications
search_applications() {
    print_header
    echo "Search Applications"
    echo ""
    
    read -p "Enter search term: " search_term
    
    if [[ -z "$search_term" ]]; then
        echo "No search term provided"
        sleep 1
        return 0
    fi
    
    echo "Searching for: $search_term"
    pkg_search "$search_term"
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# QUICKFIX MENU
################################################################################

quickfix_menu() {
    while true; do
        print_header
        echo "QuickFix - System Repair Tools"
        echo ""
        echo "1. Update System"
        echo "2. Clean Package Cache"
        echo "3. Fix Broken Packages"
        echo "4. Check Disk Space"
        echo "5. View System Logs"
        echo "0. Back to Main Menu"
        echo ""
        
        read -p "Select option: " choice
        
        case "$choice" in
            1) update_system ;;
            2) clean_cache ;;
            3) fix_broken_packages ;;
            4) check_disk_space ;;
            5) view_system_logs ;;
            0) return 0 ;;
            *)
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

# Update system
update_system() {
    print_header
    echo "Updating System..."
    echo ""
    
    # Progress tracking is handled internally by pkg_update_system()
    if pkg_update_system; then
        echo "✓ System updated successfully!"
        history_record "update" "system" "success" "System update completed"
    else
        echo "✗ System update failed"
        history_record "update" "system" "failed" "System update failed"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Clean cache
clean_cache() {
    print_header
    echo "Cleaning Package Cache..."
    echo ""
    
    if pkg_clean; then
        echo "✓ Cache cleaned successfully!"
    else
        echo "✗ Failed to clean cache"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Fix broken packages
fix_broken_packages() {
    print_header
    echo "Fixing Broken Packages..."
    echo ""
    
    case "$DETECTED_PKG_MANAGER" in
        "apt")
            sudo apt --fix-broken install -y
            ;;
        "dnf"|"yum")
            sudo $DETECTED_PKG_MANAGER check
            ;;
        "pacman")
            sudo pacman -Syy
            ;;
        *)
            echo "Not supported for $DETECTED_PKG_MANAGER"
            ;;
    esac
    
    echo ""
    read -p "Press Enter to continue..."
}

# Check disk space
check_disk_space() {
    print_header
    echo "Disk Space Usage:"
    echo ""
    
    df -h | grep -E '^/dev/'
    
    echo ""
    read -p "Press Enter to continue..."
}

# View system logs
view_system_logs() {
    print_header
    echo "Recent System Logs:"
    echo ""
    
    if command -v journalctl &>/dev/null; then
        sudo journalctl -n 50 --no-pager
    else
        tail -n 50 /var/log/syslog 2>/dev/null || tail -n 50 /var/log/messages 2>/dev/null || echo "No logs available"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# SYSTEMMANAGER MENU
################################################################################

systemmanager_menu() {
    while true; do
        print_header
        echo "SystemManager - System Monitoring"
        echo ""
        echo "1. System Information"
        echo "2. Resource Usage"
        echo "3. Network Status"
        echo "4. Service Status"
        echo "0. Back to Main Menu"
        echo ""
        
        read -p "Select option: " choice
        
        case "$choice" in
            1) show_system_info ;;
            2) show_resource_usage ;;
            3) show_network_status ;;
            4) show_service_status ;;
            0) return 0 ;;
            *)
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

# System information
show_system_info() {
    print_header
    echo "System Information:"
    echo ""
    
    echo "Hostname: $(hostname)"
    echo "Kernel: $(uname -r)"
    echo "Architecture: $(uname -m)"
    echo "Distribution: $DETECTED_DISTRO_NAME"
    echo "Package Manager: $DETECTED_PKG_MANAGER"
    echo "Uptime: $(uptime -p 2>/dev/null || uptime)"
    
    echo ""
    read -p "Press Enter to continue..."
}

# Resource usage
show_resource_usage() {
    print_header
    echo "Resource Usage:"
    echo ""
    
    if command -v htop &>/dev/null; then
        htop
    else
        top -n 1
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

# Network status
show_network_status() {
    print_header
    echo "Network Status:"
    echo ""
    
    ip addr show 2>/dev/null || ifconfig
    
    echo ""
    echo "Active Connections:"
    ss -tuln 2>/dev/null || netstat -tuln
    
    echo ""
    read -p "Press Enter to continue..."
}

# Service status
show_service_status() {
    print_header
    echo "Service Status:"
    echo ""
    
    if command -v systemctl &>/dev/null; then
        systemctl list-units --type=service --state=running
    else
        service --status-all 2>/dev/null || echo "Service management not available"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# FAVORITES MENU
################################################################################

favorites_menu_ui() {
    favorites_menu
}

################################################################################
# HISTORY MENU
################################################################################

history_menu_ui() {
    while true; do
        print_header
        echo "Installation History"
        echo ""
        echo "1. View All History"
        echo "2. View Recent (Last 10)"
        echo "3. View Successful Installations"
        echo "4. View Failed Installations"
        echo "5. Export History (JSON)"
        echo "6. Export History (CSV)"
        echo "0. Back to Main Menu"
        echo ""
        
        read -p "Select option: " choice
        
        case "$choice" in
            1) view_all_history ;;
            2) view_recent_history ;;
            3) view_successful_history ;;
            4) view_failed_history ;;
            5) export_history_json ;;
            6) export_history_csv ;;
            0) return 0 ;;
            *)
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

view_all_history() {
    print_header
    echo "All Installation History:"
    echo ""
    
    history_list | jq -r '.[] | "\(.timestamp) | \(.operation) | \(.package) | \(.status)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

view_recent_history() {
    print_header
    echo "Recent History (Last 10):"
    echo ""
    
    history_list | jq -r '.[-10:] | .[] | "\(.timestamp) | \(.operation) | \(.package) | \(.status)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

view_successful_history() {
    print_header
    echo "Successful Installations:"
    echo ""
    
    history_list | jq -r '.[] | select(.status == "success") | "\(.timestamp) | \(.operation) | \(.package)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

view_failed_history() {
    print_header
    echo "Failed Installations:"
    echo ""
    
    history_list | jq -r '.[] | select(.status == "failed") | "\(.timestamp) | \(.operation) | \(.package) | \(.message)"'
    
    echo ""
    read -p "Press Enter to continue..."
}

export_history_json() {
    local output_file="${HOME}/precoreshub_history_$(date +%Y%m%d_%H%M%S).json"
    
    if history_export "json" "$output_file"; then
        echo "✓ History exported to: $output_file"
    else
        echo "✗ Failed to export history"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

export_history_csv() {
    local output_file="${HOME}/precoreshub_history_$(date +%Y%m%d_%H%M%S).csv"
    
    if history_export "csv" "$output_file"; then
        echo "✓ History exported to: $output_file"
    else
        echo "✗ Failed to export history"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# SETTINGS MENU
################################################################################

settings_menu() {
    while true; do
        print_header
        echo "Settings"
        echo ""
        echo "1. Change Language"
        echo "2. View Configuration"
        echo "3. Reset Configuration"
        echo "4. Clear Cache"
        echo "5. View Logs"
        echo "0. Back to Main Menu"
        echo ""
        
        read -p "Select option: " choice
        
        case "$choice" in
            1) change_language ;;
            2) view_configuration ;;
            3) reset_configuration ;;
            4) clear_cache_menu ;;
            5) view_logs_menu ;;
            0) return 0 ;;
            *)
                echo "Invalid option"
                sleep 1
                ;;
        esac
    done
}

# Change language
change_language() {
    print_header
    echo "Change Language"
    echo ""
    echo "1. English"
    echo "2. Vietnamese (Tiếng Việt)"
    echo "0. Cancel"
    echo ""
    
    read -p "Select language: " choice
    
    case "$choice" in
        1)
            config_set "language" "en"
            lang_set "en"
            echo "✓ Language changed to English"
            ;;
        2)
            config_set "language" "vi"
            lang_set "vi"
            echo "✓ Ngôn ngữ đã được thay đổi sang Tiếng Việt"
            ;;
        0)
            return 0
            ;;
        *)
            echo "Invalid option"
            ;;
    esac
    
    sleep 2
}

# View configuration
view_configuration() {
    print_header
    echo "Current Configuration:"
    echo ""
    
    cat "${HOME}/.config/precoreshub/config.json" | jq '.'
    
    echo ""
    read -p "Press Enter to continue..."
}

# Reset configuration
reset_configuration() {
    print_header
    echo "Reset Configuration"
    echo ""
    
    read -p "Are you sure you want to reset all settings? (y/n): " confirm
    
    if [[ "$confirm" == "y" ]]; then
        config_reset
        echo "✓ Configuration reset to defaults"
    else
        echo "Cancelled"
    fi
    
    sleep 2
}

# Clear cache
clear_cache_menu() {
    print_header
    echo "Clear Cache"
    echo ""
    
    read -p "Clear all cached data? (y/n): " confirm
    
    if [[ "$confirm" == "y" ]]; then
        rm -rf "${HOME}/.cache/precoreshub/"*
        cache_init
        echo "✓ Cache cleared"
    else
        echo "Cancelled"
    fi
    
    sleep 2
}

# View logs
view_logs_menu() {
    print_header
    echo "Application Logs:"
    echo ""
    
    if [[ -f "${HOME}/.cache/precoreshub/logs/precoreshub.log" ]]; then
        tail -n 50 "${HOME}/.cache/precoreshub/logs/precoreshub.log"
    else
        echo "No logs available"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# MAIN EXECUTION
################################################################################

# Main entry point
main() {
    # Check dependencies first
    check_dependencies
    
    # Initialize all systems
    initialize_systems
    
    # Show main menu
    main_menu
}

# Run main function
main "$@"
