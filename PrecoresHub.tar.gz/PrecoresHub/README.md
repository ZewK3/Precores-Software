# PrecoresHub v5.0.0

Unified Control Center for Linux - Modular architecture with plugin system.

## 🚀 Quick Install

```bash
curl -sSL https://raw.githubusercontent.com/YOUR_USERNAME/PrecoresHub/main/install-precoreshub.sh | bash
```

Or with wget:

```bash
wget -qO- https://raw.githubusercontent.com/YOUR_USERNAME/PrecoresHub/main/install-precoreshub.sh | bash
```

## 📦 Manual Installation

```bash
# Download release
wget https://github.com/YOUR_USERNAME/PrecoresHub/releases/download/v5.0.0/PrecoresHub.tar.gz

# Extract
tar -xzf PrecoresHub.tar.gz

# Install
cd PrecoresHub
bash install.sh
```

## ✨ Features

- **13 Linux distributions** support (Alpine, Arch, Debian, Ubuntu, Fedora, RHEL, CentOS, openSUSE, Gentoo, Void, NixOS, Solus, Clear Linux)
- **11 package managers** (apk, pacman, apt, dnf, yum, zypper, emerge, xbps, nix, eopkg, swupd)
- **Plugin system** - Extensible architecture
- **Installation history** - Track and rollback installations
- **Favorites/bookmarks** - Quick access to frequently used apps
- **Progress tracking** - Visual feedback for operations
- **Multi-language** - English and Vietnamese support
- **Caching system** - Faster startup and operations
- **Enhanced error handling** - Helpful error messages with suggestions

## 📋 Requirements

- bash >= 4.0
- jq >= 1.6
- fzf >= 0.30.0

Install dependencies:

```bash
# Debian/Ubuntu
sudo apt install jq fzf

# Arch Linux
sudo pacman -S jq fzf

# Fedora
sudo dnf install jq fzf

# Alpine
sudo apk add jq fzf
```

## 🎯 Usage

After installation, run:

```bash
precoreshub
```

Or:

```bash
bash /opt/precoreshub/PrecoresHub.sh
```

### Main Menu

1. **QuickInstall** - Application installer with categories
2. **QuickFix** - System repair tools
3. **SystemManager** - System monitoring
4. **Favorites** - Manage favorite apps
5. **History** - Installation history and rollback
6. **Plugin Manager** - Manage plugins
7. **Settings** - Configuration

## 🔌 Plugin System

PrecoresHub supports plugins to extend functionality. See [Plugin API Documentation](https://github.com/YOUR_USERNAME/PrecoresHub/blob/main/PrecoresHub/docs/PLUGIN_API.md) for details.

Example plugin structure:

```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "description": "My custom plugin",
  "functions": {
    "my_function": "echo 'Hello from plugin!'"
  }
}
```

## 📚 Documentation

- [Quick Start Guide](PrecoresHub/QUICK_START.md) - Vietnamese
- [Start Here](PrecoresHub/START_HERE.md) - Getting started
- [Changelog](PrecoresHub/CHANGELOG.md) - Version history
- [Contributing](PrecoresHub/CONTRIBUTING.md) - Contribution guidelines
- [Plugin API](PrecoresHub/docs/PLUGIN_API.md) - Plugin development

## 🏗️ Architecture

```
PrecoresHub/
├── PrecoresHub.sh          # Main entry point
├── lib/                    # Core libraries (12 modules)
├── config/                 # Configuration files
├── lang/                   # Language files (EN/VI)
├── plugins/                # Plugin directory
├── tests/                  # Test suite (183 tests)
└── docs/                   # Documentation
```

## 🧪 Testing

Run tests:

```bash
cd PrecoresHub/tests
bash test_core.sh
bash test_config.sh
# ... run other tests
```

**Test Coverage**: 183 tests, 100% passing

## 🔧 Troubleshooting

### Permission Issues

If you encounter errors like "Permission denied" when running PrecoresHub, the lib files may not have executable permissions.

**Quick Fix:**

```bash
# Download and run the fix script
curl -sSL https://raw.githubusercontent.com/ZewK3/Precores-Software/main/fix-permissions.sh | bash
```

Or manually:

```bash
# Navigate to installation directory
cd ~/PrecoresHub  # or /opt/precoreshub

# Fix permissions
chmod +x PrecoresHub.sh
chmod +x lib/*.sh

# Verify
./PrecoresHub.sh
```

### Common Issues

**Issue**: `bash: precoreshub: command not found`
- **Solution**: Add `~/.local/bin` or `/usr/local/bin` to your PATH
  ```bash
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
  source ~/.bashrc
  ```

**Issue**: `jq: command not found` or `fzf: command not found`
- **Solution**: Install missing dependencies (see Requirements section)

**Issue**: Archive extraction fails
- **Solution**: Verify MD5 checksum and re-download
  ```bash
  md5sum -c PrecoresHub.tar.gz.md5
  ```

## 🤝 Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](PrecoresHub/CONTRIBUTING.md) for guidelines.

## 📝 License

MIT License - See [LICENSE](PrecoresHub/LICENSE) for details.

## 🔗 Links

- **Repository**: https://github.com/YOUR_USERNAME/PrecoresHub
- **Issues**: https://github.com/YOUR_USERNAME/PrecoresHub/issues
- **Releases**: https://github.com/YOUR_USERNAME/PrecoresHub/releases

## 📊 Statistics

- **Version**: 5.0.0
- **Files**: 42 files
- **Size**: ~900 KB
- **Tests**: 183 tests (100% passing)
- **Distributions**: 13 supported
- **Package Managers**: 11 supported
- **Languages**: 2 (English, Vietnamese)

## 🎉 What's New in v5.0.0

- ✅ Complete rewrite with modular architecture
- ✅ Plugin system for extensibility
- ✅ Installation history and rollback
- ✅ Favorites/bookmarks system
- ✅ Progress tracking with visual feedback
- ✅ Multi-language support (EN/VI)
- ✅ Enhanced error handling
- ✅ Caching system for performance
- ✅ Support for 13 Linux distributions
- ✅ Comprehensive test suite

## 💡 Examples

### Install Docker

```bash
precoreshub
# Select: 1. QuickInstall
# Select: 1. Development Tools
# Select: docker
# Press Enter to install
```

### Add to Favorites

```bash
# In app selection menu, press Ctrl-F
# Select apps to add to favorites
```

### View Installation History

```bash
precoreshub
# Select: 5. History
# Select: 1. View All History
```

### Change Language

```bash
precoreshub
# Select: 7. Settings
# Select: 1. Change Language
# Select: 2. Vietnamese
```

---

**Made with ❤️ by the PrecoresHub Team**

**Version**: 5.0.0  
**Date**: 2026-05-05  
**License**: MIT
