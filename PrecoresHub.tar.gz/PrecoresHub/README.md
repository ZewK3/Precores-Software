# PrecoresHub v5.0.0

**Unified Control Center for Linux System Management**

PrecoresHub is a powerful, modular command-line tool for managing Linux systems. It provides a unified interface for application installation, system repair, monitoring, and extensibility through plugins.

[![Version](https://img.shields.io/badge/version-5.0.0-blue.svg)](https://github.com/yourusername/precoreshub)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Bash](https://img.shields.io/badge/bash-%3E%3D4.0-orange.svg)](https://www.gnu.org/software/bash/)

## 🌟 Features

### Core Functionality
- **QuickInstall**: Fast application installer with 40+ pre-configured apps
- **QuickFix**: System repair and maintenance tools
- **SystemManager**: Real-time system monitoring and management
- **Plugin System**: Extensible architecture for custom functionality
- **Multi-language**: English and Vietnamese support

### New in v5.0.0
- ✨ **Modular Architecture**: 12 independent library modules
- 📦 **Plugin System**: Create and share custom plugins
- 📜 **Installation History**: Track and rollback installations
- ⭐ **Favorites**: Bookmark frequently used applications
- 📊 **Progress Tracking**: Visual progress bars for operations
- 💾 **Caching System**: Faster startup and operations
- 🌍 **13 Linux Distributions**: Extended distribution support
- 🔧 **Enhanced Error Handling**: Smart error messages with fixes
- 🎨 **Improved UI**: Better user experience with fzf integration

## 📋 Requirements

### Required
- **Bash** >= 4.0
- **jq** >= 1.6 (JSON processor)
- **fzf** >= 0.30.0 (Fuzzy finder)

### Optional
- **curl** or **wget** (for downloads)
- **git** (for plugin updates)

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/precoreshub.git
cd precoreshub

# Make executable
chmod +x PrecoresHub.sh

# Run
./PrecoresHub.sh
```

### First Run

On first run, PrecoresHub will:
1. Check for required dependencies (jq, fzf)
2. Offer to install missing dependencies
3. Initialize configuration in `~/.config/precoreshub/`
4. Detect your Linux distribution
5. Set up cache and history directories

## 📖 Usage

### Main Menu

```
================================================================
           PrecoresHub v5.0.0 - Control Center
================================================================
System: Alpine Linux (apk)
Language: en

Main Menu:

1. QuickInstall - Application Installer
2. QuickFix - System Repair Tools
3. SystemManager - System Monitoring
4. Favorites - Manage Favorite Apps
5. History - Installation History
6. Plugin Manager - Manage Plugins
7. Settings - Configuration
0. Exit
```

### QuickInstall

Install applications from curated categories:
- **Development Tools**: git, vim, vscode, docker, nodejs, python, gcc, make
- **Web Browsers**: firefox, chromium, brave
- **Media Players**: vlc, mpv, spotify
- **Office Suite**: libreoffice, gimp, inkscape
- **System Utilities**: htop, tmux, curl, wget, zip, unzip

Features:
- Multi-select with fzf
- Installation status indicators [✓]
- Favorites markers ★
- Progress tracking
- Automatic history recording

### Favorites

Manage your favorite applications:
```bash
# Add to favorites
favorites_add "git"

# Remove from favorites
favorites_remove "git"

# List favorites
favorites_list

# Install all favorites
favorites_install_all
```

### History

Track all installation operations:
- View all history
- Filter by success/failed
- Export to JSON/CSV
- Rollback installations (via library)

### Plugin System

Extend PrecoresHub with custom plugins:

```bash
# List all plugins
plugin_list

# Enable a plugin
plugin_enable "example"

# Execute plugin function
plugin_execute "example" "hello"
```

See [Plugin Development Guide](docs/PLUGIN_DEVELOPMENT.md) for creating plugins.

## 🏗️ Architecture

### Modular Design

PrecoresHub v5.0.0 uses a modular architecture with 12 core libraries:

```
PrecoresHub/
├── PrecoresHub.sh          # Main script
├── lib/                    # Core libraries
│   ├── core.sh            # Logging, JSON I/O, utilities
│   ├── config.sh          # Configuration management
│   ├── distro.sh          # Distribution detection
│   ├── package_manager.sh # Unified package manager
│   ├── progress.sh        # Progress tracking
│   ├── cache.sh           # Caching system
│   ├── history.sh         # Installation history
│   ├── favorites.sh       # Favorites system
│   ├── localization.sh    # Multi-language support
│   ├── error.sh           # Error handling
│   ├── plugin.sh          # Plugin system core
│   └── plugin_ui.sh       # Plugin management UI
├── config/                 # Configuration files
│   ├── default_config.json
│   ├── distros.json
│   └── package_mappings.json
├── lang/                   # Language files
│   ├── en.json
│   └── vi.json
├── plugins/                # System plugins
│   └── example.phub
├── tests/                  # Test suite
│   └── test_*.sh
└── docs/                   # Documentation
    ├── PLUGIN_API.md
    └── PLUGIN_DEVELOPMENT.md
```

### Supported Distributions

PrecoresHub supports 13 Linux distributions:

| Distribution | Package Manager | Status |
|-------------|----------------|--------|
| Alpine Linux | apk | ✅ Tested |
| Arch Linux | pacman | ✅ Tested |
| Debian | apt | ✅ Tested |
| Ubuntu | apt | ✅ Tested |
| Fedora | dnf | ✅ Tested |
| RHEL | yum/dnf | ✅ Supported |
| CentOS | yum/dnf | ✅ Supported |
| openSUSE | zypper | ✅ Supported |
| Gentoo | emerge | ✅ Supported |
| Void Linux | xbps | ✅ Supported |
| NixOS | nix | ✅ Supported |
| Solus | eopkg | ✅ Supported |
| Clear Linux | swupd | ✅ Supported |

## 🔌 Plugin System

### Plugin Format

Plugins are JSON files with `.phub` extension:

```json
{
  "name": "example",
  "version": "1.0.0",
  "description": "Example plugin",
  "author": "Your Name",
  "license": "MIT",
  "dependencies": ["bash", "jq"],
  "functions": {
    "hello": "echo 'Hello from plugin!'"
  },
  "menu_items": [
    {
      "label": "Say Hello",
      "function": "hello"
    }
  ]
}
```

### Plugin API

Plugins have access to 7 API functions:

1. **phub_install_package()** - Install packages
2. **phub_execute_command()** - Execute commands
3. **phub_notify()** - Display notifications
4. **phub_config_get()** - Get configuration
5. **phub_config_set()** - Set configuration
6. **phub_get_distro()** - Get distribution info
7. **phub_is_installed()** - Check if package is installed

See [Plugin API Documentation](docs/PLUGIN_API.md) for details.

## ⚙️ Configuration

Configuration is stored in `~/.config/precoreshub/config.json`:

```json
{
  "language": "en",
  "log_level": "INFO",
  "cache_ttl": 3600,
  "parallel_install_limit": 3,
  "update_check_frequency": 21600
}
```

### Configuration Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| language | string | "en" | UI language (en, vi) |
| log_level | string | "INFO" | Logging level (DEBUG, INFO, ERROR) |
| cache_ttl | number | 3600 | Cache TTL in seconds |
| parallel_install_limit | number | 3 | Max parallel installations |
| update_check_frequency | number | 21600 | Update check frequency (seconds) |

## 📊 Testing

PrecoresHub includes comprehensive test suite:

```bash
# Run all tests
cd tests
for test in test_*.sh; do
    bash "$test"
done

# Run specific test
bash tests/test_core.sh

# Run in Docker
docker run --rm -v ${PWD}:/precoreshub -w /precoreshub precoreshub-dev bash tests/test_all.sh
```

### Test Coverage

- **178 test cases**
- **100% passing**
- **12 test suites**

## 🌍 Localization

PrecoresHub supports multiple languages:

### Supported Languages
- 🇬🇧 English (en)
- 🇻🇳 Vietnamese (vi)

### Change Language

```bash
# Via Settings Menu
PrecoresHub.sh → Settings → Change Language

# Via Configuration
config_set "language" "vi"
```

### Add New Language

1. Create language file: `lang/xx.json`
2. Translate all keys from `lang/en.json`
3. Add language to `lang_list()` in `lib/localization.sh`

## 🐛 Troubleshooting

### Common Issues

**Issue**: Missing dependencies
```bash
# Solution: Install dependencies
sudo apt install jq fzf  # Debian/Ubuntu
sudo pacman -S jq fzf    # Arch Linux
sudo dnf install jq fzf  # Fedora
```

**Issue**: Permission denied
```bash
# Solution: Make script executable
chmod +x PrecoresHub.sh
```

**Issue**: Plugin not loading
```bash
# Solution: Check plugin format
jq empty plugins/yourplugin.phub
```

### Logs

View logs for debugging:
```bash
# Application logs
cat ~/.cache/precoreshub/logs/precoreshub.log

# Error logs
cat ~/.cache/precoreshub/logs/error.log
```

## 🤝 Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details.

### Development Setup

```bash
# Clone repository
git clone https://github.com/yourusername/precoreshub.git
cd precoreshub

# Install dependencies
./setup.sh

# Run tests
bash tests/test_all.sh

# Build Docker image
docker build -t precoreshub-dev -f Dockerfile.precoreshub .
```

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [fzf](https://github.com/junegunn/fzf) - Fuzzy finder
- [jq](https://github.com/stedolan/jq) - JSON processor
- All contributors and users

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/precoreshub/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/precoreshub/discussions)
- **Email**: support@precoreshub.com

## 🗺️ Roadmap

### v5.1.0 (Planned)
- [ ] Parallel installation system
- [ ] Background update checking
- [ ] Batch/scripting mode
- [ ] Keyboard shortcuts

### v5.2.0 (Planned)
- [ ] Web UI
- [ ] Remote management
- [ ] Container support
- [ ] Cloud integration

## 📈 Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.

---

**Made with ❤️ by the PrecoresHub Team**

**Star ⭐ this repository if you find it useful!**
