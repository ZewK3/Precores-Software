# 🚀 PrecoresHub v5.0.0 - BẮT ĐẦU TẠI ĐÂY!

## ⭐ FILE CHÍNH ĐỂ CHẠY

```bash
bash PrecoresHub.sh
```

**Đó là tất cả!** File `PrecoresHub.sh` sẽ tự động load tất cả các thư viện cần thiết.

---

## 📦 Cấu Trúc Dự Án

```
PrecoresHub/
├── PrecoresHub.sh          ⭐ CHẠY FILE NÀY!
├── lib/                    (12 core libraries - tự động load)
├── config/                 (3 config files - tự động load)
├── lang/                   (2 language files - tự động load)
├── plugins/                (plugin directory)
├── tests/                  (15 test files)
├── docs/                   (documentation)
└── README.md               (tài liệu đầy đủ)
```

---

## 🎯 Menu Chính

Sau khi chạy `PrecoresHub.sh`, bạn sẽ thấy:

```
1. QuickInstall - Cài đặt ứng dụng
2. QuickFix - Sửa chữa hệ thống  
3. SystemManager - Giám sát hệ thống
4. Favorites - Quản lý favorites
5. History - Lịch sử cài đặt
6. Plugin Manager - Quản lý plugins
7. Settings - Cấu hình
0. Exit
```

---

## 📋 Yêu Cầu

Trước khi chạy, cài đặt dependencies:

```bash
# Debian/Ubuntu
sudo apt install jq fzf

# Arch Linux
sudo pacman -S jq fzf

# Fedora
sudo dnf install jq fzf

# Alpine
sudo apk add jq fzf
```

---

## 📚 Tài Liệu

- **QUICK_START.md** - Hướng dẫn nhanh (Vietnamese)
- **README.md** - Tài liệu đầy đủ (English)
- **HOW_TO_USE.txt** - Hướng dẫn ngắn gọn
- **FILES_FOR_GITHUB.md** - Danh sách files lên GitHub

---

## 🌟 Tính Năng Mới v5.0.0

✅ Modular architecture  
✅ Plugin system  
✅ Installation history & rollback  
✅ Favorites/bookmarks  
✅ Progress tracking  
✅ Multi-language (EN/VI)  
✅ 13 Linux distributions support  

---

## 🔧 Troubleshooting

### Lỗi: "jq: command not found"
→ Cài đặt jq: `sudo apt install jq` (hoặc theo distro của bạn)

### Lỗi: "fzf: command not found"  
→ Cài đặt fzf: `sudo apt install fzf` (hoặc theo distro của bạn)

### Lỗi: "Permission denied"
→ Chạy: `chmod +x PrecoresHub.sh`

---

## 📤 Upload Lên GitHub

```bash
git init
git add .
git commit -m "Initial commit: PrecoresHub v5.0.0"
git remote add origin https://github.com/YOUR_USERNAME/PrecoresHub.git
git branch -M main
git push -u origin main
```

**Lưu ý**: File `.gitignore` đã được cấu hình để tự động loại trừ:
- ISO files (~3 GB)
- Extracted directories
- Build scripts
- Backup files
- Development files

**Chỉ 44 files (~900 KB) sẽ được upload lên GitHub!**

---

## 🎉 Bắt Đầu Ngay!

```bash
bash PrecoresHub.sh
```

Enjoy! 🚀

---

**Version**: 5.0.0  
**License**: MIT  
**Date**: 2026-05-05
