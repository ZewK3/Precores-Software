# PrecoresHub v5.0.0 - Hướng Dẫn Nhanh

## 🚀 Cách Sử Dụng

### Chạy PrecoresHub

```bash
bash PrecoresHub.sh
```

Hoặc:

```bash
chmod +x PrecoresHub.sh
./PrecoresHub.sh
```

### Menu Chính

Sau khi chạy, bạn sẽ thấy menu:

```
================================================================
           PrecoresHub v5.0.0 - Control Center
================================================================
System: [Your Distribution] ([Package Manager])
Language: en

Main Menu:

1. QuickInstall - Application Installer
2. QuickFix - System Repair Tools
3. SystemManager - System Monitoring
4. Favorites - Manage Favorite Apps
5. History - Installation History
6. Plugin Manager - Manage Plugins
7. Settings - Configuration
0. Exit
```

### Các Tính Năng Chính

#### 1. QuickInstall - Cài Đặt Ứng Dụng
- Chọn từ các danh mục: Development Tools, Web Browsers, Media Players, Office Suite, System Utilities
- Sử dụng fzf để tìm kiếm và chọn nhiều ứng dụng cùng lúc
- Nhấn **Tab** để chọn nhiều ứng dụng
- Nhấn **Ctrl-F** để thêm/xóa favorites
- Nhấn **Enter** để cài đặt

#### 2. QuickFix - Sửa Chữa Hệ Thống
- Update System
- Clean Package Cache
- Fix Broken Packages
- Check Disk Space
- View System Logs

#### 3. SystemManager - Giám Sát Hệ Thống
- System Information
- Resource Usage
- Network Status
- Service Status

#### 4. Favorites - Quản Lý Ứng Dụng Yêu Thích
- Xem danh sách favorites
- Thêm/xóa favorites
- Cài đặt tất cả favorites cùng lúc

#### 5. History - Lịch Sử Cài Đặt
- Xem lịch sử cài đặt
- Lọc theo thành công/thất bại
- Export sang JSON/CSV
- Rollback (nếu cần)

#### 6. Plugin Manager - Quản Lý Plugins
- Xem danh sách plugins
- Bật/tắt plugins
- Xem thông tin chi tiết
- Chạy plugin functions

#### 7. Settings - Cấu Hình
- Đổi ngôn ngữ (English/Vietnamese)
- Xem cấu hình
- Reset cấu hình
- Xóa cache
- Xem logs

## 📋 Yêu Cầu Hệ Thống

### Bắt Buộc
- **bash** >= 4.0
- **jq** >= 1.6 (JSON processor)
- **fzf** >= 0.30.0 (Fuzzy finder)

### Hỗ Trợ
- **13 Linux distributions**: Alpine, Arch, Debian, Ubuntu, Fedora, RHEL, CentOS, openSUSE, Gentoo, Void, NixOS, Solus, Clear Linux
- **11 package managers**: apk, pacman, apt, dnf, yum, zypper, emerge, xbps, nix, eopkg, swupd

## 🔧 Cài Đặt Dependencies

### Debian/Ubuntu
```bash
sudo apt install jq fzf
```

### Arch Linux
```bash
sudo pacman -S jq fzf
```

### Fedora/RHEL/CentOS
```bash
sudo dnf install jq fzf
```

### Alpine Linux
```bash
sudo apk add jq fzf
```

## 📁 Cấu Trúc Thư Mục

```
PrecoresHub/
├── PrecoresHub.sh          # Main script - CHẠY FILE NÀY!
├── lib/                    # Core libraries
│   ├── core.sh
│   ├── config.sh
│   ├── distro.sh
│   ├── package_manager.sh
│   ├── progress.sh
│   ├── cache.sh
│   ├── history.sh
│   ├── favorites.sh
│   ├── localization.sh
│   ├── error.sh
│   ├── plugin.sh
│   └── plugin_ui.sh
├── config/                 # Configuration files
│   ├── default_config.json
│   ├── distros.json
│   └── package_mappings.json
├── lang/                   # Language files
│   ├── en.json
│   └── vi.json
├── plugins/                # Plugin directory
│   └── example.phub
├── tests/                  # Test suite
└── docs/                   # Documentation
    └── PLUGIN_API.md

User directories (auto-created):
~/.config/precoreshub/      # User configuration
~/.cache/precoreshub/       # Cache and logs
```

## 🎯 Ví Dụ Sử Dụng

### Cài Đặt Docker
1. Chạy `bash PrecoresHub.sh`
2. Chọn `1` (QuickInstall)
3. Chọn `1` (Development Tools)
4. Tìm và chọn `docker`
5. Nhấn Enter để cài đặt

### Thêm Vào Favorites
1. Trong menu chọn ứng dụng, nhấn **Ctrl-F**
2. Chọn ứng dụng muốn thêm vào favorites
3. Nhấn Enter

### Cài Đặt Tất Cả Favorites
1. Chọn `4` (Favorites) từ main menu
2. Chọn `2` (Install All Favorites)

### Xem Lịch Sử Cài Đặt
1. Chọn `5` (History) từ main menu
2. Chọn option để xem lịch sử

### Đổi Ngôn Ngữ
1. Chọn `7` (Settings) từ main menu
2. Chọn `1` (Change Language)
3. Chọn ngôn ngữ mong muốn

## 🐛 Troubleshooting

### Lỗi: "jq: command not found"
```bash
# Cài đặt jq theo distro của bạn (xem phần Cài Đặt Dependencies)
```

### Lỗi: "fzf: command not found"
```bash
# Cài đặt fzf theo distro của bạn (xem phần Cài Đặt Dependencies)
```

### Lỗi: "Permission denied"
```bash
chmod +x PrecoresHub.sh
```

### Reset Configuration
```bash
rm -rf ~/.config/precoreshub/
rm -rf ~/.cache/precoreshub/
# Chạy lại PrecoresHub.sh để tạo config mới
```

## 📚 Tài Liệu Đầy Đủ

- **README.md** - Tài liệu chi tiết
- **CHANGELOG.md** - Lịch sử phiên bản
- **CONTRIBUTING.md** - Hướng dẫn đóng góp
- **docs/PLUGIN_API.md** - Plugin development guide

## 🤝 Hỗ Trợ

Nếu gặp vấn đề, vui lòng:
1. Kiểm tra logs: `~/.cache/precoreshub/logs/precoreshub.log`
2. Xem error logs: `~/.cache/precoreshub/logs/error.log`
3. Tạo issue trên GitHub

## 📝 License

MIT License - Xem file LICENSE để biết thêm chi tiết.

---

**Phiên bản**: 5.0.0  
**Cập nhật**: 2026-05-05
