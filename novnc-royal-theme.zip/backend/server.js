const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const compression = require('compression');
require('dotenv').config();

const fileRoutes = require('./routes/files');
const { logger } = require('./utils/logger');
const { errorHandler } = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 8080;

// Performance optimizations
app.set('trust proxy', true);
app.set('x-powered-by', false);

// Compression middleware (gzip/deflate)
app.use(compression({
  level: 6, // Balance between speed and compression
  threshold: 1024, // Only compress responses > 1KB
  filter: (req, res) => {
    // Don't compress file downloads (already binary)
    if (req.path.includes('/download/')) {
      return false;
    }
    return compression.filter(req, res);
  }
}));

// CORS with optimizations
app.use(cors({
  origin: '*',
  credentials: true,
  maxAge: 86400 // Cache preflight for 24 hours
}));

// Increase payload limits for large files
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`, {
    ip: req.ip,
    userAgent: req.get('user-agent')
  });
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Alias for Cloudflare Tunnel compatibility (api* -> 8080)
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API Routes
app.use('/api', fileRoutes);

// Proxy WebSocket to Websockify (noVNC)
// Cloudflared points to 8080, so we must proxy WS to 6080
const { createProxyMiddleware } = require('http-proxy-middleware');
app.use('/websockify', createProxyMiddleware({
  target: 'http://127.0.0.1:6080',
  changeOrigin: true,
  ws: true,
  logLevel: 'error'
}));

// Determine noVNC Static Files Path
function getNoVNCPath() {
  // Priority 1: Environment Variable
  if (process.env.NOVNC_PATH && fs.existsSync(process.env.NOVNC_PATH)) {
    return process.env.NOVNC_PATH;
  }

  // Priority 2: Standard Linux Path
  if (fs.existsSync('/usr/share/novnc')) {
    return '/usr/share/novnc';
  }

  // Priority 3: Local 'novnc' folder next to parent (Development)
  const localNoVNC = path.join(__dirname, '../../novnc'); // Adjust relative path as needed
  if (fs.existsSync(localNoVNC)) {
    return localNoVNC;
  }

  // Fallback: Just use current directory (likely wrong but safe)
  return path.join(__dirname, 'public');
}

const noVNCPath = getNoVNCPath();
logger.info(`Serving noVNC from: ${noVNCPath}`);

// Serve Custom Frontend Assets (Overlay)
// In production, these files are copied into the noVNC directory, so specific routes are not needed.
// app.use('/app', express.static(path.join(customFrontendPath, 'js')));
// app.use('/app/styles', express.static(path.join(customFrontendPath, 'css')));

// Force No-Cache for HTML files (to ensure vnc.html updates are seen)
app.use((req, res, next) => {
  if (req.path.endsWith('.html') || req.path === '/') {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Surrogate-Control', 'no-store');
  }
  next();
});

// Serve actual noVNC files (Fallback)
app.use(express.static(noVNCPath));

// Error handling
app.use(errorHandler);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint not found' });
});

// Start server with optimizations
const server = app.listen(PORT, () => {
  logger.info(`noVNC File Transfer API server running on port ${PORT}`);
  logger.info(`Upload directory: ${process.env.UPLOAD_DIR || '/home/user/Downloads'}`);
  logger.info(`Max file size: ${(process.env.MAX_FILE_SIZE || 104857600) / 1024 / 1024}MB`);
});

// Increase server timeout for large file transfers
server.timeout = 300000; // 5 minutes
server.keepAliveTimeout = 65000; // 65 seconds
server.headersTimeout = 66000; // 66 seconds

module.exports = app;
