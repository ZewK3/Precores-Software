const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const { logger } = require('../utils/logger');
const { isPathSafe, getSafePath, isSystemPath } = require('../utils/pathValidator');

/**
 * Upload file controller
 */
async function uploadFile(req, res, next) {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No file uploaded'
      });
    }

    const file = req.file;
    
    // Validate file path
    if (!isPathSafe(file.filename)) {
      // Delete the uploaded file
      await fs.unlink(file.path);
      return res.status(400).json({
        success: false,
        error: 'Invalid file path'
      });
    }

    // Calculate file checksum for integrity verification
    const checksum = await calculateChecksum(file.path);

    logger.info('File uploaded successfully', {
      filename: file.originalname,
      size: file.size,
      path: file.path,
      checksum: checksum
    });

    res.json({
      success: true,
      filename: file.originalname,
      storedAs: file.filename,
      size: file.size,
      path: file.path,
      checksum: checksum,
      uploadedAt: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Upload error', { error: error.message });
    next(error);
  }
}

/**
 * Download file controller with optimized streaming
 */
async function downloadFile(req, res, next) {
  try {
    const filename = req.params.filename;
    const baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
    
    // Validate path
    if (!isPathSafe(filename, baseDir)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid file path'
      });
    }

    const filePath = getSafePath(filename, baseDir);
    
    if (!filePath) {
      return res.status(400).json({
        success: false,
        error: 'Invalid file path'
      });
    }

    // Check if file exists
    let stats;
    try {
      stats = await fs.stat(filePath);
    } catch (error) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }
    
    if (!stats.isFile()) {
      return res.status(400).json({
        success: false,
        error: 'Not a file'
      });
    }

    logger.info('File download started', {
      filename: filename,
      size: stats.size,
      path: filePath
    });

    // Set headers for optimized streaming
    const basename = path.basename(filename);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${basename}"`);
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Accept-Ranges', 'bytes');
    
    // Support range requests for resume capability
    const range = req.headers.range;
    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : stats.size - 1;
      const chunksize = (end - start) + 1;
      
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${stats.size}`);
      res.setHeader('Content-Length', chunksize);
      
      const fileStream = fsSync.createReadStream(filePath, { start, end, highWaterMark: 64 * 1024 });
      fileStream.pipe(res);
    } else {
      // Stream entire file with optimized buffer size
      const fileStream = fsSync.createReadStream(filePath, { highWaterMark: 64 * 1024 });
      fileStream.pipe(res);
    }

  } catch (error) {
    logger.error('Download error', { error: error.message });
    next(error);
  }
}

/**
 * List files in directory
 */
async function listFiles(req, res, next) {
  try {
    const requestedPath = req.query.path || '';
    const baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
    
    // Validate path
    if (!isPathSafe(requestedPath, baseDir)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid directory path'
      });
    }

    const dirPath = getSafePath(requestedPath, baseDir) || baseDir;

    // Check if directory exists
    try {
      const stats = await fs.stat(dirPath);
      if (!stats.isDirectory()) {
        return res.status(400).json({
          success: false,
          error: 'Not a directory'
        });
      }
    } catch (error) {
      return res.status(404).json({
        success: false,
        error: 'Directory not found'
      });
    }

    // Read directory contents
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    
    // Get file details
    const files = await Promise.all(
      entries.map(async (entry) => {
        try {
          const fullPath = path.join(dirPath, entry.name);
          const stats = await fs.stat(fullPath);
          
          return {
            name: entry.name,
            type: entry.isDirectory() ? 'directory' : 'file',
            size: entry.isDirectory() ? 0 : stats.size,
            modified: stats.mtime.toISOString(),
            permissions: stats.mode
          };
        } catch (error) {
          logger.warn('Error reading file stats', { file: entry.name, error: error.message });
          return null;
        }
      })
    );

    // Filter out null entries (files we couldn't read)
    const validFiles = files.filter(f => f !== null);

    logger.info('Directory listed', {
      path: dirPath,
      fileCount: validFiles.length
    });

    res.json({
      success: true,
      path: requestedPath || '/',
      files: validFiles
    });

  } catch (error) {
    logger.error('List files error', { error: error.message });
    next(error);
  }
}

/**
 * Browse specific directory
 */
async function browseDirectory(req, res, next) {
  try {
    const requestedPath = req.params.path || '';
    const baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
    
    // Validate path
    if (!isPathSafe(requestedPath, baseDir)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid directory path'
      });
    }

    const dirPath = getSafePath(requestedPath, baseDir);
    
    if (!dirPath) {
      return res.status(400).json({
        success: false,
        error: 'Invalid directory path'
      });
    }

    // Check if directory exists
    try {
      const stats = await fs.stat(dirPath);
      if (!stats.isDirectory()) {
        return res.status(400).json({
          success: false,
          error: 'Not a directory'
        });
      }
    } catch (error) {
      return res.status(404).json({
        success: false,
        error: 'Directory not found'
      });
    }

    // Read directory contents
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    
    // Get file details
    const files = await Promise.all(
      entries.map(async (entry) => {
        try {
          const fullPath = path.join(dirPath, entry.name);
          const stats = await fs.stat(fullPath);
          
          return {
            name: entry.name,
            type: entry.isDirectory() ? 'directory' : 'file',
            size: entry.isDirectory() ? 0 : stats.size,
            modified: stats.mtime.toISOString()
          };
        } catch (error) {
          return null;
        }
      })
    );

    const validFiles = files.filter(f => f !== null);

    res.json({
      success: true,
      path: requestedPath,
      files: validFiles
    });

  } catch (error) {
    logger.error('Browse directory error', { error: error.message });
    next(error);
  }
}

/**
 * Delete file controller
 */
async function deleteFile(req, res, next) {
  try {
    const filename = req.params.filename;
    const baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
    
    // Validate path
    if (!isPathSafe(filename, baseDir)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid file path'
      });
    }

    const filePath = getSafePath(filename, baseDir);
    
    if (!filePath) {
      return res.status(400).json({
        success: false,
        error: 'Invalid file path'
      });
    }

    // Check if file exists
    try {
      const stats = await fs.stat(filePath);
      if (!stats.isFile()) {
        return res.status(400).json({
          success: false,
          error: 'Not a file'
        });
      }
    } catch (error) {
      return res.status(404).json({
        success: false,
        error: 'File not found'
      });
    }

    // Delete the file
    await fs.unlink(filePath);

    logger.info('File deleted', {
      filename: filename,
      path: filePath
    });

    res.json({
      success: true,
      message: 'File deleted successfully',
      filename: filename
    });

  } catch (error) {
    logger.error('Delete file error', { error: error.message });
    next(error);
  }
}

/**
 * Calculate file checksum (SHA256)
 */
function calculateChecksum(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fsSync.createReadStream(filePath);
    
    stream.on('data', (data) => hash.update(data));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

module.exports = {
  uploadFile,
  downloadFile,
  listFiles,
  browseDirectory,
  deleteFile
};
