const crypto = require('crypto');
const { logger } = require('../utils/logger');

// In-memory token storage (in production, use Redis or database)
const tokens = new Map();

/**
 * Generate a new authentication token
 * @returns {string} - The generated token
 */
function generateToken() {
  const token = crypto.randomBytes(32).toString('hex');
  const expiry = Date.now() + (parseInt(process.env.TOKEN_EXPIRY) || 86400) * 1000;
  
  tokens.set(token, {
    createdAt: Date.now(),
    expiresAt: expiry
  });

  // Clean up expired tokens
  cleanupExpiredTokens();

  logger.info('New token generated', { token: token.substring(0, 8) + '...' });
  return token;
}

/**
 * Validate an authentication token
 * @param {string} token - The token to validate
 * @returns {boolean} - True if valid, false otherwise
 */
function validateToken(token) {
  if (!token) {
    return false;
  }

  const tokenData = tokens.get(token);
  
  if (!tokenData) {
    return false;
  }

  // Check if token is expired
  if (Date.now() > tokenData.expiresAt) {
    tokens.delete(token);
    return false;
  }

  return true;
}

/**
 * Clean up expired tokens from memory
 */
function cleanupExpiredTokens() {
  const now = Date.now();
  let cleaned = 0;

  for (const [token, data] of tokens.entries()) {
    if (now > data.expiresAt) {
      tokens.delete(token);
      cleaned++;
    }
  }

  if (cleaned > 0) {
    logger.info(`Cleaned up ${cleaned} expired tokens`);
  }
}

/**
 * Authentication middleware
 */
function authMiddleware(req, res, next) {
  // Skip auth for health check and token generation
  if (req.path === '/health' || req.path === '/api/token') {
    return next();
  }

  const authHeader = req.headers['authorization'];
  
  if (!authHeader) {
    logger.warn('Missing authorization header', { ip: req.ip, path: req.path });
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: Missing authorization header'
    });
  }

  // Extract token from "Bearer <token>" format
  const token = authHeader.startsWith('Bearer ') 
    ? authHeader.substring(7) 
    : authHeader;

  if (!validateToken(token)) {
    logger.warn('Invalid or expired token', { ip: req.ip, path: req.path });
    return res.status(401).json({
      success: false,
      error: 'Unauthorized: Invalid or expired token'
    });
  }

  next();
}

// Run cleanup every hour
setInterval(cleanupExpiredTokens, 3600000);

module.exports = {
  authMiddleware,
  generateToken,
  validateToken
};
