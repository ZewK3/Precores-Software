const path = require('path');
const os = require('os');

/**
 * Validates if a file path is safe and within allowed boundaries
 * @param {string} filePath - The file path to validate
 * @param {string} baseDir - The base directory (default: user's home Downloads)
 * @returns {boolean} - True if path is safe, false otherwise
 */
function isPathSafe(filePath, baseDir = null) {
  try {
    // Default base directory
    if (!baseDir) {
      baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
    }

    // Sanitize: Treat leading slashes as relative to baseDir (strip them)
    // This prevents path.resolve() from treating it as a filesystem root override
    if (filePath.startsWith('/') || filePath.startsWith('\\')) {
      filePath = filePath.replace(/^[\/\\]+/, '');
    }

    // Resolve the full path
    const resolvedPath = path.resolve(baseDir, filePath);
    const resolvedBase = path.resolve(baseDir);

    // Check if resolved path starts with base directory
    if (!resolvedPath.startsWith(resolvedBase)) {
      return false;
    }

    // Check for path traversal attempts
    if (filePath.includes('..') || filePath.includes('./')) {
      return false;
    }

    // Check for absolute paths (should be relative)
    if (path.isAbsolute(filePath)) {
      return false;
    }

    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Get the safe absolute path within the base directory
 * @param {string} filePath - The relative file path
 * @param {string} baseDir - The base directory
 * @returns {string|null} - The safe absolute path or null if invalid
 */
function getSafePath(filePath, baseDir = null) {
  if (!baseDir) {
    baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
  }

  if (!isPathSafe(filePath, baseDir)) {
    return null;
  }

  return path.resolve(baseDir, filePath);
}

/**
 * Check if path is a system directory
 * @param {string} filePath - The file path to check
 * @returns {boolean} - True if it's a system directory
 */
function isSystemPath(filePath) {
  const systemPaths = [
    '/etc',
    '/sys',
    '/proc',
    '/dev',
    '/boot',
    '/root',
    '/var',
    '/usr/bin',
    '/usr/sbin',
    'C:\\Windows',
    'C:\\Program Files'
  ];

  const resolvedPath = path.resolve(filePath);
  return systemPaths.some(sysPath => resolvedPath.startsWith(sysPath));
}

module.exports = {
  isPathSafe,
  getSafePath,
  isSystemPath
};
