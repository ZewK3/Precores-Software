const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const os = require('os');
const fs = require('fs');

const { authMiddleware, generateToken } = require('../middleware/auth');
const { rateLimitMiddleware } = require('../middleware/rateLimit');
const fileController = require('../controllers/fileController');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');

    // Support for folder structure (recursive uploads)
    if (req.headers['x-relative-path']) {
      // Sanitize path to prevent directory traversal
      const relativePath = req.headers['x-relative-path'].replace(/\.\./g, '');
      const subDir = path.dirname(relativePath);

      if (subDir && subDir !== '.') {
        uploadDir = path.join(uploadDir, subDir);
        // Ensure directory exists
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }
      }
    }

    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Start with original name
    let filename = file.originalname;

    // If we have a relative path, the originalname might just be the basename, 
    // or it might be the full path depending on the client. 
    // But multer usually gives valid filename. 
    // We already handled the directory in 'destination'.

    // Auto-rename if exists (or just overwrite? User didn't specify. 
    // Existing logic used timestamp. Let's keep timestamp for safety 
    // BUT folder uploads usually expect exact names.
    // Let's use a simpler safe name without timestamp if it's a folder upload, 
    // to preserve structure exactly? 
    // User request: "transfer folder". Usually implies exact mirror.
    // But existing logic forced timestamp.
    // I will modify to use original name IF x-relative-path is set, to keep structure clean.

    if (req.headers['x-relative-path']) {
      // Use exact name for directory uploads to preserve structure
      cb(null, filename);
    } else {
      // Timestamp for single files to avoid conflicts
      const timestamp = Date.now();
      const safeName = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
      cb(null, `${timestamp}-${safeName}`);
    }
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 104857600 // 100MB default
  },
  fileFilter: (req, file, cb) => {
    // Optional: Add file type restrictions here
    // For now, allow all file types
    cb(null, true);
  }
});

// Token generation endpoint (no auth required)
router.post('/token', (req, res) => {
  try {
    const token = generateToken();
    res.json({
      success: true,
      token: token,
      expiresIn: parseInt(process.env.TOKEN_EXPIRY) || 86400 // seconds
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to generate token'
    });
  }
});

// Apply authentication and rate limiting to all routes below
router.use(authMiddleware);
router.use(rateLimitMiddleware);

// File upload endpoint
router.post('/upload', upload.single('file'), fileController.uploadFile);

// File download endpoint
router.get('/download/:filename', fileController.downloadFile);

// List files in directory
router.get('/files', fileController.listFiles);

// Browse specific directory
router.get('/files/:path(*)', fileController.browseDirectory);

// Delete file
router.delete('/files/:filename', fileController.deleteFile);

module.exports = router;
