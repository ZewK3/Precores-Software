const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const os = require('os');
const fs = require('fs');
const archiver = require('archiver');

const { authMiddleware, generateToken } = require('../middleware/auth');
const { rateLimitMiddleware } = require('../middleware/rateLimit');
const fileController = require('../controllers/fileController');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');

    // Support for folder structure (recursive uploads)
    if (req.headers['x-relative-path']) {
      // Sanitize path to prevent directory traversal
      const relativePath = req.headers['x-relative-path'].replace(/\.\./g, '');
      const subDir = path.dirname(relativePath);

      if (subDir && subDir !== '.') {
        uploadDir = path.join(uploadDir, subDir);
        // Ensure directory exists
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }
      }
    }

    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Start with original name
    let filename = file.originalname;

    // If we have a relative path, the originalname might just be the basename, 
    // or it might be the full path depending on the client. 
    // But multer usually gives valid filename. 
    // We already handled the directory in 'destination'.

    // Auto-rename if exists (or just overwrite? User didn't specify. 
    // Existing logic used timestamp. Let's keep timestamp for safety 
    // BUT folder uploads usually expect exact names.
    // Let's use a simpler safe name without timestamp if it's a folder upload, 
    // to preserve structure exactly? 
    // User request: "transfer folder". Usually implies exact mirror.
    // But existing logic forced timestamp.
    // I will modify to use original name IF x-relative-path is set, to keep structure clean.

    if (req.headers['x-relative-path']) {
      // Use exact name for directory uploads to preserve structure
      cb(null, filename);
    } else {
      // Timestamp for single files to avoid conflicts
      const timestamp = Date.now();
      const safeName = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
      cb(null, `${timestamp}-${safeName}`);
    }
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 2147483648 // 2GB default (increased from 100MB)
  },
  fileFilter: (req, file, cb) => {
    // Allow all file types
    cb(null, true);
  }
});

// Token generation endpoint (no auth required)
router.post('/token', (req, res) => {
  try {
    const token = generateToken();
    res.json({
      success: true,
      token: token,
      expiresIn: parseInt(process.env.TOKEN_EXPIRY) || 86400 // seconds
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to generate token'
    });
  }
});

// Apply authentication and rate limiting to all routes below
router.use(authMiddleware);
router.use(rateLimitMiddleware);

// File upload endpoint
router.post('/upload', upload.single('file'), fileController.uploadFile);

// File download endpoint
router.get('/download/:filename', fileController.downloadFile);

// List files in directory
router.get('/files', fileController.listFiles);

// Browse specific directory
router.get('/files/:path(*)', fileController.browseDirectory);

// Delete file
router.delete('/files/:filename', fileController.deleteFile);

// Download folder as ZIP
router.get('/download-folder/:folderPath(*)', async (req, res, next) => {
  try {
    const folderPath = req.params.folderPath || '';
    const baseDir = process.env.UPLOAD_DIR || path.join(os.homedir(), 'Downloads');
    const fullPath = path.join(baseDir, folderPath);

    // Validate path
    if (!fullPath.startsWith(baseDir)) {
      return res.status(400).json({ success: false, error: 'Invalid path' });
    }

    // Check if directory exists
    if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isDirectory()) {
      return res.status(404).json({ success: false, error: 'Folder not found' });
    }

    // Set headers
    const folderName = path.basename(fullPath) || 'download';
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${folderName}.zip"`);

    // Create zip archive
    const archive = archiver('zip', {
      zlib: { level: 6 } // Compression level (0-9)
    });

    // Pipe archive to response
    archive.pipe(res);

    // Add directory to archive
    archive.directory(fullPath, false);

    // Finalize archive
    await archive.finalize();

  } catch (error) {
    console.error('Download folder error:', error);
    next(error);
  }
});

module.exports = router;
