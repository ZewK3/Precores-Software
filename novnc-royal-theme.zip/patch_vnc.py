#!/usr/bin/env python3
print("Running Patch VNC Script v13 (LOGO FIX ONLY - NO CSS)")

import time
import re
import sys
import os

timestamp = int(time.time())

# NO CSS INJECTION (User relies on base.css)
css_inject = ""

# SIDEBAR HTML (Fixed Logo Encoding)
sidebar_html = """
    <!-- PRECORES Royal Sidebar -->
    <div id="noVNC_custom_sidebar" class="noVNC_vertical_sidebar">
        <!-- Logo & Signal -->
        <div class="sidebar-header">
            <!-- Fixed Logo with HTML Entity -->
            <div class="sidebar-logo" title="PRECORES OS">&#9812;</div>
            <div id="network_widget" class="network-widget" title="Connection Quality">
                <div class="signal-bar"></div>
                <div class="signal-bar"></div>
                <div class="signal-bar"></div>
            </div>
        </div>
        
        <!-- Group 1: Session -->
        <div class="sidebar-group">
            <button id="btn_fullscreen_custom" class="sidebar-btn" data-tooltip="Fullscreen">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>
            </button>
            <button id="btn_stats_custom" class="sidebar-btn" data-tooltip="Statistics">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
            </button>
        </div>

        <div class="sidebar-divider"></div>

        <!-- Group 2: View Control -->
        <div class="sidebar-group">
             <button id="btn_fit_custom" class="sidebar-btn" data-tooltip="Fit Screen">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"></path></svg>
            </button>
             <button id="btn_quality_custom" class="sidebar-btn" data-tooltip="Toggle Quality (HD/Fast)">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"></path><path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83M16.62 12l-5.74 9.94"></path></svg>
            </button>
        </div>

        <div class="sidebar-divider"></div>

        <!-- Group 3: Macros -->
        <div class="sidebar-group">
            <button id="btn_key_win" class="sidebar-btn" data-tooltip="Windows Key">
                 <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M3 3h18v18H3zM3 12h18M12 3v18"></path></svg>
            </button>
            <button id="btn_key_alttab" class="sidebar-btn" data-tooltip="Alt+Tab">
                 <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M16 4l4 4-4 4"></path><path d="M20 8H4"></path><path d="M8 20l-4-4 4-4"></path><path d="M4 16h16"></path></svg>
            </button>
             <button id="btn_key_esc" class="sidebar-btn" data-tooltip="Escape">
                 <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 6L6 18M6 6l12 12"></path><rect x="4" y="4" width="16" height="16" rx="2"></rect></svg>
            </button>
             <button id="btn_cad_custom" class="sidebar-btn" data-tooltip="Ctrl+Alt+Del">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H21a2 2 0 0 1 2 2v9.76a2 2 0 0 1-2 2h-2.24"></path><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>

        <div class="sidebar-divider"></div>

        <!-- Group 4: Tools -->
        <div class="sidebar-group">
            <button id="btn_clipboard_custom" class="sidebar-btn" data-tooltip="Clipboard">
                 <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect></svg>
            </button>
             <button id="btn_screenshot" class="sidebar-btn" data-tooltip="Screenshot">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>
            </button>
            <button id="btn_record_custom" class="sidebar-btn" data-tooltip="Screen Recording">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M23 7l-7 5 7 5V7z"></path><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg>
            </button>
        </div>

        <div class="sidebar-divider"></div>

        <!-- Group 5: File Transfer -->
        <div class="sidebar-group">
            <button id="btn_upload" class="sidebar-btn" data-tooltip="File Transfer">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
            </button>
        </div>

        <div class="sidebar-spacer"></div>

        <!-- Group 6: System -->
        <div class="sidebar-group">
            <button id="btn_refresh_custom" class="sidebar-btn" data-tooltip="Reload Connection">
                 <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
            </button>
             <button id="btn_settings_custom" class="sidebar-btn" data-tooltip="Settings">
                <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
            </button>
        </div>
        
        <!-- Session Clock -->
        <div id="session_clock" class="session-clock" title="Session Time">
            00:00
        </div>
    </div>
"""

js_inject = f'''
    <!-- Antigravity Integrations -->
    <script src="app/enhanced-features.js?v={timestamp}" defer></script>
    <script src="app/api-client.js?v={timestamp}" defer></script>
    <script src="app/file-browser.js?v={timestamp}" defer></script>
    <script src="app/file-transfer-modal.js?v={timestamp}" defer></script>
    <script src="app/file-transfer-ui.js?v={timestamp}" defer></script>
    <script>
      console.log("Royal Theme Loaded: {timestamp}");
      
      // Ensure RFB is exposed for buttons
      window.addEventListener('load', function() {{
          setTimeout(function() {{
              if (!window.rfb && window.UI && window.UI.rfb) {{
                  window.rfb = window.UI.rfb;
                  console.log("Exposed window.rfb from UI.rfb");
              }}
          }}, 2000);
      }});
      
      // Configure API URL
      window.FILE_TRANSFER_API_URL = "/api";
    </script>
'''

def is_patched(text):
    return "custom-theme.css" in text or "enhanced-features.js" in text or "Royal Theme" in text

def process_file(current_file):
    print(f"\\n--- Processing {current_file} ---")
    
    if not os.path.exists(current_file):
        print(f"File not found: {current_file}")
        return

    # 1. GZIP CLEANUP (Crucial fix for stale server cache)
    gzip_file = current_file + ".gz"
    if os.path.exists(gzip_file):
        print(f"DEBUG: Found stale .gz file {gzip_file}. Deleting to force server to use patched HTML...")
        try:
            os.remove(gzip_file)
            print("DEBUG: .gz file deleted.")
        except Exception as e:
            print(f"DEBUG: Failed to delete .gz file: {e}")

    with open(current_file, 'r') as f:
        content_to_use = f.read()

    # Sanitize (Regex based for dynamic tags)
    if is_patched(content_to_use):
        print(f"DEBUG: Detected existing patch in {os.path.basename(current_file)}. Sanitizing...")
        
        # Remove Inline CSS Block (New v11/v12)
        content_to_use = re.sub(r'<!-- Royal Theme Layout Fixes -->.*?<style>.*?</style>', '', content_to_use, flags=re.DOTALL)
        content_to_use = re.sub(r'<!-- Royal Theme & Integrations -->.*?/* Z-Index Fixes */\s*#noVNC_file_transfer_button.*?<style>.*?/* Z-Index Fixes */.*?</style>', '', content_to_use, flags=re.DOTALL)
        
        # Remove Old CSS Block
        content_to_use = re.sub(r'<!-- Royal Theme & Integrations -->.*?<!-- Royal Theme & Integrations \(Merged into base\.css\) -->\s*?<style>.*?</style>', '', content_to_use, flags=re.DOTALL)
        content_to_use = re.sub(r'<!-- Royal Theme & Integrations -->.*?<style>.*?</style>', '', content_to_use, flags=re.DOTALL)

        # Remove Sidebar/JS Block
        content_to_use = re.sub(r'<!-- PRECORES Royal Sidebar -->.*?</body>', '</body>', content_to_use, flags=re.DOTALL)
        
        # Remove Specific Tags (Regex for timestamped versions)
        content_to_use = re.sub(r'<link rel="stylesheet" href="app/styles/custom-theme\.css.*?>', '', content_to_use)
        content_to_use = re.sub(r'<script src="app/enhanced-features\.js.*?" defer></script>', '', content_to_use)
        
        # Remove Legacy Tags (without timestamp or standard attributes)
        content_to_use = content_to_use.replace('<link rel="stylesheet" href="app/styles/custom-theme.css">', '')
        content_to_use = content_to_use.replace('<script src="app/enhanced-features.js" defer></script>', '')
        
        print("DEBUG: Sanitization complete.")
    
    # Inject
    print("DEBUG: Injecting Fresh Code...")
    content = content_to_use

    # Inject CSS (If not empty)
    if css_inject and "noVNC_vertical_sidebar" not in content:
        if "</head>" in content:
            content = content.replace("</head>", css_inject + "\\n</head>")
        else:
            content = css_inject + content

    # Inject JS/Sidebar
    if "enhanced-features.js" not in content:
        if "</body>" in content:
            content = content.replace("</body>", sidebar_html + "\\n" + js_inject + "\\n</body>")
        else:
            content = content + sidebar_html + js_inject

    # Save
    with open(current_file, 'w') as f:
        f.write(content)
    
    print(f"Successfully patched {current_file}")


# Main Execution Logic
if __name__ == "__main__":
    primary_target = sys.argv[1]
    base_dir = os.path.dirname(primary_target)

    # List of files to attempt to patch
    targets = ['vnc.html', 'index.html', 'vnc_lite.html', 'vnc_auto.html']
    processed = set()

    # Always process the primary target first
    process_file(primary_target)
    processed.add(os.path.basename(primary_target))

    # Check adjacent files
    for t in targets:
        if t not in processed:
            full_path = os.path.join(base_dir, t)
            if os.path.exists(full_path):
                # Check if it's a symlink to the primary target
                if os.path.realpath(full_path) == os.path.realpath(primary_target):
                    print(f"Skipping {t} (Symlink to primary target)")
                    continue
                
                process_file(full_path)
                processed.add(t)
