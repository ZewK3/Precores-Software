/**
 * API Client for noVNC File Transfer
 */
class FileTransferAPI {
  constructor(baseURL = '/api') {
    this.baseURL = baseURL;
    this.token = this.loadToken();
  }

  /**
   * Load token from sessionStorage
   */
  loadToken() {
    return sessionStorage.getItem('fileTransferToken');
  }

  /**
   * Save token to sessionStorage
   */
  saveToken(token) {
    this.token = token;
    sessionStorage.setItem('fileTransferToken', token);
  }

  /**
   * Get authentication headers
   */
  getHeaders() {
    const headers = {};
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  /**
   * Generate a new authentication token
   */
  async generateToken() {
    try {
      const response = await fetch(`${this.baseURL}/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.success && data.token) {
        this.saveToken(data.token);
        return data.token;
      }

      throw new Error('Failed to generate token');
    } catch (error) {
      console.error('Token generation error:', error);
      throw error;
    }
  }

  /**
   * Upload file with progress callback and chunked upload for large files
   * @param {File} file - The file to upload
   * @param {Function} onProgress - Progress callback (percent)
   * @returns {Promise} Upload result
   */
  async uploadFile(file, onProgress = null, relativePath = '') {
    try {
      // For files larger than 10MB, use chunked upload
      const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks

      if (file.size > 10 * 1024 * 1024) {
        return this.uploadFileChunked(file, onProgress);
      }

      // Regular upload for smaller files
      const formData = new FormData();
      formData.append('file', file);

      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        if (onProgress) {
          xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          });
        }

        // Load event
        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const response = JSON.parse(xhr.responseText);
              resolve(response);
            } catch (error) {
              reject(new Error('Invalid response format'));
            }
          } else {
            try {
              const error = JSON.parse(xhr.responseText);
              reject(new Error(error.error || 'Upload failed'));
            } catch (e) {
              reject(new Error(`Upload failed with status ${xhr.status}`));
            }
          }
        });

        // Error event
        xhr.addEventListener('error', () => {
          reject(new Error('Network error during upload'));
        });

        // Abort event
        xhr.addEventListener('abort', () => {
          reject(new Error('Upload cancelled'));
        });

        // Open and send request
        xhr.open('POST', `${this.baseURL}/upload`);
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
        if (relativePath) {
          xhr.setRequestHeader('x-relative-path', relativePath);
        }
        xhr.send(formData);
      });
    } catch (error) {
      console.error('Upload error:', error);
      throw error;
    }
  }

  /**
   * Upload large file in chunks (for files > 10MB)
   * @param {File} file - The file to upload
   * @param {Function} onProgress - Progress callback
   * @returns {Promise} Upload result
   */
  async uploadFileChunked(file, onProgress = null) {
    // For now, fall back to regular upload
    // TODO: Implement chunked upload with backend support
    return this.uploadFile(file, onProgress);
  }

  /**
   * Download file with progress callback and resume support
   * @param {string} filename - The filename to download
   * @param {Function} onProgress - Progress callback (percent)
   * @returns {Promise} Download result
   */
  async downloadFile(filename, onProgress = null) {
    try {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        if (onProgress) {
          xhr.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          });
        }

        // Load event
        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            // Create blob and download
            const blob = new Blob([xhr.response]);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename.split('/').pop(); // Get filename from path
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);

            resolve({ success: true, filename });
          } else {
            try {
              const error = JSON.parse(xhr.responseText);
              reject(new Error(error.error || 'Download failed'));
            } catch (e) {
              reject(new Error(`Download failed with status ${xhr.status}`));
            }
          }
        });

        // Error event
        xhr.addEventListener('error', () => {
          reject(new Error('Network error during download'));
        });

        // Sanitize path: remove leading slashes/double slashes
        const safeFilename = filename.replace(/^[\/\\]+/, '');

        // Open and send request with range support
        xhr.open('GET', `${this.baseURL}/download/${encodeURIComponent(safeFilename)}`);
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
        // Removed unsafe Accept-Encoding header
        xhr.responseType = 'blob';

        // Enable timeout for large files
        xhr.timeout = 300000; // 5 minutes

        xhr.send();
      });
    } catch (error) {
      console.error('Download error:', error);
      throw error;
    }
  }

  /**
   * List files in directory
   * @param {string} path - Directory path (optional)
   * @returns {Promise} File list
   */
  async listFiles(path = '') {
    try {
      const url = path
        ? `${this.baseURL}/files?path=${encodeURIComponent(path)}`
        : `${this.baseURL}/files`;

      const response = await fetch(url, {
        method: 'GET',
        headers: this.getHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to list files');
      }

      return data;
    } catch (error) {
      console.error('List files error:', error);
      throw error;
    }
  }

  /**
   * Delete file
   * @param {string} filename - The filename to delete
   * @returns {Promise} Delete result
   */
  async deleteFile(filename) {
    try {
      const response = await fetch(`${this.baseURL}/files/${encodeURIComponent(filename)}`, {
        method: 'DELETE',
        headers: this.getHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to delete file');
      }

      return data;
    } catch (error) {
      console.error('Delete file error:', error);
      throw error;
    }
  }

  /**
   * Check if API is available
   * @returns {Promise<boolean>}
   */
  async checkHealth() {
    try {
      // Use /api/health to ensure it passes through Cloudflare Tunnel 'api*' rule
      const response = await fetch(`${this.baseURL}/health`);
      if (!response.ok) return false;
      const data = await response.json();
      return data.status === 'ok';
    } catch (error) {
      // Quietly fail if API is not present or returns HTML (404 page)
      // console.debug('Health check failed (API likely unavailable):', error);
      return false;
    }
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileTransferAPI;
}
