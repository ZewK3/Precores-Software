/**
 * API Client for noVNC File Transfer
 */
class FileTransferAPI {
  constructor(baseURL = '/api') {
    this.baseURL = baseURL;
    this.token = this.loadToken();
  }

  /**
   * Load token from sessionStorage
   */
  loadToken() {
    return sessionStorage.getItem('fileTransferToken');
  }

  /**
   * Save token to sessionStorage
   */
  saveToken(token) {
    this.token = token;
    sessionStorage.setItem('fileTransferToken', token);
  }

  /**
   * Get authentication headers
   */
  getHeaders() {
    const headers = {};
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  /**
   * Generate a new authentication token
   */
  async generateToken() {
    try {
      const response = await fetch(`${this.baseURL}/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.success && data.token) {
        this.saveToken(data.token);
        return data.token;
      }

      throw new Error('Failed to generate token');
    } catch (error) {
      console.error('Token generation error:', error);
      throw error;
    }
  }

  /**
   * Upload file with progress callback and optimizations for images and large files
   * @param {File} file - The file to upload
   * @param {Function} onProgress - Progress callback (percent)
   * @param {string} relativePath - Relative path for folder uploads
   * @returns {Promise} Upload result
   */
  async uploadFile(file, onProgress = null, relativePath = '') {
    try {
      // Check if file is an image and optimize if needed
      if (file.type.startsWith('image/') && file.size > 1024 * 1024) {
        // Compress images larger than 1MB
        file = await this.compressImage(file);
      }

      // Use chunked upload for very large files (> 50MB)
      if (file.size > 50 * 1024 * 1024) {
        return this.uploadFileChunked(file, onProgress, relativePath);
      }

      // Regular upload for smaller files
      const formData = new FormData();
      formData.append('file', file);

      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        if (onProgress) {
          xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          });
        }

        // Load event
        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const response = JSON.parse(xhr.responseText);
              resolve(response);
            } catch (error) {
              reject(new Error('Invalid response format'));
            }
          } else {
            try {
              const error = JSON.parse(xhr.responseText);
              reject(new Error(error.error || 'Upload failed'));
            } catch (e) {
              reject(new Error(`Upload failed with status ${xhr.status}`));
            }
          }
        });

        // Error event
        xhr.addEventListener('error', () => {
          reject(new Error('Network error during upload'));
        });

        // Abort event
        xhr.addEventListener('abort', () => {
          reject(new Error('Upload cancelled'));
        });

        // Timeout for large files
        xhr.timeout = 600000; // 10 minutes

        // Open and send request
        xhr.open('POST', `${this.baseURL}/upload`);
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
        if (relativePath) {
          xhr.setRequestHeader('x-relative-path', relativePath);
        }
        xhr.send(formData);
      });
    } catch (error) {
      console.error('Upload error:', error);
      throw error;
    }
  }

  /**
   * Compress image before upload
   * @param {File} file - Image file to compress
   * @returns {Promise<File>} Compressed image file
   */
  async compressImage(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        const img = new Image();
        
        img.onload = () => {
          // Create canvas
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          // Calculate new dimensions (max 1920x1080 for large images)
          let width = img.width;
          let height = img.height;
          const maxDimension = 1920;
          
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = (height / width) * maxDimension;
              width = maxDimension;
            } else {
              width = (width / height) * maxDimension;
              height = maxDimension;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          
          // Draw and compress
          ctx.drawImage(img, 0, 0, width, height);
          
          // Convert to blob with quality 0.85
          canvas.toBlob((blob) => {
            if (blob) {
              // Create new file from blob
              const compressedFile = new File([blob], file.name, {
                type: file.type,
                lastModified: Date.now()
              });
              
              console.log(`Image compressed: ${(file.size / 1024 / 1024).toFixed(2)}MB -> ${(compressedFile.size / 1024 / 1024).toFixed(2)}MB`);
              resolve(compressedFile);
            } else {
              // If compression fails, use original
              resolve(file);
            }
          }, file.type, 0.85);
        };
        
        img.onerror = () => {
          // If image loading fails, use original file
          resolve(file);
        };
        
        img.src = e.target.result;
      };
      
      reader.onerror = () => {
        // If reading fails, use original file
        resolve(file);
      };
      
      reader.readAsDataURL(file);
    });
  }

  /**
   * Upload large file in chunks (for files > 50MB)
   * @param {File} file - The file to upload
   * @param {Function} onProgress - Progress callback
   * @param {string} relativePath - Relative path for folder uploads
   * @returns {Promise} Upload result
   */
  async uploadFileChunked(file, onProgress = null, relativePath = '') {
    const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks
    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
    let uploadedChunks = 0;

    try {
      // For now, use regular upload with increased timeout
      // TODO: Implement proper chunked upload with backend support
      console.log(`Large file detected (${(file.size / 1024 / 1024).toFixed(2)}MB), using extended timeout...`);
      
      const formData = new FormData();
      formData.append('file', file);

      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        if (onProgress) {
          xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          });
        }

        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const response = JSON.parse(xhr.responseText);
              resolve(response);
            } catch (error) {
              reject(new Error('Invalid response format'));
            }
          } else {
            try {
              const error = JSON.parse(xhr.responseText);
              reject(new Error(error.error || 'Upload failed'));
            } catch (e) {
              reject(new Error(`Upload failed with status ${xhr.status}`));
            }
          }
        });

        xhr.addEventListener('error', () => {
          reject(new Error('Network error during upload'));
        });

        // Extended timeout for large files (10 minutes)
        xhr.timeout = 600000;

        xhr.open('POST', `${this.baseURL}/upload`);
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
        if (relativePath) {
          xhr.setRequestHeader('x-relative-path', relativePath);
        }
        xhr.send(formData);
      });
    } catch (error) {
      console.error('Chunked upload error:', error);
      throw error;
    }
  }

  /**
   * Download file with progress callback and resume support
   * @param {string} filename - The filename to download
   * @param {Function} onProgress - Progress callback (percent)
   * @returns {Promise} Download result
   */
  async downloadFile(filename, onProgress = null) {
    try {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        if (onProgress) {
          xhr.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          });
        }

        // Load event
        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            // Create blob and download
            const blob = new Blob([xhr.response]);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename.split('/').pop(); // Get filename from path
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);

            resolve({ success: true, filename });
          } else {
            try {
              const error = JSON.parse(xhr.responseText);
              reject(new Error(error.error || 'Download failed'));
            } catch (e) {
              reject(new Error(`Download failed with status ${xhr.status}`));
            }
          }
        });

        // Error event
        xhr.addEventListener('error', () => {
          reject(new Error('Network error during download'));
        });

        // Sanitize path: remove leading slashes/double slashes
        const safeFilename = filename.replace(/^[\/\\]+/, '');

        // Open and send request with range support
        xhr.open('GET', `${this.baseURL}/download/${encodeURIComponent(safeFilename)}`);
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
        // Removed unsafe Accept-Encoding header
        xhr.responseType = 'blob';

        // Enable timeout for large files (10 minutes)
        xhr.timeout = 600000; // 10 minutes

        xhr.send();
      });
    } catch (error) {
      console.error('Download error:', error);
      throw error;
    }
  }

  /**
   * List files in directory
   * @param {string} path - Directory path (optional)
   * @returns {Promise} File list
   */
  async listFiles(path = '') {
    try {
      const url = path
        ? `${this.baseURL}/files?path=${encodeURIComponent(path)}`
        : `${this.baseURL}/files`;

      const response = await fetch(url, {
        method: 'GET',
        headers: this.getHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to list files');
      }

      return data;
    } catch (error) {
      console.error('List files error:', error);
      throw error;
    }
  }

  /**
   * Download folder as ZIP
   * @param {string} folderPath - The folder path to download
   * @param {Function} onProgress - Progress callback (percent)
   * @returns {Promise} Download result
   */
  async downloadFolder(folderPath, onProgress = null) {
    try {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Progress tracking
        if (onProgress) {
          xhr.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          });
        }

        // Load event
        xhr.addEventListener('load', () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            // Create blob and download
            const blob = new Blob([xhr.response], { type: 'application/zip' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const folderName = folderPath.split('/').pop() || 'download';
            a.download = `${folderName}.zip`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);

            resolve({ success: true, folderPath });
          } else {
            try {
              const error = JSON.parse(xhr.responseText);
              reject(new Error(error.error || 'Download failed'));
            } catch (e) {
              reject(new Error(`Download failed with status ${xhr.status}`));
            }
          }
        });

        // Error event
        xhr.addEventListener('error', () => {
          reject(new Error('Network error during download'));
        });

        // Sanitize path
        const safePath = folderPath.replace(/^[\/\\]+/, '');

        // Open and send request
        xhr.open('GET', `${this.baseURL}/download-folder/${encodeURIComponent(safePath)}`);
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
        xhr.responseType = 'blob';
        xhr.timeout = 600000; // 10 minutes

        xhr.send();
      });
    } catch (error) {
      console.error('Download folder error:', error);
      throw error;
    }
  }

  /**
   * Delete file
   * @param {string} filename - The filename to delete
   * @returns {Promise} Delete result
   */
  async deleteFile(filename) {
    try {
      const response = await fetch(`${this.baseURL}/files/${encodeURIComponent(filename)}`, {
        method: 'DELETE',
        headers: this.getHeaders()
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to delete file');
      }

      return data;
    } catch (error) {
      console.error('Delete file error:', error);
      throw error;
    }
  }

  /**
   * Check if API is available
   * @returns {Promise<boolean>}
   */
  async checkHealth() {
    try {
      // Use /api/health to ensure it passes through Cloudflare Tunnel 'api*' rule
      const response = await fetch(`${this.baseURL}/health`);
      if (!response.ok) return false;
      const data = await response.json();
      return data.status === 'ok';
    } catch (error) {
      // Quietly fail if API is not present or returns HTML (404 page)
      // console.debug('Health check failed (API likely unavailable):', error);
      return false;
    }
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileTransferAPI;
}
