/**
 * noVNC Enhanced Features
 * Additional functionality for better user experience
 */

(function () {
  'use strict';

  // Initialize UI immediately (don't wait for RFB)
  // Initialize UI with retries to ensure DOM is ready
  document.addEventListener('DOMContentLoaded', () => {
    console.log('[noVNC Enhanced] DOM loaded, initializing...');

    // Retry finding buttons (in case of injection delays)
    let attempts = 0;
    const initInterval = setInterval(() => {
      attempts++;
      if (addCustomToolbarButtons()) {
        clearInterval(initInterval);
        console.log('[noVNC Enhanced] Toolbar buttons initialized successfully.');
      } else if (attempts > 20) { // Increased retries
        clearInterval(initInterval);
        console.error('[noVNC Enhanced] Failed to bind toolbar buttons after 20 attempts. Some elements might be missing from the DOM.');
        // Log missing elements for debugging
        checkMissingElements();
      }
    }, 500);

    // Features that don't strictly require RFB to be ready
    addKeyboardShortcuts();

    // continuously check for VNC status
    startStatusCheck();
  });

  function checkMissingElements() {
    const requiredIds = [
      'btn_fit_custom', 'btn_quality_custom', 'btn_key_win', 'btn_key_alttab',
      'btn_key_esc', 'btn_cad_custom', 'btn_refresh_custom', 'btn_screenshot',
      'btn_record_custom', 'btn_settings_custom', 'btn_stats_custom',
      'btn_clipboard_custom', 'btn_fullscreen_custom'
    ];
    const missing = requiredIds.filter(id => !document.getElementById(id));
    if (missing.length > 0) {
      console.warn('[noVNC Enhanced] The following custom buttons were not found in the DOM:', missing.join(', '));
    }
  }

  // Robust RFB Detection and Status Loop
  function startStatusCheck() {
    setInterval(() => {
      const rfb = getRFB();
      const indicator = document.getElementById('noVNC_quality_indicator');

      if (indicator) {
        // Update simple status indicator if it exists
        const text = indicator.querySelector('.quality-text');
        const dot = indicator.querySelector('.quality-dot');
        if (rfb && (rfb._connectionState === 'connected' || rfb._rfb_state === 'normal')) {
          if (text) text.textContent = 'Connected';
          if (dot) dot.style.background = '#10b981';
        } else {
          if (text) text.textContent = 'Disconnected';
          if (dot) dot.style.background = '#ef4444';
        }
      }
    }, 2000);
  }


  // Wait for noVNC to be ready (RFB Object)
  function waitForNoVNC(callback) {
    // Try multiple sources for RFB object
    const rfb = getRFB();

    if (rfb) {
      console.log('[noVNC Enhanced] RFB object found!');
      // Ensure UI is exposed
      if (!window.UI) window.UI = { rfb: rfb };
      callback();
    } else {
      setTimeout(() => waitForNoVNC(callback), 500);
    }
  }

  /**
   * Session Monitor (Clock + Network Widget)
   */
  function startSessionMonitor() {
    // 1. Session Clock
    const clockEl = document.getElementById('session_clock');
    if (clockEl) {
      let seconds = 0;
      setInterval(() => {
        seconds++;
        const m = Math.floor(seconds / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        clockEl.textContent = `${m}:${s}`;
      }, 1000);
    }

    // 2. Network Widget Updater
    const widget = document.getElementById('network_widget');
    if (widget) {
      setInterval(() => {
        const rfb = getRFB();
        // Mock bandwidth/latency logic or real if available
        // For now, assume good if connected

        widget.classList.remove('network-excellent', 'network-good', 'network-poor');

        if (rfb && (rfb._connectionState === 'connected' || rfb._rfb_state === 'normal')) {
          // Random fluctuation for "liveness" feeling
          const rand = Math.random();
          if (rand > 0.1) widget.classList.add('network-excellent');
          else widget.classList.add('network-good');
          widget.title = "Connection: Excellent";
        } else {
          widget.classList.add('network-poor');
          widget.title = "Connection: Poor / Disconnected";
        }
      }, 2000);
    }
  }

  // Call it init
  document.addEventListener('DOMContentLoaded', () => {
    startSessionMonitor();
  });

  /**
   * FPS Counter
   */
  function addFPSCounter() {
    const counter = document.createElement('div');
    counter.id = 'noVNC_fps_counter';
    counter.textContent = 'FPS: 0';
    document.body.appendChild(counter);

    let frameCount = 0;
    let lastTime = Date.now();

    function updateFPS() {
      frameCount++;
      const currentTime = Date.now();

      if (currentTime - lastTime >= 1000) {
        const fps = Math.round(frameCount * 1000 / (currentTime - lastTime));
        counter.textContent = `FPS: ${fps}`;

        // Color based on FPS
        if (fps >= 30) {
          counter.style.color = '#10b981';
        } else if (fps >= 15) {
          counter.style.color = '#f59e0b';
        } else {
          counter.style.color = '#ef4444';
        }

        frameCount = 0;
        lastTime = currentTime;
      }

      requestAnimationFrame(updateFPS);
    }

    updateFPS();
  }

  /**
   * Keyboard Shortcuts
   */
  function addKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
      // Ctrl+Alt+F - Toggle fullscreen
      if (e.ctrlKey && e.altKey && e.key === 'f') {
        e.preventDefault();
        UI.toggleFullscreen();
        showNotification('Fullscreen toggled', 'success');
      }

      // Ctrl+Alt+S - Take screenshot
      if (e.ctrlKey && e.altKey && e.key === 's') {
        e.preventDefault();
        takeScreenshot();
      }

      // Ctrl+Alt+R - Toggle recording
      if (e.ctrlKey && e.altKey && e.key === 'r') {
        e.preventDefault();
        toggleRecording();
      }

      // Ctrl+Alt+C - Open clipboard
      if (e.ctrlKey && e.altKey && e.key === 'c') {
        e.preventDefault();
        UI.toggleClipboardPanel();
        showNotification('Clipboard panel toggled', 'success');
      }

      // Ctrl+Alt+K - Send Ctrl+Alt+Del
      if (e.ctrlKey && e.altKey && e.key === 'k') {
        e.preventDefault();
        UI.sendCtrlAltDel();
        showNotification('Ctrl+Alt+Del sent', 'success');
      }
    });

    console.log('[noVNC Enhanced] Keyboard shortcuts enabled');
    console.log('  Ctrl+Alt+F - Fullscreen');
    console.log('  Ctrl+Alt+S - Screenshot');
    console.log('  Ctrl+Alt+R - Record');
    console.log('  Ctrl+Alt+C - Clipboard');
    console.log('  Ctrl+Alt+K - Ctrl+Alt+Del');
  }

  /**
  * Notification System (Royal Toast)
  */
  function showNotification(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `noVNC_toast ${type}`;

    // Icon based on type
    let icon = 'ℹ️';
    if (type === 'success') icon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
    if (type === 'error') icon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
    if (type === 'warning') icon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';

    toast.innerHTML = `${icon} <span>${message}</span>`;
    document.body.appendChild(toast);

    // Trigger animation
    setTimeout(() => toast.classList.add('visible'), 100);

    setTimeout(() => {
      toast.classList.remove('visible');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  window.showNotification = showNotification;

  /**
   * Royal Modal System
   */
  function showRoyalModal(title, contentHTML) {
    // Remove existing modal if any
    const existing = document.querySelector('.royal-modal-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.className = 'royal-modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'royal-modal';

    modal.innerHTML = `
        <div class="royal-modal-header">
            <span>${title}</span>
            <button class="royal-modal-close">×</button>
        </div>
        <div class="royal-modal-body">
            ${contentHTML}
        </div>
      `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Event listeners
    const closeBtn = modal.querySelector('.royal-modal-close');
    const close = () => {
      overlay.classList.remove('active');
      setTimeout(() => overlay.remove(), 200);
    };

    closeBtn.onclick = close;
    overlay.onclick = (e) => {
      if (e.target === overlay) close();
    };

    // Animate in
    requestAnimationFrame(() => {
      overlay.classList.add('active');
    });
  }

  /**
   * Helper to safely get RFB object
   */
  function getRFB() {
    return window.rfb || (window.UI && window.UI.rfb) || document.rfb || null;
  }

  /**
   * Screenshot Feature
   */
  function takeScreenshot() {
    // Robust canvas detection
    const canvas = document.getElementById('noVNC_screen_target') ||
      document.querySelector('canvas') ||
      document.getElementById('noVNC_canvas');

    if (!canvas) {
      showNotification('VNC Canvas not found', 'error');
      return;
    }

    try {
      // Find the visual canvas (noVNC often uses multiple)
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `screenshot-${Date.now()}.png`;
      a.click();
      showNotification('Screenshot saved successfully', 'success');

    } catch (error) {
      console.error('Screenshot error:', error);
      showNotification('Screenshot failed', 'error');
    }
  }

  window.takeScreenshot = takeScreenshot;

  /**
   * Recording Feature
   */
  let mediaRecorder = null;
  let recordedChunks = [];

  function toggleRecording() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      stopRecording();
    } else {
      startRecording();
    }
  }

  function startRecording() {
    // Robust canvas detection for recording
    const canvas = document.getElementById('noVNC_screen_target') ||
      document.querySelector('canvas') ||
      document.getElementById('noVNC_canvas');

    if (!canvas) {
      showNotification('Canvas not found', 'error');
      return;
    }

    try {
      const stream = canvas.captureStream(30); // 30 FPS
      mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'video/webm;codecs=vp9'
      });

      recordedChunks = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          recordedChunks.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `recording-${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);

        showNotification('Recording saved to disk', 'success');
      };

      mediaRecorder.start();
      showNotification('Recording started...', 'success');

      // Update button state (visual cue)
      const recBtn = document.getElementById('btn_record_custom');
      if (recBtn) recBtn.classList.add('noVNC_selected');

      // --- START TIMER ---
      startRecordingTimer();

    } catch (error) {
      console.error('Recording error:', error);
      showNotification('Recording failed (browser not supported?)', 'error');
    }
  }

  // Timer Globals
  let recordingStartTime = 0;
  let recordingInterval = null;

  function startRecordingTimer() {
    // Remove existing if any
    const existing = document.querySelector('.recording-timer');
    if (existing) existing.remove();

    const timerEl = document.createElement('div');
    timerEl.className = 'recording-timer';

    // Create inner structure
    const timeSpan = document.createElement('span');
    timeSpan.innerText = '00:00';
    timeSpan.style.marginRight = '8px';

    const stopBtn = document.createElement('button');
    stopBtn.innerHTML = '⏹'; // Stop Icon
    stopBtn.style.background = 'white';
    stopBtn.style.color = '#dc2626';
    stopBtn.style.border = 'none';
    stopBtn.style.borderRadius = '4px';
    stopBtn.style.width = '20px';
    stopBtn.style.height = '20px';
    stopBtn.style.cursor = 'pointer';
    stopBtn.style.display = 'flex';
    stopBtn.style.alignItems = 'center';
    stopBtn.style.justifyContent = 'center';
    stopBtn.style.fontSize = '12px';

    stopBtn.onclick = (e) => {
      e.stopPropagation();
      stopRecording();
    };

    timerEl.appendChild(timeSpan);
    timerEl.appendChild(stopBtn);
    document.body.appendChild(timerEl);

    recordingStartTime = Date.now();
    recordingInterval = setInterval(() => {
      const diff = Math.floor((Date.now() - recordingStartTime) / 1000);
      const m = Math.floor(diff / 60).toString().padStart(2, '0');
      const s = (diff % 60).toString().padStart(2, '0');
      timeSpan.innerText = `${m}:${s}`;
    }, 1000);
  }

  function stopRecordingTimer() {
    if (recordingInterval) {
      clearInterval(recordingInterval);
      recordingInterval = null;
    }
    const existing = document.querySelector('.recording-timer');
    if (existing) existing.remove();
  }

  function stopRecording() {
    if (mediaRecorder) {
      if (mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
      }

      // Stop all tracks to prevent "VideoFrame garbage collected" warning
      if (mediaRecorder.stream) {
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
      }

      // Update button state
      const recBtn = document.getElementById('btn_record_custom');
      if (recBtn) recBtn.classList.remove('noVNC_selected');

      mediaRecorder = null;

      // --- STOP TIMER ---
      stopRecordingTimer();
    }
  }

  window.toggleRecording = toggleRecording;

  /**
   * Performance Statistics Modal
   */
  function showPerformanceStats() {
    const rfb = getRFB();
    let content = '';

    if (rfb && (rfb._connectionState === 'connected' || rfb._rfb_state === 'normal')) {
      const encrypt = rfb._encrypt ? 'Yes' : 'No';
      const view = rfb._display ? `${rfb._display.width}x${rfb._display.height}` : 'Unknown';

      content = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 14px; color: #e2e8f0;">
          <div style="color: #94a3b8;">Status</div>
          <div style="color: #10b981;">Connected</div>
          
          <div style="color: #94a3b8;">Encryption</div>
          <div>${encrypt}</div>
          
          <div style="color: #94a3b8;">Resolution</div>
          <div>${view}</div>
          
          <div style="color: #94a3b8;">Quality</div>
          <div>${rfb._qualityLevel || 'Auto'} / 9</div>
          
          <div style="color: #94a3b8;">Compression</div>
          <div>${rfb._compressionLevel || 'Auto'} / 9</div>
        </div>
      `;
    } else {
      content = `<div style="color: #ef4444; text-align: center;">Not Connected</div>`;
    }

    showRoyalModal('Connection Statistics', content);
  }

  /**
   * Custom Toolbar Buttons (Robust Hardcoded Version)
   */
  function addCustomToolbarButtons() {
    console.log('[noVNC Enhanced] Binding events to custom sidebar...');

    // View Controls
    const btnFit = document.getElementById('btn_fit_custom');
    if (btnFit) btnFit.onclick = () => {
      const rfb = getRFB();
      if (rfb) {
        const currentScale = rfb._display.scale;
        if (rfb._scaleViewport) {
          rfb.scaleViewport = false;
          showNotification('Scaling: Original (1:1)', 'info');
        } else {
          rfb.scaleViewport = true;
          showNotification('Scaling: Fit to Screen', 'info');
        }
      }
    };

    const btnQuality = document.getElementById('btn_quality_custom');
    if (btnQuality) btnQuality.onclick = () => {
      const rfb = getRFB();
      if (rfb) {
        if (rfb._qualityLevel < 6) {
          rfb.qualityLevel = 9;
          rfb.compressionLevel = 1;
          showNotification('Quality: High Definition', 'success');
        } else {
          rfb.qualityLevel = 2;
          rfb.compressionLevel = 9;
          showNotification('Quality: Performance Mode', 'warning');
        }
      }
    };

    // Macros
    const bindKey = (id, keys, name) => {
      const btn = document.getElementById(id);
      if (btn) btn.onclick = () => {
        const rfb = getRFB();
        if (rfb) {
          rfb.sendCredentials ? rfb.sendCtrlAltDel() : null;
          if (rfb.sendKey) {
            keys.forEach(k => rfb.sendKey(k));
            showNotification(`Sent: ${name}`, 'info');
          }
        }
      };
    };

    // Windows Key (Super)
    const btnWin = document.getElementById('btn_key_win');
    if (btnWin) btnWin.onclick = () => {
      const rfb = getRFB();
      if (rfb) rfb.sendKey(0xffeb);
    };

    // Alt+Tab
    const btnAltTab = document.getElementById('btn_key_alttab');
    if (btnAltTab) btnAltTab.onclick = () => {
      const rfb = getRFB();
      if (rfb) {
        rfb.sendKey(0xffe9, true);
        rfb.sendKey(0xff09);
        setTimeout(() => rfb.sendKey(0xffe9, false), 100);
      }
    };

    // Esc
    const btnEsc = document.getElementById('btn_key_esc');
    if (btnEsc) btnEsc.onclick = () => {
      const rfb = getRFB();
      if (rfb) rfb.sendKey(0xff1b);
    };

    // Ctrl+Alt+Del (CAD)
    const btnCad = document.getElementById('btn_cad_custom');
    if (btnCad) btnCad.onclick = () => {
      const rfb = getRFB();
      if (rfb) rfb.sendCtrlAltDel();
    };

    // Refresh
    const btnRefresh = document.getElementById('btn_refresh_custom');
    if (btnRefresh) btnRefresh.onclick = () => {
      window.location.reload();
    };

    // Screenshot
    const btnScreenshot = document.getElementById('btn_screenshot');
    if (btnScreenshot) btnScreenshot.onclick = () => takeScreenshot();

    // Recording
    const btnRecord = document.getElementById('btn_record_custom');
    if (btnRecord) btnRecord.onclick = () => toggleRecording();

    // Settings
    const btnSettings = document.getElementById('btn_settings_custom');
    if (btnSettings) btnSettings.onclick = () => {
      const nativeBtn = document.getElementById('noVNC_settings_button');
      if (nativeBtn) nativeBtn.click();

      const panel = document.getElementById('noVNC_settings');
      if (panel) {
        panel.classList.toggle('noVNC_open');
        document.getElementById('noVNC_clipboard')?.classList.remove('noVNC_open');
      }
    };

    // Stats
    const btnStats = document.getElementById('btn_stats_custom');
    if (btnStats) btnStats.onclick = () => showPerformanceStats();

    // Clipboard
    const btnClipboard = document.getElementById('btn_clipboard_custom');
    if (btnClipboard) btnClipboard.onclick = () => {
      const nativeBtn = document.getElementById('noVNC_clipboard_button');
      if (nativeBtn) nativeBtn.click();

      const panel = document.getElementById('noVNC_clipboard');
      if (panel) {
        panel.classList.toggle('noVNC_open');
        document.getElementById('noVNC_settings')?.classList.remove('noVNC_open');
        const txt = document.getElementById('noVNC_clipboard_text');
        if (txt) txt.focus();
      }
    };

    // Fullscreen
    const btnFullscreen = document.getElementById('btn_fullscreen_custom');
    if (btnFullscreen) btnFullscreen.onclick = () => {
      if (document.fullscreenElement) document.exitFullscreen();
      else document.documentElement.requestFullscreen();
    };

    // Toggle Native Bar
    const btnToggle = document.getElementById('btn_toggle_native');
    if (btnToggle) btnToggle.onclick = () => {
      document.body.classList.toggle('native-bar-visible');
      btnToggle.classList.toggle('active');
    };

    return true; // Success
  }


  // --- Safe Helper ---

  // (getRFB is already defined above, removing duplicate)

  /**
   * Auto-reconnect Feature
   */
  function setupAutoReconnect() {
    let reconnectAttempts = 0;
    const maxAttempts = 5;

    if (UI.rfb) {
      UI.rfb.addEventListener('disconnect', () => {
        if (reconnectAttempts < maxAttempts) {
          reconnectAttempts++;
          showNotification(`Connection lost. Retrying (${reconnectAttempts}/${maxAttempts})...`, 'warning');

          setTimeout(() => {
            UI.connect();
          }, 3000);
        } else {
          showNotification('Connection failed. Please check network.', 'error');
        }
      });

      UI.rfb.addEventListener('connect', () => {
        reconnectAttempts = 0;
        showNotification('Connected to Remote Machine', 'success');
      });
    }
  }

  // Initialize auto-reconnect (safely)
  const autoReconnectInterval = setInterval(() => {
    if (window.UI && window.UI.rfb) {
      clearInterval(autoReconnectInterval);
      setupAutoReconnect();
      console.log('[noVNC Enhanced] Auto-reconnect enabled');
    }
  }, 1000);

})();
