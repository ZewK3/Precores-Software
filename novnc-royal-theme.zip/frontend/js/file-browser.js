/**
 * File Browser Component
 */
class FileBrowser {
  constructor(apiClient, containerId, options = {}) {
    this.apiClient = apiClient;
    this.container = document.getElementById(containerId);
    this.currentPath = '';
    this.files = [];
    this.searchQuery = '';
    this.onFileSelect = null;
    this.extraButtons = options.extraButtons || []; // Array of { id, icon, label, onClick }
  }

  /**
   * Initialize the file browser
   */
  async init() {
    await this.loadFiles(this.currentPath);
  }

  /**
   * Load files from directory
   */
  async loadFiles(path = '') {
    try {
      const response = await this.apiClient.listFiles(path);

      if (response.success) {
        this.currentPath = response.path;
        this.files = response.files;
        this.render();
      }
    } catch (error) {
      console.error('Failed to load files:', error);
      this.showError('Failed to load files: ' + error.message);
    }
  }

  /**
   * Navigate to folder
   */
  async navigateToFolder(folderName) {
    const newPath = this.currentPath
      ? `${this.currentPath}/${folderName}`
      : folderName;

    await this.loadFiles(newPath);
  }

  /**
   * Go back to parent directory
   */
  async goBack() {
    if (!this.currentPath) return;

    const parts = this.currentPath.split('/');
    parts.pop();
    const parentPath = parts.join('/');

    await this.loadFiles(parentPath);
  }

  /**
   * Filter files by search query
   */
  filterFiles() {
    if (!this.searchQuery) {
      return this.files;
    }

    const query = this.searchQuery.toLowerCase();
    return this.files.filter(file =>
      file.name.toLowerCase().includes(query)
    );
  }

  /**
   * Format file size
   */
  formatSize(bytes) {
    if (bytes === 0) return '-';

    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + units[i];
  }

  /**
   * Format date
   */
  formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
  }

  /**
   * Render the file browser
   */
  render() {
    if (!this.container) return;

    const filteredFiles = this.filterFiles();

    this.container.innerHTML = `
      <div class="file-browser">
        <div class="browser-toolbar">
          <button class="btn-icon-back" ${!this.currentPath ? 'disabled' : ''} title="Go Up" style="padding: 6px 10px; margin-right: 5px; cursor: pointer;">
            ⬆
          </button>
          
          <div class="path-display" style="flex-grow: 1; margin: 0 10px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; color: #94a3b8; font-family: monospace;">
            <span class="path-text">${this.currentPath || '/'}</span>
          </div>

          <!-- Custom Buttons (Upload/Folder) -->
          <div class="custom-buttons" style="display: flex; gap: 5px; margin-right: 10px;">
             ${this.extraButtons.map(btn => `
               <button id="${btn.id}" class="btn-compact-custom" title="${btn.title || btn.label}" style="padding: 6px 12px; background: #334155; border: 1px solid #475569; border-radius: 6px; color: #fff; cursor: pointer; display: flex; align-items: center; gap: 6px; font-size: 13px;">
                  <span>${btn.icon}</span> <span class="btn-label-text">${btn.label}</span>
               </button>
             `).join('')}
          </div>

          <div class="search-compact">
             <input 
                type="text" 
                class="search-input-compact" 
                placeholder="🔍 Search..."
                value="${this.searchQuery}"
                style="padding: 6px 10px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #fff;"
             />
          </div>
        </div>
        
        <div class="file-list compact-list">
          ${filteredFiles.length === 0 ? `
            <div class="empty-state">
              <p>No files found</p>
            </div>
          ` : filteredFiles.map(file => this.renderFileItem(file)).join('')}
        </div>
      </div>
    `;

    this.attachEventListeners();
  }

  /**
   * Render a single file item
   */
  renderFileItem(file) {
    const icon = file.type === 'directory' ? '📁' : '📄';
    const action = file.type === 'directory'
      ? `<button class="btn-navigate" data-name="${file.name}">→</button>`
      : `<button class="btn-download" data-name="${file.name}">⬇️</button>`;

    return `
      <div class="file-item" data-type="${file.type}">
        <span class="file-icon">${icon}</span>
        <span class="file-name">${file.name}</span>
        <span class="file-size">${this.formatSize(file.size)}</span>
        <span class="file-date">${this.formatDate(file.modified)}</span>
        <span class="file-actions">${action}</span>
      </div>
    `;
  }

  /**
   * Attach event listeners
   */
  attachEventListeners() {
    // Back button
    const backBtn = this.container.querySelector('.btn-icon-back');
    if (backBtn) {
      backBtn.addEventListener('click', () => this.goBack());
    }

    // Search input
    const searchInput = this.container.querySelector('.search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value;
        this.render();
      });
    }

    // Navigate buttons
    const navigateBtns = this.container.querySelectorAll('.btn-navigate');
    navigateBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const folderName = btn.getAttribute('data-name');
        this.navigateToFolder(folderName);
      });
    });

    // Download buttons
    const downloadBtns = this.container.querySelectorAll('.btn-download');
    downloadBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const filename = btn.getAttribute('data-name');
        this.selectFile(filename);
      });
    });

    // Custom Buttons Events
    this.extraButtons.forEach(btn => {
      const el = document.getElementById(btn.id);
      if (el && btn.onClick) {
        el.addEventListener('click', (e) => {
          e.preventDefault();
          btn.onClick(e);
        });
      }
    });
  }

  /**
   * Select a file (trigger callback)
   */
  selectFile(filename) {
    // Clean current path: remove trailing slash if present (except if it is just root /)
    let basePath = this.currentPath;
    if (basePath && basePath.endsWith('/') && basePath.length > 1) {
      basePath = basePath.slice(0, -1);
    }
    // If root '/', treat as empty to avoid '//file'
    if (basePath === '/') basePath = '';

    const fullPath = basePath
      ? `${basePath}/${filename}`
      : filename;

    if (this.onFileSelect) {
      this.onFileSelect(fullPath, filename);
    }
  }

  /**
   * Show error message
   */
  showError(message) {
    if (!this.container) return;

    this.container.innerHTML = `
      <div class="error-message">
        <p>❌ ${message}</p>
        <button class="btn-retry">Retry</button>
      </div>
    `;

    const retryBtn = this.container.querySelector('.btn-retry');
    if (retryBtn) {
      retryBtn.addEventListener('click', () => this.loadFiles(this.currentPath));
    }
  }

  /**
   * Set file select callback
   */
  setOnFileSelect(callback) {
    this.onFileSelect = callback;
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileBrowser;
}
