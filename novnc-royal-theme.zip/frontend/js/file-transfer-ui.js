/**
 * File Transfer UI Integration for noVNC
 */
class FileTransferUI {
  constructor(rfb, apiBaseURL = 'http://localhost:8080/api') {
    this.rfb = rfb;
    this.apiClient = new FileTransferAPI(apiBaseURL);
    this.modal = null;
    this.initialized = false;
  }

  /**
   * Initialize the file transfer UI
   */
  async init() {
    if (this.initialized) return;

    try {
      // Check if API is available
      const isHealthy = await this.apiClient.checkHealth();
      if (!isHealthy) {
        console.warn('File transfer API is not available');
        return;
      }

      // Generate authentication token
      await this.apiClient.generateToken();

      // Add buttons to toolbar
      this.addToolbarButtons();

      // Create modal
      this.modal = new FileTransferModal(this.apiClient);

      this.initialized = true;
      console.log('File transfer UI initialized');

    } catch (error) {
      console.error('Failed to initialize file transfer UI:', error);
    }
  }

  /**
   * Bind events to existing toolbar buttons
   */
  addToolbarButtons() {
    console.log('[FileTransfer] Binding events to sidebar buttons...');

    // Upload Button
    const uploadBtn = document.getElementById('btn_upload');
    if (uploadBtn) {
      uploadBtn.onclick = () => this.showUploadDialog();
    } else {
      console.warn('[FileTransfer] Upload button not found in DOM');
    }

    // Download Button
    const downloadBtn = document.getElementById('btn_download');
    if (downloadBtn) {
      downloadBtn.onclick = () => this.showDownloadDialog();
    } else {
      console.warn('[FileTransfer] Download button not found in DOM');
    }
  }

  // createButton and createStandaloneButtons methods removed


  /**
   * Show upload dialog
   */
  showUploadDialog() {
    if (!this.modal) {
      console.error('Modal not initialized');
      return;
    }

    this.modal.show();
    this.modal.switchTab('browser');

    // Trigger file input click
    setTimeout(() => {
      const fileInput = document.getElementById('fileInput');
      if (fileInput) {
        fileInput.click();
      }
    }, 100);
  }

  /**
   * Show download dialog (file browser)
   */
  showDownloadDialog() {
    if (!this.modal) {
      console.error('Modal not initialized');
      return;
    }

    this.modal.show();
    this.modal.switchTab('browser');
  }

  /**
   * Show transfer history
   */
  showHistory() {
    if (!this.modal) {
      console.error('Modal not initialized');
      return;
    }

    this.modal.show();
    this.modal.switchTab('history');
  }

  /**
   * Cleanup
   */
  destroy() {
    if (this.modal) {
      this.modal.hide();
    }
    this.initialized = false;
  }
}

// Auto-initialize when noVNC connects
if (typeof window !== 'undefined') {
  window.FileTransferUI = FileTransferUI;

  // Try to auto-initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initFileTransfer();
    });
  } else {
    initFileTransfer();
  }
}

/**
 * Initialize file transfer when noVNC is ready
 */
/**
 * Initialize file transfer when DOM is ready
 */
function initFileTransfer() {
  console.log('[FileTransfer] Initializing...');

  // Get API URL
  const apiURL = window.FILE_TRANSFER_API_URL || '/api';

  // Initialize immediately without waiting for RFB
  // Pass null for RFB initially - it's mostly used for reference/session context if needed later
  const rfb = window.rfb || window.UI?.rfb || null;
  const fileTransferUI = new FileTransferUI(rfb, apiURL);

  // logic to keep looking for RFB if it's missing, just in case
  if (!rfb) {
    console.log('[FileTransfer] RFB not found yet, starting background watcher...');
    const rfbWatcher = setInterval(() => {
      const foundRfb = window.rfb || window.UI?.rfb;
      if (foundRfb) {
        fileTransferUI.rfb = foundRfb;
        console.log('[FileTransfer] RFB linked successfully.');
        clearInterval(rfbWatcher);
      }
    }, 1000);
  }

  fileTransferUI.init();
  window.fileTransferUI = fileTransferUI;
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileTransferUI;
}
