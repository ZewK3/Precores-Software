/**
 * File Transfer Modal Component
 */
class FileTransferModal {
  constructor(apiClient) {
    this.apiClient = apiClient;
    this.modal = null;
    this.fileBrowser = null;
    this.transferHistory = [];
    this.currentTab = 'browser'; // 'browser' or 'history'
    this.currentTransfer = null;
  }

  /**
   * Create and show the modal
   */
  show() {
    if (this.modal) {
      this.modal.style.display = 'flex';
      return;
    }

    this.createModal();
    this.modal.style.display = 'flex';

    // Initialize file browser
    if (this.currentTab === 'browser') {
      this.initFileBrowser();
    }
  }

  /**
   * Hide the modal
   */
  hide() {
    if (this.modal) {
      this.modal.style.display = 'none';
    }
  }

  /**
   * Create modal HTML structure
   */
  createModal() {
    const modalHTML = `
      <div class="file-transfer-modal" id="fileTransferModal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>File Transfer</h2>
            <button class="btn-close" id="modalClose">✕</button>
          </div>
          
          <div class="modal-tabs">
            <button class="tab-btn active" data-tab="browser">Browse Files</button>
            <button class="tab-btn" data-tab="history">Transfer History</button>
          </div>
          
          <div class="modal-body">
            <div class="tab-content active" id="browserTab">
              <div class="ft-actions-toolbar">
                  <div class="upload-group">
                    <input type="file" id="fileInput" style="display: none;" />
                    <input type="file" id="folderInput" webkitdirectory directory style="display: none;" />
                    <button class="btn-compact-upload" id="btnSelectFile" title="Upload File">
                       📄 Upload
                    </button>
                    <button class="btn-compact-upload btn-folder" id="btnSelectFolder" title="Upload Folder">
                       📁 Folder
                    </button>
                  </div>
              </div>
              <div id="fileBrowserContainer"></div>
            </div>
            
            <div class="tab-content" id="historyTab">
              <div id="transferHistoryContainer"></div>
            </div>
          </div>
          
          <div class="progress-section" id="progressSection" style="display: none;">
            <div class="progress-info">
              <span id="progressText">Uploading...</span>
              <span id="progressPercent">0%</span>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" id="progressFill"></div>
            </div>
          </div>
          
          <div class="notification" id="notification" style="display: none;"></div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);
    this.modal = document.getElementById('fileTransferModal');

    this.attachEventListeners();
  }

  /**
   * Attach event listeners
   */
  attachEventListeners() {
    // Close button
    const closeBtn = document.getElementById('modalClose');
    closeBtn.addEventListener('click', () => this.hide());

    // Click outside to close
    this.modal.addEventListener('click', (e) => {
      if (e.target === this.modal) {
        this.hide();
      }
    });

    // Tab buttons
    const tabBtns = this.modal.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-tab');
        this.switchTab(tab);
      });
    });

    // Upload buttons
    const uploadBtn = document.getElementById('btnSelectFile');
    const folderBtn = document.getElementById('btnSelectFolder');
    const fileInput = document.getElementById('fileInput');
    const folderInput = document.getElementById('folderInput');

    if (uploadBtn) uploadBtn.addEventListener('click', () => fileInput.click());
    if (folderBtn) folderBtn.addEventListener('click', () => folderInput.click());

    // Single File
    fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        this.uploadFile(e.target.files[0]);
      }
    });

    // Folder (Recursive)
    folderInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        this.uploadBatch(e.target.files);
      }
    });
  }

  /**
   * Switch between tabs
   */
  switchTab(tab) {
    this.currentTab = tab;

    // Update tab buttons
    const tabBtns = this.modal.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
      if (btn.getAttribute('data-tab') === tab) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Update tab content
    const browserTab = document.getElementById('browserTab');
    const historyTab = document.getElementById('historyTab');

    if (tab === 'browser') {
      browserTab.classList.add('active');
      historyTab.classList.remove('active');
      this.initFileBrowser();
    } else {
      browserTab.classList.remove('active');
      historyTab.classList.add('active');
      this.renderHistory();
    }
  }

  /**
   * Initialize file browser
   */
  initFileBrowser() {
    if (!this.fileBrowser) {
      this.fileBrowser = new FileBrowser(this.apiClient, 'fileBrowserContainer');
      this.fileBrowser.setOnFileSelect((fullPath, filename) => {
        this.downloadFile(fullPath, filename);
      });
      this.fileBrowser.init();
    }
  }

  /**
   * Upload Batch (Folder)
   */
  async uploadBatch(files) {
    const total = files.length;
    let completed = 0;
    let failed = 0;

    this.showProgress(`Uploading Folder (${total} files)`, 'Starting...');

    for (let i = 0; i < total; i++) {
      const file = files[i];
      const relativePath = file.webkitRelativePath || file.name;

      this.updateProgress(Math.round((i / total) * 100));
      document.getElementById('progressText').textContent = `Uploading ${i + 1}/${total}: ${file.name}`;

      try {
        await this.apiClient.uploadFile(file, null, relativePath);
        completed++;
        // Don't flood history with every file, maybe just summary? 
        // Or just add to history silently? 
        // For now, let's add individual entries but maybe limit UI repaint?
        this.addToHistory({
          type: 'upload',
          filename: relativePath,
          size: file.size,
          status: 'success',
          timestamp: new Date().toISOString()
        });
      } catch (err) {
        failed++;
        this.addToHistory({
          type: 'upload',
          filename: relativePath,
          size: file.size,
          status: 'failed',
          error: err.message,
          timestamp: new Date().toISOString()
        });
      }
    }

    this.hideProgress();
    this.showNotification(`Upload Complete: ${completed} success, ${failed} failed`, failed > 0 ? 'warning' : 'success');

    // Refresh browser
    if (this.fileBrowser) {
      this.fileBrowser.loadFiles(this.fileBrowser.currentPath);
    }

    // Reset inputs
    document.getElementById('folderInput').value = '';
  }

  /**
   * Upload file
   */
  async uploadFile(file) {
    try {
      this.showProgress('Uploading', file.name);

      const result = await this.apiClient.uploadFile(file, (percent) => {
        this.updateProgress(percent);
      });

      this.hideProgress();
      this.showNotification('✅ Upload successful: ' + file.name, 'success');

      // Add to history
      this.addToHistory({
        type: 'upload',
        filename: file.name,
        size: file.size,
        status: 'success',
        timestamp: new Date().toISOString()
      });

      // Refresh file browser
      if (this.fileBrowser) {
        this.fileBrowser.loadFiles(this.fileBrowser.currentPath);
      }

      // Reset file input
      document.getElementById('fileInput').value = '';

    } catch (error) {
      this.hideProgress();
      this.showNotification('❌ Upload failed: ' + error.message, 'error');

      this.addToHistory({
        type: 'upload',
        filename: file.name,
        size: file.size,
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * Download file
   */
  async downloadFile(fullPath, filename) {
    try {
      this.showProgress('Downloading', filename);

      await this.apiClient.downloadFile(fullPath, (percent) => {
        this.updateProgress(percent);
      });

      this.hideProgress();
      this.showNotification('✅ Download successful: ' + filename, 'success');

      this.addToHistory({
        type: 'download',
        filename: filename,
        status: 'success',
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      this.hideProgress();
      this.showNotification('❌ Download failed: ' + error.message, 'error');

      this.addToHistory({
        type: 'download',
        filename: filename,
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * Show progress bar
   */
  showProgress(action, filename) {
    const progressSection = document.getElementById('progressSection');
    const progressText = document.getElementById('progressText');

    progressText.textContent = `${action}: ${filename}`;
    progressSection.style.display = 'block';
    this.updateProgress(0);
  }

  /**
   * Update progress bar
   */
  updateProgress(percent) {
    const progressFill = document.getElementById('progressFill');
    const progressPercent = document.getElementById('progressPercent');

    progressFill.style.width = percent + '%';
    progressPercent.textContent = percent + '%';
  }

  /**
   * Hide progress bar
   */
  hideProgress() {
    const progressSection = document.getElementById('progressSection');
    progressSection.style.display = 'none';
  }

  /**
   * Show notification
   */
  showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';

    setTimeout(() => {
      notification.style.display = 'none';
    }, 5000);
  }

  /**
   * Add to transfer history
   */
  addToHistory(transfer) {
    this.transferHistory.unshift(transfer);

    // Keep only last 50 transfers
    if (this.transferHistory.length > 50) {
      this.transferHistory = this.transferHistory.slice(0, 50);
    }

    // Save to sessionStorage
    sessionStorage.setItem('transferHistory', JSON.stringify(this.transferHistory));
  }

  /**
   * Load history from sessionStorage
   */
  loadHistory() {
    const saved = sessionStorage.getItem('transferHistory');
    if (saved) {
      try {
        this.transferHistory = JSON.parse(saved);
      } catch (error) {
        console.error('Failed to load history:', error);
      }
    }
  }

  /**
   * Render transfer history
   */
  renderHistory() {
    this.loadHistory();

    const container = document.getElementById('transferHistoryContainer');

    if (this.transferHistory.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>No transfer history</p>
        </div>
      `;
      return;
    }

    const historyHTML = this.transferHistory.map(transfer => {
      const icon = transfer.type === 'upload' ? '⬆️' : '⬇️';
      const statusIcon = transfer.status === 'success' ? '✅' : '❌';
      const date = new Date(transfer.timestamp).toLocaleString();
      const size = transfer.size ? this.formatSize(transfer.size) : '-';

      return `
        <div class="history-item ${transfer.status}">
          <div class="history-icon">${icon}</div>
          <div class="history-details">
            <div class="history-filename">${transfer.filename}</div>
            <div class="history-meta">
              ${date} • ${size}
              ${transfer.error ? `<br><span class="error-text">${transfer.error}</span>` : ''}
            </div>
          </div>
          <div class="history-status">${statusIcon}</div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div class="history-list">
        ${historyHTML}
      </div>
      <button class="btn-clear-history" id="btnClearHistory">Clear History</button>
    `;

    // Clear history button
    const clearBtn = document.getElementById('btnClearHistory');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        this.clearHistory();
      });
    }
  }

  /**
   * Clear transfer history
   */
  clearHistory() {
    this.transferHistory = [];
    sessionStorage.removeItem('transferHistory');
    this.renderHistory();
    this.showNotification('History cleared', 'info');
  }

  /**
   * Format file size
   */
  formatSize(bytes) {
    if (!bytes) return '-';

    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + units[i];
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileTransferModal;
}
