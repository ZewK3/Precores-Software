/**
 * File Transfer Modal Component
 */
class FileTransferModal {
  constructor(apiClient) {
    this.apiClient = apiClient;
    this.modal = null;
    this.fileBrowser = null;
    this.transferHistory = [];
    this.currentTab = 'browser'; // 'browser' or 'history'
    this.currentTransfer = null;
  }

  /**
   * Create and show the modal
   */
  show() {
    if (this.modal) {
      this.modal.style.display = 'flex';
      return;
    }

    this.createModal();
    this.modal.style.display = 'flex';

    // Initialize file browser
    if (this.currentTab === 'browser') {
      this.initFileBrowser();
    }
  }

  /**
   * Hide the modal
   */
  hide() {
    if (this.modal) {
      this.modal.style.display = 'none';
    }
  }

  /**
   * Switch between tabs
   */
  switchTab(tabId) {
    this.currentTab = tabId;

    // Update buttons
    const btns = this.modal.querySelectorAll('.tab-btn');
    btns.forEach(btn => {
      if (btn.getAttribute('data-tab') === tabId) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Update content
    const contents = this.modal.querySelectorAll('.tab-content');
    contents.forEach(content => {
      if (content.id === `${tabId}Tab`) {
        content.classList.add('active');
        content.style.display = 'flex'; // Ensure flex for layout
      } else {
        content.classList.remove('active');
        content.style.display = 'none';
      }
    });

    // Show/Hide Upload buttons based on tab
    const tabActions = this.modal.querySelector('.tab-actions');
    if (tabActions) {
      if (tabId === 'browser') {
        tabActions.style.display = 'flex';
      } else {
        tabActions.style.display = 'none';
      }
    }

    // Initialize browser if switching to it
    if (tabId === 'browser') {
      this.initFileBrowser();
    } else if (tabId === 'history') {
      this.renderHistory();
    }
  }

  /**
   * Create modal HTML structure - Optimized Layout
   */
  createModal() {
    const modalHTML = `
      <div class="file-transfer-modal" id="fileTransferModal">
        <div class="modal-content">
          <div class="modal-header">
            <h2>📁 File Transfer</h2>
            <button class="btn-close" id="modalClose" title="Close">✕</button>
          </div>
          
          <div class="modal-tabs">
            <button class="tab-btn active" data-tab="browser">
              <span class="tab-icon">📂</span>
              <span class="tab-label">Browse Files</span>
            </button>
            <button class="tab-btn" data-tab="history">
              <span class="tab-icon">📋</span>
              <span class="tab-label">History</span>
            </button>
            <div class="tab-actions">
              <button class="btn-tab-action" id="btnQuickUpload" title="Upload File">
                <span>📄</span> Upload
              </button>
              <button class="btn-tab-action" id="btnQuickFolder" title="Upload Folder">
                <span>📁</span> Folder
              </button>
            </div>
          </div>
          
          <div class="modal-body">
            <div class="tab-content active" id="browserTab">
               <!-- Hidden Inputs -->
               <input type="file" id="fileInput" style="display: none;" />
               <input type="file" id="folderInput" webkitdirectory directory style="display: none;" />
               
               <!-- Browser Container -->
               <div id="fileBrowserContainer" style="display: flex; flex-direction: column; height: 100%;"></div>
            </div>
            
            <div class="tab-content" id="historyTab">
              <div id="transferHistoryContainer" class="history-container"></div>
            </div>
          </div>
          
          <div class="progress-section" id="progressSection" style="display: none;">
            <div class="progress-info">
              <span id="progressText">Uploading...</span>
              <span id="progressPercent">0%</span>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" id="progressFill"></div>
            </div>
          </div>
          
          <div class="notification" id="notification"></div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHTML);
    this.modal = document.getElementById('fileTransferModal');

    this.attachEventListeners();
  }

  // ... [EventListeners kept as is, but ensuring input logic is robust] ...

  /**
   * Add to transfer history
   */
  addToHistory(transfer) {
    this.transferHistory.unshift(transfer);

    // Keep only last 100 transfers
    if (this.transferHistory.length > 100) {
      this.transferHistory = this.transferHistory.slice(0, 100);
    }

    // Save to localStorage (persistent)
    localStorage.setItem('transferHistory', JSON.stringify(this.transferHistory));
  }

  /**
   * Load history from localStorage
   */
  loadHistory() {
    const saved = localStorage.getItem('transferHistory');
    if (saved) {
      try {
        this.transferHistory = JSON.parse(saved);
      } catch (error) {
        console.error('Failed to load history:', error);
        this.transferHistory = [];
      }
    }
  }

  /**
   * Render transfer history
   */
  renderHistory() {
    this.loadHistory();

    const container = document.getElementById('transferHistoryContainer');

    if (this.transferHistory.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="text-align: center; padding: 40px; color: #64748b;">
          <p>No transfer history yet</p>
        </div>
      `;
      return;
    }

    const rows = this.transferHistory.map(transfer => {
      const typeIcon = transfer.type === 'upload' ? '⬆️' : '⬇️';
      const statusClass = transfer.status === 'success' ? 'status-success' : 'status-failed';
      const statusLabel = transfer.status === 'success' ? 'Completed' : 'Failed';
      const date = new Date(transfer.timestamp).toLocaleString();
      const size = transfer.size ? this.formatSize(transfer.size) : '-';

      return `
        <tr>
          <td>${typeIcon} ${transfer.type.toUpperCase()}</td>
          <td>${transfer.filename}</td>
          <td>${size}</td>
          <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
          <td>${date}</td>
        </tr>
      `;
    }).join('');

    container.innerHTML = `
      <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
          <button id="btnClearHistory" style="background: transparent; border: 1px solid #ef4444; color: #ef4444; padding: 4px 12px; border-radius: 4px; cursor: pointer; font-size: 12px;">Clear History</button>
      </div>
      <table class="history-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Filename</th>
            <th>Size</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    `;

    // Clear history button
    const clearBtn = document.getElementById('btnClearHistory');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        this.clearHistory();
      });
    }
  }

  /**
   * Clear transfer history
   */
  clearHistory() {
    this.transferHistory = [];
    localStorage.removeItem('transferHistory');
    this.renderHistory();
    this.showNotification('History cleared', 'info');
  }

  /**
   * Format file size
   */
  formatSize(bytes) {
    if (!bytes && bytes !== 0) return '-';
    if (bytes === 0) return '0 B';

    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + units[i];
  }

  /**
   * Attach event listeners
   */
  attachEventListeners() {
    // Close button
    const closeBtn = document.getElementById('modalClose');
    closeBtn.addEventListener('click', () => this.hide());

    // Click outside to close
    this.modal.addEventListener('click', (e) => {
      if (e.target === this.modal) {
        this.hide();
      }
    });

    // Tab buttons
    const tabBtns = this.modal.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-tab');
        this.switchTab(tab);
      });
    });

    // Quick action buttons in tab bar
    const btnQuickUpload = document.getElementById('btnQuickUpload');
    const btnQuickFolder = document.getElementById('btnQuickFolder');
    
    if (btnQuickUpload) {
      btnQuickUpload.addEventListener('click', () => {
        document.getElementById('fileInput').click();
      });
    }
    
    if (btnQuickFolder) {
      btnQuickFolder.addEventListener('click', () => {
        document.getElementById('folderInput').click();
      });
    }

    // Inputs (Logic moved from buttons to direct input handling)
    const fileInput = document.getElementById('fileInput');
    const folderInput = document.getElementById('folderInput');

    // Single File
    fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        this.uploadFile(e.target.files[0]);
      }
    });

    // Folder (Recursive)
    folderInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        this.uploadBatch(e.target.files);
      }
    });
  }

  /**
   * Initialize file browser
   */
  initFileBrowser() {
    if (!this.fileBrowser) {
      // Define Custom Buttons for Toolbar
      const extraButtons = [
        {
          id: 'btnToolbarUpload',
          label: 'Upload',
          icon: '📄',
          title: 'Upload Single File',
          onClick: () => document.getElementById('fileInput').click()
        },
        {
          id: 'btnToolbarFolder',
          label: 'Folder',
          icon: '📁',
          title: 'Upload Recursive Folder',
          onClick: () => document.getElementById('folderInput').click()
        }
      ];

      this.fileBrowser = new FileBrowser(this.apiClient, 'fileBrowserContainer', { extraButtons });
      this.fileBrowser.setOnFileSelect((fullPath, filename) => {
        this.downloadFile(fullPath, filename);
      });
      this.fileBrowser.init();
    }
  }

  /**
   * Upload Batch (Folder)
   */
  async uploadBatch(files) {
    const total = files.length;
    let completed = 0;
    let failed = 0;

    this.showProgress(`Uploading Folder (${total} files)`, 'Starting...');

    for (let i = 0; i < total; i++) {
      const file = files[i];
      const relativePath = file.webkitRelativePath || file.name;

      this.updateProgress(Math.round((i / total) * 100));
      document.getElementById('progressText').textContent = `Uploading ${i + 1}/${total}: ${file.name}`;

      try {
        await this.apiClient.uploadFile(file, null, relativePath);
        completed++;
        // Don't flood history with every file, maybe just summary? 
        // Or just add to history silently? 
        // For now, let's add individual entries but maybe limit UI repaint?
        this.addToHistory({
          type: 'upload',
          filename: relativePath,
          size: file.size,
          status: 'success',
          timestamp: new Date().toISOString()
        });
      } catch (err) {
        failed++;
        this.addToHistory({
          type: 'upload',
          filename: relativePath,
          size: file.size,
          status: 'failed',
          error: err.message,
          timestamp: new Date().toISOString()
        });
      }
    }

    this.hideProgress();
    this.showNotification(`Upload Complete: ${completed} success, ${failed} failed`, failed > 0 ? 'warning' : 'success');

    // Refresh browser
    if (this.fileBrowser) {
      this.fileBrowser.loadFiles(this.fileBrowser.currentPath);
    }

    // Reset inputs
    document.getElementById('folderInput').value = '';
  }

  /**
   * Upload file
   */
  async uploadFile(file) {
    try {
      // Show file size info for large files
      const fileSizeMB = file.size / 1024 / 1024;
      if (fileSizeMB > 50) {
        this.showProgress('Uploading Large File', `${file.name} (${fileSizeMB.toFixed(2)}MB) - This may take a while...`);
      } else {
        this.showProgress('Uploading', file.name);
      }

      const result = await this.apiClient.uploadFile(file, (percent) => {
        this.updateProgress(percent);
      });

      this.hideProgress();
      
      // Show compression info if image was compressed
      if (file.type.startsWith('image/') && result.size < file.size) {
        const savedMB = ((file.size - result.size) / 1024 / 1024).toFixed(2);
        this.showNotification(`✅ Upload successful: ${file.name} (Saved ${savedMB}MB via compression)`, 'success');
      } else {
        this.showNotification('✅ Upload successful: ' + file.name, 'success');
      }

      // Add to history
      this.addToHistory({
        type: 'upload',
        filename: file.name,
        size: file.size,
        status: 'success',
        timestamp: new Date().toISOString()
      });

      // Refresh file browser
      if (this.fileBrowser) {
        this.fileBrowser.loadFiles(this.fileBrowser.currentPath);
      }

      // Reset file input
      document.getElementById('fileInput').value = '';

    } catch (error) {
      this.hideProgress();
      this.showNotification('❌ Upload failed: ' + error.message, 'error');

      this.addToHistory({
        type: 'upload',
        filename: file.name,
        size: file.size,
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * Download file
   */
  async downloadFile(fullPath, filename) {
    try {
      this.showProgress('Downloading', filename);

      await this.apiClient.downloadFile(fullPath, (percent) => {
        this.updateProgress(percent);
      });

      this.hideProgress();
      this.showNotification('✅ Download successful: ' + filename, 'success');

      this.addToHistory({
        type: 'download',
        filename: filename,
        status: 'success',
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      this.hideProgress();
      this.showNotification('❌ Download failed: ' + error.message, 'error');

      this.addToHistory({
        type: 'download',
        filename: filename,
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }

  /**
   * Show progress bar
   */
  showProgress(action, filename) {
    const progressSection = document.getElementById('progressSection');
    const progressText = document.getElementById('progressText');

    progressText.textContent = `${action}: ${filename}`;
    progressSection.style.display = 'block';
    this.updateProgress(0);
  }

  /**
   * Update progress bar
   */
  updateProgress(percent) {
    const progressFill = document.getElementById('progressFill');
    const progressPercent = document.getElementById('progressPercent');

    progressFill.style.width = percent + '%';
    progressPercent.textContent = percent + '%';
  }

  /**
   * Hide progress bar
   */
  hideProgress() {
    const progressSection = document.getElementById('progressSection');
    progressSection.style.display = 'none';
  }

  /**
   * Show notification
   */
  showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';

    setTimeout(() => {
      notification.style.display = 'none';
    }, 5000);
  }

  /**
   * Add to transfer history
   */
  addToHistory(transfer) {
    this.transferHistory.unshift(transfer);

    // Keep only last 50 transfers
    if (this.transferHistory.length > 50) {
      this.transferHistory = this.transferHistory.slice(0, 50);
    }

    // Save to sessionStorage
    sessionStorage.setItem('transferHistory', JSON.stringify(this.transferHistory));
  }

  /**
   * Load history from sessionStorage
   */
  loadHistory() {
    const saved = sessionStorage.getItem('transferHistory');
    if (saved) {
      try {
        this.transferHistory = JSON.parse(saved);
      } catch (error) {
        console.error('Failed to load history:', error);
      }
    }
  }

  /**
   * Render transfer history
   */
  renderHistory() {
    this.loadHistory();

    const container = document.getElementById('transferHistoryContainer');

    if (this.transferHistory.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>No transfer history</p>
        </div>
      `;
      return;
    }

    const historyHTML = this.transferHistory.map(transfer => {
      const icon = transfer.type === 'upload' ? '⬆️' : '⬇️';
      const statusIcon = transfer.status === 'success' ? '✅' : '❌';
      const date = new Date(transfer.timestamp).toLocaleString();
      const size = transfer.size ? this.formatSize(transfer.size) : '-';

      return `
        <div class="history-item ${transfer.status}">
          <div class="history-icon">${icon}</div>
          <div class="history-details">
            <div class="history-filename">${transfer.filename}</div>
            <div class="history-meta">
              ${date} • ${size}
              ${transfer.error ? `<br><span class="error-text">${transfer.error}</span>` : ''}
            </div>
          </div>
          <div class="history-status">${statusIcon}</div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <div class="history-list">
        ${historyHTML}
      </div>
      <button class="btn-clear-history" id="btnClearHistory">Clear History</button>
    `;

    // Clear history button
    const clearBtn = document.getElementById('btnClearHistory');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        this.clearHistory();
      });
    }
  }

  /**
   * Clear transfer history
   */
  clearHistory() {
    this.transferHistory = [];
    sessionStorage.removeItem('transferHistory');
    this.renderHistory();
    this.showNotification('History cleared', 'info');
  }

  /**
   * Format file size
   */
  formatSize(bytes) {
    if (!bytes) return '-';

    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + units[i];
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileTransferModal;
}
